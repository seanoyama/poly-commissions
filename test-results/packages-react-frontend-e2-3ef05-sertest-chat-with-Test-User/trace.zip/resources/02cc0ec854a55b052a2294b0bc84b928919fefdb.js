import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/sidebar.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import { useAuth } from "/src/SessionContext.tsx";
import { react_url } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/sidebar.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function Sidebar() {
	_s();
	const { user } = useAuth();
	const user_url = `${react_url}/users/` + user?.id;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "sidebar",
		children: [
			/* @__PURE__ */ _jsxDEV("a", {
				href: user_url,
				children: "Profile"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 9,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("a", {
				href: `${react_url}/posts`,
				children: "Posts"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 10,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("a", {
				href: `${react_url}/messages`,
				children: "Messages"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 11,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("a", {
				href: `${react_url}/settings`,
				children: "Settings"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 12,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
_s(Sidebar, "9ep4vdl3mBfipxjmc+tQCDhw6Ik=", false, function() {
	return [useAuth];
});
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/sidebar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/sidebar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVEsaUJBQWdCOzs7O0FBRXhCLGVBQWUsU0FBUyxVQUFVOztDQUNoQyxNQUFNLEVBQUUsU0FBUyxRQUFRO0NBQ3pCLE1BQU0sV0FBVyxHQUFHLFVBQVUsV0FBVyxNQUFNO0NBQy9DLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxLQUFEO0lBQUcsTUFBTTtjQUFVO0dBQVU7Ozs7O0dBQzdCLHdCQUFDLEtBQUQ7SUFBRyxNQUFNLEdBQUcsVUFBVTtjQUFTO0dBQVE7Ozs7O0dBQ3ZDLHdCQUFDLEtBQUQ7SUFBRyxNQUFNLEdBQUcsVUFBVTtjQUFZO0dBQVc7Ozs7O0dBQzdDLHdCQUFDLEtBQUQ7SUFBRyxNQUFNLEdBQUcsVUFBVTtjQUFZO0dBQVc7Ozs7O0VBQ3RDOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzaWRlYmFyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4vU2Vzc2lvbkNvbnRleHRcIjtcclxuaW1wb3J0IHtyZWFjdF91cmx9IGZyb20gXCIuL2NvbnN0YW50c1wiXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaWRlYmFyKCkge1xyXG4gIGNvbnN0IHsgdXNlciB9ID0gdXNlQXV0aCgpOyAvL2FkZCBzZXNzaW9uXHJcbiAgY29uc3QgdXNlcl91cmwgPSBgJHtyZWFjdF91cmx9L3VzZXJzL2AgKyB1c2VyPy5pZDtcclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwic2lkZWJhclwiPlxyXG4gICAgICA8YSBocmVmPXt1c2VyX3VybH0+UHJvZmlsZTwvYT5cclxuICAgICAgPGEgaHJlZj17YCR7cmVhY3RfdXJsfS9wb3N0c2B9PlBvc3RzPC9hPlxyXG4gICAgICA8YSBocmVmPXtgJHtyZWFjdF91cmx9L21lc3NhZ2VzYH0+TWVzc2FnZXM8L2E+XHJcbiAgICAgIDxhIGhyZWY9e2Ake3JlYWN0X3VybH0vc2V0dGluZ3NgfT5TZXR0aW5nczwvYT5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==