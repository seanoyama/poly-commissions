import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/ChatsPage.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import "/src/App.css";
//import { useParams } from "react-router";
//import MessagesList from "../MessagesList";
import ChatsList from "/src/ChatsList.tsx";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/ChatsPage.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
export default function MessagesPage() {
	//const { chat_id } = useParams();
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "main",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Messages" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 10,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(ChatsList, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 11,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 5
	}, this);
}
_c = MessagesPage;
var _c;
$RefreshReg$(_c, "MessagesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/ChatsPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/ChatsPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/ChatsPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/ChatsPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTzs7O0FBR1AsT0FBTyxlQUFlOzs7QUFFdEIsZUFBZSxTQUFTLGVBQWU7O0NBRXJDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxXQUFZOzs7O1lBQ2hCLHdCQUFDLFdBQUQsQ0FBWTs7OztVQUNUOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGF0c1BhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL0FwcC5jc3NcIjtcclxuLy9pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcbi8vaW1wb3J0IE1lc3NhZ2VzTGlzdCBmcm9tIFwiLi4vTWVzc2FnZXNMaXN0XCI7XHJcbmltcG9ydCBDaGF0c0xpc3QgZnJvbSBcIi4uL0NoYXRzTGlzdFwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWVzc2FnZXNQYWdlKCkge1xyXG4gIC8vY29uc3QgeyBjaGF0X2lkIH0gPSB1c2VQYXJhbXMoKTtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYWluXCI+XHJcbiAgICAgIDxoMT5NZXNzYWdlczwvaDE+XHJcbiAgICAgIDxDaGF0c0xpc3QgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19