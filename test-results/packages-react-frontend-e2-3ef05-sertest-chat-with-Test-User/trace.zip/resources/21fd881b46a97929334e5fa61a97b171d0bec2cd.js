import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/navbar.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { react_url } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/navbar.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
export default function Navbar() {
	// const URL = "http://localhost:5173";
	return /* @__PURE__ */ _jsxDEV("nav", {
		className: "navbar",
		children: [/* @__PURE__ */ _jsxDEV("h1", {
			className: "logo",
			children: /* @__PURE__ */ _jsxDEV("a", {
				href: "/",
				children: "PolyComms"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 7,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 6,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("ul", {
			className: "nav-list",
			children: [
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
					href: `${react_url}/`,
					children: "About"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 11,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 10,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
					href: `${react_url}/login`,
					children: "Login"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 14,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 13,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("li", { children: /* @__PURE__ */ _jsxDEV("a", {
					href: `${react_url}/signup`,
					children: "Sign Up"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 17,
					columnNumber: 11
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 9,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 5,
		columnNumber: 5
	}, this);
}
_c = Navbar;
var _c;
$RefreshReg$(_c, "Navbar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/navbar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/navbar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/navbar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/navbar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxpQkFBZ0I7OztBQUN4QixlQUFlLFNBQVMsU0FBUzs7Q0FFL0IsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFDWix3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFJO0dBQVk7Ozs7O0VBQ3RCOzs7O1lBQ0osd0JBQUMsTUFBRDtHQUFJLFdBQVU7YUFBZDtJQUNFLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxLQUFEO0tBQUcsTUFBTSxHQUFHLFVBQVU7ZUFBSTtJQUFROzs7O2FBQ2hDOzs7OztJQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxLQUFEO0tBQUcsTUFBTSxHQUFHLFVBQVU7ZUFBUztJQUFROzs7O2FBQ3JDOzs7OztJQUNKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxLQUFEO0tBQUcsTUFBTSxHQUFHLFVBQVU7ZUFBVTtJQUFVOzs7O2FBQ3hDOzs7OztHQUNGOzs7OztVQUNEOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJuYXZiYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7cmVhY3RfdXJsfSBmcm9tIFwiLi9jb25zdGFudHNcIlxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBOYXZiYXIoKSB7XHJcbiAgLy8gY29uc3QgVVJMID0gXCJodHRwOi8vbG9jYWxob3N0OjUxNzNcIjtcclxuICByZXR1cm4gKFxyXG4gICAgPG5hdiBjbGFzc05hbWU9XCJuYXZiYXJcIj5cclxuICAgICAgPGgxIGNsYXNzTmFtZT1cImxvZ29cIj5cclxuICAgICAgICA8YSBocmVmPVwiL1wiPlBvbHlDb21tczwvYT5cclxuICAgICAgPC9oMT5cclxuICAgICAgPHVsIGNsYXNzTmFtZT1cIm5hdi1saXN0XCI+XHJcbiAgICAgICAgPGxpPlxyXG4gICAgICAgICAgPGEgaHJlZj17YCR7cmVhY3RfdXJsfS9gfT5BYm91dDwvYT5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIDxsaT5cclxuICAgICAgICAgIDxhIGhyZWY9e2Ake3JlYWN0X3VybH0vbG9naW5gfT5Mb2dpbjwvYT5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICAgIDxsaT5cclxuICAgICAgICAgIDxhIGhyZWY9e2Ake3JlYWN0X3VybH0vc2lnbnVwYH0+U2lnbiBVcDwvYT5cclxuICAgICAgICA8L2xpPlxyXG4gICAgICA8L3VsPlxyXG4gICAgPC9uYXY+XHJcbiAgKTtcclxufVxyXG4iXX0=