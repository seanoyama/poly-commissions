import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MessageForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessageForm.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
const url = API_URL + "messages";
export default function MessageForm({ chat_id, user_id, onMessageSent }) {
	_s();
	const [body, setBody] = useState("");
	const [error, setError] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		if (!chat_id || !user_id) {
			setError("A chat and signed-in user are required to send a message.");
			return;
		}
		const message = {
			body: body.trim(),
			chat_id,
			user_id
		};
		if (!message.body) {
			setError("Enter a message before sending.");
			return;
		}
		setIsSubmitting(true);
		try {
			const response = await fetch(url, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(message)
			});
			if (!response.ok) {
				const details = await response.text();
				throw new Error(details || "Unable to send message.");
			}
			setBody("");
			onMessageSent();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to send message.");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("label", { children: "Message " }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 71,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "message-body",
				name: "body",
				value: body,
				onChange: (event) => setBody(event.target.value),
				required: true,
				disabled: isSubmitting
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 17
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting || !chat_id || !user_id,
				children: isSubmitting ? "Sending..." : "Send"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 70,
		columnNumber: 5
	}, this);
}
_s(MessageForm, "tCKTNlLOMzaNK16Cc5/0F3CRSnA=");
_c = MessageForm;
var _c;
$RefreshReg$(_c, "MessageForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/MessageForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessageForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessageForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessageForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7QUFDekMsU0FBUSxlQUFjOzs7O0FBbUJ0QixNQUFNLE1BQU0sVUFBUTtBQUVwQixlQUFlLFNBQVMsWUFBWSxFQUNsQyxTQUNBLFNBQ0EsaUJBQ21COztDQUNuQixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBRXRELGVBQWUsYUFBYSxPQUFtQztFQUM3RCxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBRVgsSUFBSSxDQUFDLFdBQVcsQ0FBQyxTQUFTO0dBQ3hCLFNBQVMsMkRBQTJEO0dBQ3BFO0VBQ0Y7RUFFQSxNQUFNLFVBQXNCO0dBQUUsTUFBTSxLQUFLLEtBQUs7R0FBRztHQUFTO0VBQVE7RUFDbEUsSUFBSSxDQUFDLFFBQVEsTUFBTTtHQUNqQixTQUFTLGlDQUFpQztHQUMxQztFQUNGO0VBRUEsZ0JBQWdCLElBQUk7RUFDcEIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sS0FBSztJQUNoQyxRQUFRO0lBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7SUFDOUMsTUFBTSxLQUFLLFVBQVUsT0FBTztHQUM5QixDQUFDO0dBRUQsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUs7SUFDcEMsTUFBTSxJQUFJLE1BQU0sV0FBVyx5QkFBeUI7R0FDdEQ7R0FFQSxRQUFRLEVBQUU7R0FDVixjQUFjO0VBQ2hCLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSx5QkFBeUI7RUFDekUsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxVQUFVO1lBQWhCO0dBQ0Usd0JBQUMsU0FBRCxZQUFPLFdBQWU7Ozs7O0dBQ3RCLHdCQUFDLFNBQUQ7SUFDRSxJQUFHO0lBQ0gsTUFBSztJQUNMLE9BQU87SUFDUCxXQUFXLFVBQVUsUUFBUSxNQUFNLE9BQU8sS0FBSztJQUMvQztJQUNBLFVBQVU7R0FDWDs7Ozs7R0FDQSxTQUFTLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVM7R0FBUzs7Ozs7R0FDcEMsd0JBQUMsVUFBRDtJQUFRLE1BQUs7SUFBUyxVQUFVLGdCQUFnQixDQUFDLFdBQVcsQ0FBQztjQUMxRCxlQUFlLGVBQWU7R0FDekI7Ozs7O0VBQ0o7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1lc3NhZ2VGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtBUElfVVJMfSBmcm9tIFwiLi9jb25zdGFudHNcIlxyXG50eXBlIE1lc3NhZ2UgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxuICBjaGF0X2lkOiBzdHJpbmc7XHJcbiAgdXNlcl9pZDogc3RyaW5nO1xyXG4gIGJvZHk6IHN0cmluZztcclxuICBpbWFnZXM6IHN0cmluZztcclxuICByZXBseV90bzogc3RyaW5nO1xyXG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcclxufTtcclxuXHJcbnR5cGUgTmV3TWVzc2FnZSA9IFBpY2s8TWVzc2FnZSwgXCJjaGF0X2lkXCIgfCBcInVzZXJfaWRcIiB8IFwiYm9keVwiPjtcclxuXHJcbnR5cGUgTWVzc2FnZUZvcm1Qcm9wcyA9IHtcclxuICBjaGF0X2lkPzogc3RyaW5nO1xyXG4gIHVzZXJfaWQ/OiBzdHJpbmc7XHJcbiAgb25NZXNzYWdlU2VudDogKCkgPT4gdm9pZDtcclxufTtcclxuXHJcbmNvbnN0IHVybCA9IEFQSV9VUkwrXCJtZXNzYWdlc1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTWVzc2FnZUZvcm0oe1xyXG4gIGNoYXRfaWQsXHJcbiAgdXNlcl9pZCxcclxuICBvbk1lc3NhZ2VTZW50XHJcbn06IE1lc3NhZ2VGb3JtUHJvcHMpIHtcclxuICBjb25zdCBbYm9keSwgc2V0Qm9keV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRFcnJvcihcIlwiKTtcclxuXHJcbiAgICBpZiAoIWNoYXRfaWQgfHwgIXVzZXJfaWQpIHsgLy8gdGhpcyBjYXNlIHNob3VsZCBiZSBpbXBvc3NpYmxlIHNpbmNlIHNvbWVvbmUgbm90IGxvZ2dlZCBpbiB3b3VsZG4ndCBzZWUgdGhlIG1lc3NhZ2UgZm9ybSBJIHRoaW5rXHJcbiAgICAgIHNldEVycm9yKFwiQSBjaGF0IGFuZCBzaWduZWQtaW4gdXNlciBhcmUgcmVxdWlyZWQgdG8gc2VuZCBhIG1lc3NhZ2UuXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgbWVzc2FnZTogTmV3TWVzc2FnZSA9IHsgYm9keTogYm9keS50cmltKCksIGNoYXRfaWQsIHVzZXJfaWQgfTtcclxuICAgIGlmICghbWVzc2FnZS5ib2R5KSB7XHJcbiAgICAgIHNldEVycm9yKFwiRW50ZXIgYSBtZXNzYWdlIGJlZm9yZSBzZW5kaW5nLlwiKTtcclxuICAgICAgcmV0dXJuO1xyXG4gICAgfVxyXG5cclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkobWVzc2FnZSlcclxuICAgICAgfSk7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGV0YWlscyA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZGV0YWlscyB8fCBcIlVuYWJsZSB0byBzZW5kIG1lc3NhZ2UuXCIpO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRCb2R5KFwiXCIpO1xyXG4gICAgICBvbk1lc3NhZ2VTZW50KCk7XHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6IFwiVW5hYmxlIHRvIHNlbmQgbWVzc2FnZS5cIik7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICA8bGFiZWw+TWVzc2FnZSA8L2xhYmVsPlxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICBpZD1cIm1lc3NhZ2UtYm9keVwiXHJcbiAgICAgICAgbmFtZT1cImJvZHlcIlxyXG4gICAgICAgIHZhbHVlPXtib2R5fVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+IHNldEJvZHkoZXZlbnQudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgIC8+XHJcbiAgICAgIHtlcnJvciAmJiA8cCByb2xlPVwiYWxlcnRcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZyB8fCAhY2hhdF9pZCB8fCAhdXNlcl9pZH0+XHJcbiAgICAgICAge2lzU3VibWl0dGluZyA/IFwiU2VuZGluZy4uLlwiIDogXCJTZW5kXCJ9XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn0iXX0=