import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/LoginForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/LoginForm.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function LoginForm() {
	_s();
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		setIsSubmitting(true);
		const formData = new FormData(event.currentTarget);
		const email = String(formData.get("email"));
		const password = String(formData.get("password"));
		try {
			const response = await fetch(`${API_URL}/auth/login`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					email,
					password
				})
			});
			//const { user, session, error } = await supabase.auth.signIn({
			//email: 'example@email.com',
			//password: 'example-password',
			//})
			const result = await response.json();
			if (!response.ok) {
				throw new Error(result.error ?? "Unable to log in.");
			}
			setMessage(`Logged in as ${result.user?.email ?? email}.`);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to log in.");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "LoginForm",
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "email",
				children: "Email"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "email",
				name: "email",
				type: "email",
				autoComplete: "email",
				required: true,
				disabled: isSubmitting,
				className: "LoginEntry"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "password",
				children: "Password"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 75,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "password",
				name: "password",
				type: "password",
				autoComplete: "current-password",
				required: true,
				disabled: isSubmitting,
				className: "LoginEntry"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 76,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 17
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 19
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting,
				className: "LoginButton",
				children: isSubmitting ? "Logging in..." : "Log in"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 63,
		columnNumber: 5
	}, this);
}
_s(LoginForm, "H3bakMZ/G+40iBpvDXOVBtBXhV0=");
_c = LoginForm;
var _c;
$RefreshReg$(_c, "LoginForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/LoginForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/LoginForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/LoginForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/LoginForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7QUFFekMsU0FBUSxlQUFjOzs7O0FBU3RCLGVBQWUsU0FBUyxZQUFZOztDQUNsQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBRXRELGVBQWUsYUFDYixPQUNBO0VBQ0EsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUNYLFdBQVcsRUFBRTtFQUNiLGdCQUFnQixJQUFJO0VBRXBCLE1BQU0sV0FBVyxJQUFJLFNBQVMsTUFBTSxhQUFhO0VBQ2pELE1BQU0sUUFBUSxPQUFPLFNBQVMsSUFBSSxPQUFPLENBQUM7RUFDMUMsTUFBTSxXQUFXLE9BQU8sU0FBUyxJQUFJLFVBQVUsQ0FBQztFQUVoRCxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLFFBQVEsY0FBYztJQUNwRCxRQUFRO0lBQ1IsU0FBUyxFQUNQLGdCQUFnQixtQkFDbEI7SUFDQSxNQUFNLEtBQUssVUFBVTtLQUFFO0tBQU87SUFBUyxDQUFDO0dBQzFDLENBQUM7Ozs7O0dBT0QsTUFBTSxTQUFVLE1BQU0sU0FBUyxLQUFLO0dBRXBDLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQU0sT0FBTyxTQUFTLG1CQUFtQjtHQUNyRDtHQUVBLFdBQ0UsZ0JBQWdCLE9BQU8sTUFBTSxTQUFTLE1BQU0sRUFDOUM7RUFFRixTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFBUSxJQUFJLFVBQVUsbUJBQ3ZDO0VBQ0YsVUFBVTtHQUNSLGdCQUFnQixLQUFLO0VBQ3ZCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFFBQUQ7RUFBTSxXQUFVO0VBQVksVUFBVTtZQUF0QztHQUNFLHdCQUFDLFNBQUQ7SUFBTyxTQUFRO2NBQVE7R0FBWTs7Ozs7R0FDbkMsd0JBQUMsU0FBRDtJQUNFLElBQUc7SUFDSCxNQUFLO0lBQ0wsTUFBSztJQUNMLGNBQWE7SUFDYjtJQUNBLFVBQVU7SUFDVixXQUFVO0dBQ1g7Ozs7O0dBRUQsd0JBQUMsU0FBRDtJQUFPLFNBQVE7Y0FBVztHQUFlOzs7OztHQUN6Qyx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxNQUFLO0lBQ0wsY0FBYTtJQUNiO0lBQ0EsVUFBVTtJQUNWLFdBQVU7R0FDWDs7Ozs7R0FFQSxTQUFTLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVM7R0FBUzs7Ozs7R0FDbkMsV0FBVyx3QkFBQyxLQUFELFlBQUksUUFBVzs7Ozs7R0FFM0Isd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxVQUFVO0lBQ1YsV0FBVTtjQUNULGVBQWUsa0JBQWtCO0dBQzVCOzs7OztFQUNKOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJMb2dpbkZvcm0udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB0eXBlIEZvcm1FdmVudCB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHtBUElfVVJMfSBmcm9tIFwiLi9jb25zdGFudHNcIlxyXG5cclxudHlwZSBMb2dpblJlc3BvbnNlID0ge1xyXG4gIGVycm9yPzogc3RyaW5nO1xyXG4gIHVzZXI/OiB7XHJcbiAgICBlbWFpbD86IHN0cmluZyB8IG51bGw7XHJcbiAgfTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luRm9ybSgpIHtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtpc1N1Ym1pdHRpbmcsIHNldElzU3VibWl0dGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChcclxuICAgIGV2ZW50OiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PlxyXG4gICkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgc2V0TWVzc2FnZShcIlwiKTtcclxuICAgIHNldElzU3VibWl0dGluZyh0cnVlKTtcclxuXHJcbiAgICBjb25zdCBmb3JtRGF0YSA9IG5ldyBGb3JtRGF0YShldmVudC5jdXJyZW50VGFyZ2V0KTtcclxuICAgIGNvbnN0IGVtYWlsID0gU3RyaW5nKGZvcm1EYXRhLmdldChcImVtYWlsXCIpKTtcclxuICAgIGNvbnN0IHBhc3N3b3JkID0gU3RyaW5nKGZvcm1EYXRhLmdldChcInBhc3N3b3JkXCIpKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGAke0FQSV9VUkx9L2F1dGgvbG9naW5gLCB7XHJcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoeyBlbWFpbCwgcGFzc3dvcmQgfSlcclxuICAgICAgfSk7XHJcblxyXG4gICAgICAvL2NvbnN0IHsgdXNlciwgc2Vzc2lvbiwgZXJyb3IgfSA9IGF3YWl0IHN1cGFiYXNlLmF1dGguc2lnbkluKHtcclxuICAgICAgLy9lbWFpbDogJ2V4YW1wbGVAZW1haWwuY29tJyxcclxuICAgICAgLy9wYXNzd29yZDogJ2V4YW1wbGUtcGFzc3dvcmQnLFxyXG4gICAgICAvL30pXHJcblxyXG4gICAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgcmVzcG9uc2UuanNvbigpKSBhcyBMb2dpblJlc3BvbnNlO1xyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihyZXN1bHQuZXJyb3IgPz8gXCJVbmFibGUgdG8gbG9nIGluLlwiKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0TWVzc2FnZShcclxuICAgICAgICBgTG9nZ2VkIGluIGFzICR7cmVzdWx0LnVzZXI/LmVtYWlsID8/IGVtYWlsfS5gXHJcbiAgICAgICk7XHJcbiAgICAgIC8vIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJVbmFibGUgdG8gbG9nIGluLlwiXHJcbiAgICAgICk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtIGNsYXNzTmFtZT1cIkxvZ2luRm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxyXG4gICAgICA8aW5wdXRcclxuICAgICAgICBpZD1cImVtYWlsXCJcclxuICAgICAgICBuYW1lPVwiZW1haWxcIlxyXG4gICAgICAgIHR5cGU9XCJlbWFpbFwiXHJcbiAgICAgICAgYXV0b0NvbXBsZXRlPVwiZW1haWxcIlxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICBjbGFzc05hbWU9XCJMb2dpbkVudHJ5XCJcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5QYXNzd29yZDwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgIG5hbWU9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICBhdXRvQ29tcGxldGU9XCJjdXJyZW50LXBhc3N3b3JkXCJcclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiTG9naW5FbnRyeVwiXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7ZXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XHJcbiAgICAgIHttZXNzYWdlICYmIDxwPnttZXNzYWdlfTwvcD59XHJcblxyXG4gICAgICA8YnV0dG9uXHJcbiAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgZGlzYWJsZWQ9e2lzU3VibWl0dGluZ31cclxuICAgICAgICBjbGFzc05hbWU9XCJMb2dpbkJ1dHRvblwiPlxyXG4gICAgICAgIHtpc1N1Ym1pdHRpbmcgPyBcIkxvZ2dpbmcgaW4uLi5cIiA6IFwiTG9nIGluXCJ9XHJcbiAgICAgIDwvYnV0dG9uPlxyXG4gICAgPC9mb3JtPlxyXG4gICk7XHJcbn1cclxuIl19