import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SignupForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SignupForm.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
const CAL_POLY_EMAIL = /^[^\s@]+@calpoly\.edu$/i;
export default function SignupForm() {
	_s();
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		setIsSubmitting(true);
		const formData = new FormData(event.currentTarget);
		const name = String(formData.get("name") ?? "").trim();
		const email = String(formData.get("email") ?? "").trim();
		const password = String(formData.get("password") ?? "");
		if (!CAL_POLY_EMAIL.test(email)) {
			setError("Please use your @calpoly.edu email address.");
			setIsSubmitting(false);
			return;
		}
		try {
			const response = await fetch(`${API_URL}/users`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					name,
					email,
					password
				})
			});
			const result = await response.json();
			if (!response.ok) {
				throw new Error(result.error ?? "Unable to create your account.");
			}
			setMessage(`Account created for ${result.name ?? name}.`);
			event.currentTarget.reset();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to create your account.");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "LoginForm",
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "name",
				children: "Name "
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "name",
				name: "name",
				type: "text",
				autoComplete: "name",
				required: true,
				disabled: isSubmitting,
				className: "LoginEntry",
				placeholder: "e.g. Jeffrey Mustang"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 67,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "email",
				children: "Email "
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "email",
				name: "email",
				type: "email",
				autoComplete: "email",
				required: true,
				disabled: isSubmitting,
				className: "LoginEntry",
				placeholder: "e.g. jeffreym@calpoly.edu"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: "password",
				children: "New password "
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 90,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: "password",
				name: "password",
				type: "password",
				autoComplete: "new-password",
				required: true,
				disabled: isSubmitting,
				className: "LoginEntry"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 91,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 17
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 102,
				columnNumber: 19
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting,
				className: "LoginButton",
				children: isSubmitting ? "Creating account..." : "Sign up"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 104,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 65,
		columnNumber: 5
	}, this);
}
_s(SignupForm, "H3bakMZ/G+40iBpvDXOVBtBXhV0=");
_c = SignupForm;
var _c;
$RefreshReg$(_c, "SignupForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/SignupForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SignupForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SignupForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SignupForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7QUFFekMsU0FBUSxlQUFjOzs7O0FBQ3RCLE1BQU0saUJBQWlCO0FBU3ZCLGVBQWUsU0FBUyxhQUFhOztDQUNuQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUN6QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBRXRELGVBQWUsYUFDYixPQUNBO0VBQ0EsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUNYLFdBQVcsRUFBRTtFQUNiLGdCQUFnQixJQUFJO0VBRXBCLE1BQU0sV0FBVyxJQUFJLFNBQVMsTUFBTSxhQUFhO0VBQ2pELE1BQU0sT0FBTyxPQUFPLFNBQVMsSUFBSSxNQUFNLEtBQUssRUFBRSxDQUFDLENBQUMsS0FBSztFQUNyRCxNQUFNLFFBQVEsT0FBTyxTQUFTLElBQUksT0FBTyxLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUs7RUFDdkQsTUFBTSxXQUFXLE9BQU8sU0FBUyxJQUFJLFVBQVUsS0FBSyxFQUFFO0VBRXRELElBQUksQ0FBQyxlQUFlLEtBQUssS0FBSyxHQUFHO0dBQy9CLFNBQVMsNkNBQTZDO0dBQ3RELGdCQUFnQixLQUFLO0dBQ3JCO0VBQ0Y7RUFFQSxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHLFFBQVEsU0FBUztJQUMvQyxRQUFRO0lBQ1IsU0FBUyxFQUFFLGdCQUFnQixtQkFBbUI7SUFDOUMsTUFBTSxLQUFLLFVBQVU7S0FBRTtLQUFNO0tBQU87SUFBUyxDQUFDO0dBQ2hELENBQUM7R0FDRCxNQUFNLFNBQVUsTUFBTSxTQUFTLEtBQUs7R0FFcEMsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFDUixPQUFPLFNBQVMsZ0NBQ2xCO0dBQ0Y7R0FFQSxXQUFXLHVCQUF1QixPQUFPLFFBQVEsS0FBSyxFQUFFO0dBQ3hELE1BQU0sY0FBYyxNQUFNO0VBQzVCLFNBQVMsS0FBSztHQUNaLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSixnQ0FDTjtFQUNGLFVBQVU7R0FDUixnQkFBZ0IsS0FBSztFQUN2QjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxRQUFEO0VBQU0sV0FBVTtFQUFZLFVBQVU7WUFBdEM7R0FDRSx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFPO0dBQVk7Ozs7O0dBQ2xDLHdCQUFDLFNBQUQ7SUFDRSxJQUFHO0lBQ0gsTUFBSztJQUNMLE1BQUs7SUFDTCxjQUFhO0lBQ2I7SUFDQSxVQUFVO0lBQ1YsV0FBVTtJQUNWLGFBQVk7R0FDYjs7Ozs7R0FFRCx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFRO0dBQWE7Ozs7O0dBQ3BDLHdCQUFDLFNBQUQ7SUFDRSxJQUFHO0lBQ0gsTUFBSztJQUNMLE1BQUs7SUFDTCxjQUFhO0lBQ2I7SUFDQSxVQUFVO0lBQ1YsV0FBVTtJQUNWLGFBQVk7R0FDYjs7Ozs7R0FFRCx3QkFBQyxTQUFEO0lBQU8sU0FBUTtjQUFXO0dBQW9COzs7OztHQUM5Qyx3QkFBQyxTQUFEO0lBQ0UsSUFBRztJQUNILE1BQUs7SUFDTCxNQUFLO0lBQ0wsY0FBYTtJQUNiO0lBQ0EsVUFBVTtJQUNWLFdBQVU7R0FDWDs7Ozs7R0FFQSxTQUFTLHdCQUFDLEtBQUQ7SUFBRyxNQUFLO2NBQVM7R0FBUzs7Ozs7R0FDbkMsV0FBVyx3QkFBQyxLQUFELFlBQUksUUFBVzs7Ozs7R0FFM0Isd0JBQUMsVUFBRDtJQUNFLE1BQUs7SUFDTCxVQUFVO0lBQ1YsV0FBVTtjQUNULGVBQWUsd0JBQXdCO0dBQ2xDOzs7OztFQUNKOzs7Ozs7QUFFViIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTaWdudXBGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCB7QVBJX1VSTH0gZnJvbSBcIi4vY29uc3RhbnRzXCJcclxuY29uc3QgQ0FMX1BPTFlfRU1BSUwgPSAvXlteXFxzQF0rQGNhbHBvbHlcXC5lZHUkL2k7XHJcblxyXG50eXBlIFNpZ251cFJlc3BvbnNlID0ge1xyXG4gIGVycm9yPzogc3RyaW5nO1xyXG4gIGlkPzogc3RyaW5nO1xyXG4gIGVtYWlsPzogc3RyaW5nO1xyXG4gIG5hbWU/OiBzdHJpbmc7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTaWdudXBGb3JtKCkge1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2lzU3VibWl0dGluZywgc2V0SXNTdWJtaXR0aW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KFxyXG4gICAgZXZlbnQ6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+XHJcbiAgKSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgc2V0RXJyb3IoXCJcIik7XHJcbiAgICBzZXRNZXNzYWdlKFwiXCIpO1xyXG4gICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xyXG5cclxuICAgIGNvbnN0IGZvcm1EYXRhID0gbmV3IEZvcm1EYXRhKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xyXG4gICAgY29uc3QgbmFtZSA9IFN0cmluZyhmb3JtRGF0YS5nZXQoXCJuYW1lXCIpID8/IFwiXCIpLnRyaW0oKTtcclxuICAgIGNvbnN0IGVtYWlsID0gU3RyaW5nKGZvcm1EYXRhLmdldChcImVtYWlsXCIpID8/IFwiXCIpLnRyaW0oKTtcclxuICAgIGNvbnN0IHBhc3N3b3JkID0gU3RyaW5nKGZvcm1EYXRhLmdldChcInBhc3N3b3JkXCIpID8/IFwiXCIpO1xyXG5cclxuICAgIGlmICghQ0FMX1BPTFlfRU1BSUwudGVzdChlbWFpbCkpIHtcclxuICAgICAgc2V0RXJyb3IoXCJQbGVhc2UgdXNlIHlvdXIgQGNhbHBvbHkuZWR1IGVtYWlsIGFkZHJlc3MuXCIpO1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChgJHtBUElfVVJMfS91c2Vyc2AsIHtcclxuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxyXG4gICAgICAgIGhlYWRlcnM6IHsgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCIgfSxcclxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IG5hbWUsIGVtYWlsLCBwYXNzd29yZCB9KVxyXG4gICAgICB9KTtcclxuICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgU2lnbnVwUmVzcG9uc2U7XHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgcmVzdWx0LmVycm9yID8/IFwiVW5hYmxlIHRvIGNyZWF0ZSB5b3VyIGFjY291bnQuXCJcclxuICAgICAgICApO1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRNZXNzYWdlKGBBY2NvdW50IGNyZWF0ZWQgZm9yICR7cmVzdWx0Lm5hbWUgPz8gbmFtZX0uYCk7XHJcbiAgICAgIGV2ZW50LmN1cnJlbnRUYXJnZXQucmVzZXQoKTtcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgOiBcIlVuYWJsZSB0byBjcmVhdGUgeW91ciBhY2NvdW50LlwiXHJcbiAgICAgICk7XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRJc1N1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxmb3JtIGNsYXNzTmFtZT1cIkxvZ2luRm9ybVwiIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIj5OYW1lIDwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPVwibmFtZVwiXHJcbiAgICAgICAgbmFtZT1cIm5hbWVcIlxyXG4gICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICBhdXRvQ29tcGxldGU9XCJuYW1lXCJcclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiTG9naW5FbnRyeVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIEplZmZyZXkgTXVzdGFuZ1wiXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWwgPC9sYWJlbD5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgaWQ9XCJlbWFpbFwiXHJcbiAgICAgICAgbmFtZT1cImVtYWlsXCJcclxuICAgICAgICB0eXBlPVwiZW1haWxcIlxyXG4gICAgICAgIGF1dG9Db21wbGV0ZT1cImVtYWlsXCJcclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiTG9naW5FbnRyeVwiXHJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJlLmcuIGplZmZyZXltQGNhbHBvbHkuZWR1XCJcclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5OZXcgcGFzc3dvcmQgPC9sYWJlbD5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgbmFtZT1cInBhc3N3b3JkXCJcclxuICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgIGF1dG9Db21wbGV0ZT1cIm5ldy1wYXNzd29yZFwiXHJcbiAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICBkaXNhYmxlZD17aXNTdWJtaXR0aW5nfVxyXG4gICAgICAgIGNsYXNzTmFtZT1cIkxvZ2luRW50cnlcIlxyXG4gICAgICAvPlxyXG5cclxuICAgICAge2Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L3A+fVxyXG4gICAgICB7bWVzc2FnZSAmJiA8cD57bWVzc2FnZX08L3A+fVxyXG5cclxuICAgICAgPGJ1dHRvblxyXG4gICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgIGRpc2FibGVkPXtpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgY2xhc3NOYW1lPVwiTG9naW5CdXR0b25cIj5cclxuICAgICAgICB7aXNTdWJtaXR0aW5nID8gXCJDcmVhdGluZyBhY2NvdW50Li4uXCIgOiBcIlNpZ24gdXBcIn1cclxuICAgICAgPC9idXR0b24+XHJcbiAgICA8L2Zvcm0+XHJcbiAgKTtcclxufVxyXG4iXX0=