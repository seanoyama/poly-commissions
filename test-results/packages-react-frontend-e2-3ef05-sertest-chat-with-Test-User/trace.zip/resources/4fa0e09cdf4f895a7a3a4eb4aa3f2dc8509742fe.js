import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/LoginPage.tsx");const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import "/src/App.css";
import LoginForm from "/src/LoginForm.tsx";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/LoginPage.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
export default function LoginPage() {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "main",
		children: [/* @__PURE__ */ _jsxDEV("h1", { children: "Login" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 7,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(LoginForm, {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 8,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 6,
		columnNumber: 5
	}, this);
}
_c = LoginPage;
var _c;
$RefreshReg$(_c, "LoginPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/LoginPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/LoginPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/LoginPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/LoginPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLE9BQU8sZUFBZTs7O0FBRXRCLGVBQWUsU0FBUyxZQUFZO0NBQ2xDLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLE1BQUQsWUFBSSxRQUFTOzs7O1lBQ2Isd0JBQUMsV0FBRCxDQUFZOzs7O1VBQ1Q7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkxvZ2luUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vQXBwLmNzc1wiO1xyXG5pbXBvcnQgTG9naW5Gb3JtIGZyb20gXCIuLi9Mb2dpbkZvcm1cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExvZ2luUGFnZSgpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYWluXCI+XHJcbiAgICAgIDxoMT5Mb2dpbjwvaDE+XHJcbiAgICAgIDxMb2dpbkZvcm0gLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19