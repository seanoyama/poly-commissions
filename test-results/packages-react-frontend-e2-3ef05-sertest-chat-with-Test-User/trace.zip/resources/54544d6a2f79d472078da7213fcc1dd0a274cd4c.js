import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/posts.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import PostsList from "/src/PostsList.tsx";
import PhotoUpload from "/src/photoUpload.tsx";
//import PayPal from "../paypal.";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/posts.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
// const API_URL =
//   import.meta.env.VITE_API_URL ?? "http://localhost:8000";
const CATEGORIES = [
	"Furniture",
	"Electronics",
	"Clothing",
	"Books",
	"Other"
];
export default function Posts() {
	_s();
	const [title, setTitle] = useState("");
	const [price, setPrice] = useState("");
	const [category, setCategory] = useState("");
	const [location, setLocation] = useState("");
	const [image, setImage] = useState("");
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const [submitting, setSubmitting] = useState(false);
	const [refreshKey, setRefreshKey] = useState(0);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		if (!image) {
			setError("Please upload a photo first.");
			return;
		}
		setSubmitting(true);
		try {
			const response = await fetch(`${API_URL}/posts`, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify({
					title,
					price: Number(price),
					category,
					location,
					image
				})
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(data?.detail ?? "Could not create listing.");
			}
			setTitle("");
			setPrice("");
			setCategory("");
			setLocation("");
			setImage("");
			setMessage("Your listing was created!");
			setRefreshKey((k) => k + 1);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not create listing.");
		} finally {
			setSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "posts",
		children: [/* @__PURE__ */ _jsxDEV("section", {
			className: "loginForm",
			children: [
				/* @__PURE__ */ _jsxDEV("h2", { children: "Create a listing" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 85,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("form", {
					onSubmit: handleSubmit,
					children: [
						/* @__PURE__ */ _jsxDEV("label", { children: ["Title", /* @__PURE__ */ _jsxDEV("input", {
							value: title,
							onChange: (e) => setTitle(e.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 88,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", { children: ["Price ($)", /* @__PURE__ */ _jsxDEV("input", {
							type: "number",
							min: "0",
							step: "0.01",
							value: price,
							onChange: (e) => setPrice(e.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 99,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 97,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", { children: ["Category", /* @__PURE__ */ _jsxDEV("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							required: true,
							children: [/* @__PURE__ */ _jsxDEV("option", {
								value: "",
								disabled: true,
								children: "Select a category"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 116,
								columnNumber: 15
							}, this), CATEGORIES.map((c) => /* @__PURE__ */ _jsxDEV("option", {
								value: c,
								children: c
							}, c, false, {
								fileName: _jsxFileName,
								lineNumber: 120,
								columnNumber: 17
							}, this))]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 110,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("label", { children: ["Location", /* @__PURE__ */ _jsxDEV("input", {
							value: location,
							onChange: (e) => setLocation(e.target.value),
							required: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 129,
							columnNumber: 13
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV(PhotoUpload, { onUpload: setImage }, refreshKey, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: submitting || !image,
							children: submitting ? "Creating..." : "Create listing"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 136,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 142,
					columnNumber: 19
				}, this),
				message && /* @__PURE__ */ _jsxDEV("p", {
					role: "status",
					children: message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 143,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 84,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV(PostsList, { refreshKey }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 146,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
_s(Posts, "HiQQChFXXd2rKdi2Iwr6gHYuro0=");
_c = Posts;
var _c;
$RefreshReg$(_c, "Posts");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/posts.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/posts.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/posts.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/posts.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFFekIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8saUJBQWlCOztBQUd4QixTQUFRLGVBQWM7Ozs7OztBQUl0QixNQUFNLGFBQWE7Q0FDakI7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtBQUNGO0FBRUEsZUFBZSxTQUFTLFFBQVE7O0NBQzlCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLEtBQUs7Q0FDbEQsTUFBTSxDQUFDLFlBQVksaUJBQWlCLFNBQVMsQ0FBQztDQUU5QyxlQUFlLGFBQ2IsT0FDQTtFQUNBLE1BQU0sZUFBZTtFQUNyQixTQUFTLEVBQUU7RUFDWCxXQUFXLEVBQUU7RUFFYixJQUFJLENBQUMsT0FBTztHQUNWLFNBQVMsOEJBQThCO0dBQ3ZDO0VBQ0Y7RUFFQSxjQUFjLElBQUk7RUFFbEIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQU0sR0FBRyxRQUFRLFNBQVM7SUFDL0MsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVO0tBQ25CO0tBQ0EsT0FBTyxPQUFPLEtBQUs7S0FDbkI7S0FDQTtLQUNBO0lBQ0YsQ0FBQztHQUNILENBQUM7R0FFRCxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsWUFBWSxJQUFJO0lBQ25ELE1BQU0sSUFBSSxNQUNSLE1BQU0sVUFBVSwyQkFDbEI7R0FDRjtHQUVBLFNBQVMsRUFBRTtHQUNYLFNBQVMsRUFBRTtHQUNYLFlBQVksRUFBRTtHQUNkLFlBQVksRUFBRTtHQUNkLFNBQVMsRUFBRTtHQUNYLFdBQVcsMkJBQTJCO0dBQ3RDLGVBQWUsTUFBTSxJQUFJLENBQUM7RUFDNUIsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDJCQUNOO0VBQ0YsVUFBVTtHQUNSLGNBQWMsS0FBSztFQUNyQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUNFLHdCQUFDLFdBQUQ7R0FBUyxXQUFVO2FBQW5CO0lBQ0Usd0JBQUMsTUFBRCxZQUFJLG1CQUFvQjs7Ozs7SUFFeEIsd0JBQUMsUUFBRDtLQUFNLFVBQVU7ZUFBaEI7TUFDRSx3QkFBQyxTQUFELGFBQU8sU0FFTCx3QkFBQyxTQUFEO09BQ0UsT0FBTztPQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO09BQ3hDO01BQ0Q7Ozs7Y0FDSTs7Ozs7TUFDUCx3QkFBQyxNQUFELENBQVE7Ozs7O01BQ1Isd0JBQUMsU0FBRCxhQUFPLGFBRUwsd0JBQUMsU0FBRDtPQUNFLE1BQUs7T0FDTCxLQUFJO09BQ0osTUFBSztPQUNMLE9BQU87T0FDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztPQUN4QztNQUNEOzs7O2NBQ0k7Ozs7O01BRVAsd0JBQUMsTUFBRCxDQUFROzs7OztNQUNSLHdCQUFDLFNBQUQsYUFBTyxZQUVMLHdCQUFDLFVBQUQ7T0FDRSxPQUFPO09BQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7T0FDM0M7aUJBSEYsQ0FJRSx3QkFBQyxVQUFEO1FBQVEsT0FBTTtRQUFHO2tCQUFTO09BRWxCOzs7O2lCQUNQLFdBQVcsS0FBSyxNQUNmLHdCQUFDLFVBQUQ7UUFBZ0IsT0FBTztrQkFDcEI7T0FDSyxHQUZLOzs7O2NBRUwsQ0FDVCxDQUNLOzs7OztjQUNIOzs7OztNQUNQLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7TUFDUix3QkFBQyxTQUFELGFBQU8sWUFFTCx3QkFBQyxTQUFEO09BQ0UsT0FBTztPQUNQLFdBQVcsTUFBTSxZQUFZLEVBQUUsT0FBTyxLQUFLO09BQzNDO01BQ0Q7Ozs7Y0FDSTs7Ozs7TUFDUCx3QkFBQyxhQUFELEVBQThCLFVBQVUsU0FBVyxHQUFqQzs7OzthQUFpQztNQUNuRCx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFVBQVUsY0FBYyxDQUFDO2lCQUM1QyxhQUFhLGdCQUFnQjtNQUN4Qjs7Ozs7S0FDSjs7Ozs7O0lBQ04sd0JBQUMsTUFBRCxDQUFROzs7OztJQUVQLFNBQVMsd0JBQUMsS0FBRDtLQUFHLE1BQUs7ZUFBUztJQUFTOzs7OztJQUNuQyxXQUFXLHdCQUFDLEtBQUQ7S0FBRyxNQUFLO2VBQVU7SUFBVzs7Ozs7R0FDbEM7Ozs7O1lBRVQsd0JBQUMsV0FBRCxFQUF1QixXQUFhOzs7O1VBQzdCOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwb3N0cy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmltcG9ydCBQb3N0c0xpc3QgZnJvbSBcIi4vUG9zdHNMaXN0XCI7XHJcbmltcG9ydCBQaG90b1VwbG9hZCBmcm9tIFwiLi9waG90b1VwbG9hZFwiO1xyXG4vL2ltcG9ydCBQYXlQYWwgZnJvbSBcIi4uL3BheXBhbC5cIjtcclxuXHJcbmltcG9ydCB7QVBJX1VSTH0gZnJvbSBcIi4vY29uc3RhbnRzXCJcclxuLy8gY29uc3QgQVBJX1VSTCA9XHJcbi8vICAgaW1wb3J0Lm1ldGEuZW52LlZJVEVfQVBJX1VSTCA/PyBcImh0dHA6Ly9sb2NhbGhvc3Q6ODAwMFwiO1xyXG5cclxuY29uc3QgQ0FURUdPUklFUyA9IFtcclxuICBcIkZ1cm5pdHVyZVwiLFxyXG4gIFwiRWxlY3Ryb25pY3NcIixcclxuICBcIkNsb3RoaW5nXCIsXHJcbiAgXCJCb29rc1wiLFxyXG4gIFwiT3RoZXJcIlxyXG5dO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUG9zdHMoKSB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbcHJpY2UsIHNldFByaWNlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtjYXRlZ29yeSwgc2V0Q2F0ZWdvcnldID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2xvY2F0aW9uLCBzZXRMb2NhdGlvbl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuICBjb25zdCBbaW1hZ2UsIHNldEltYWdlXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3N1Ym1pdHRpbmcsIHNldFN1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gIGNvbnN0IFtyZWZyZXNoS2V5LCBzZXRSZWZyZXNoS2V5XSA9IHVzZVN0YXRlKDApO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoXHJcbiAgICBldmVudDogUmVhY3QuRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD5cclxuICApIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KCk7XHJcbiAgICBzZXRFcnJvcihcIlwiKTtcclxuICAgIHNldE1lc3NhZ2UoXCJcIik7XHJcblxyXG4gICAgaWYgKCFpbWFnZSkge1xyXG4gICAgICBzZXRFcnJvcihcIlBsZWFzZSB1cGxvYWQgYSBwaG90byBmaXJzdC5cIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYCR7QVBJX1VSTH0vcG9zdHNgLCB7XHJcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgdGl0bGUsXHJcbiAgICAgICAgICBwcmljZTogTnVtYmVyKHByaWNlKSxcclxuICAgICAgICAgIGNhdGVnb3J5LFxyXG4gICAgICAgICAgbG9jYXRpb24sXHJcbiAgICAgICAgICBpbWFnZVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH0pO1xyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbCk7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgZGF0YT8uZGV0YWlsID8/IFwiQ291bGQgbm90IGNyZWF0ZSBsaXN0aW5nLlwiXHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG5cclxuICAgICAgc2V0VGl0bGUoXCJcIik7XHJcbiAgICAgIHNldFByaWNlKFwiXCIpO1xyXG4gICAgICBzZXRDYXRlZ29yeShcIlwiKTtcclxuICAgICAgc2V0TG9jYXRpb24oXCJcIik7XHJcbiAgICAgIHNldEltYWdlKFwiXCIpO1xyXG4gICAgICBzZXRNZXNzYWdlKFwiWW91ciBsaXN0aW5nIHdhcyBjcmVhdGVkIVwiKTtcclxuICAgICAgc2V0UmVmcmVzaEtleSgoaykgPT4gayArIDEpOyAvLyByZWZldGNoZXMgdGhlIGxpc3QgKyByZXNldHMgdGhlIHVwbG9hZGVyXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcclxuICAgICAgICAgIDogXCJDb3VsZCBub3QgY3JlYXRlIGxpc3RpbmcuXCJcclxuICAgICAgKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldFN1Ym1pdHRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvc3RzXCI+XHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImxvZ2luRm9ybVwiPlxyXG4gICAgICAgIDxoMj5DcmVhdGUgYSBsaXN0aW5nPC9oMj5cclxuXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgIFRpdGxlXHJcbiAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxicj48L2JyPlxyXG4gICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICBQcmljZSAoJClcclxuICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgICAgbWluPVwiMFwiXHJcbiAgICAgICAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXtwcmljZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFByaWNlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIHsvKiA8UGF5UGFsIC8+ICovfVxyXG4gICAgICAgICAgPGJyPjwvYnI+XHJcbiAgICAgICAgICA8bGFiZWw+XHJcbiAgICAgICAgICAgIENhdGVnb3J5XHJcbiAgICAgICAgICAgIDxzZWxlY3RcclxuICAgICAgICAgICAgICB2YWx1ZT17Y2F0ZWdvcnl9XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDYXRlZ29yeShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWQ+XHJcbiAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cIlwiIGRpc2FibGVkPlxyXG4gICAgICAgICAgICAgICAgU2VsZWN0IGEgY2F0ZWdvcnlcclxuICAgICAgICAgICAgICA8L29wdGlvbj5cclxuICAgICAgICAgICAgICB7Q0FURUdPUklFUy5tYXAoKGMpID0+IChcclxuICAgICAgICAgICAgICAgIDxvcHRpb24ga2V5PXtjfSB2YWx1ZT17Y30+XHJcbiAgICAgICAgICAgICAgICAgIHtjfVxyXG4gICAgICAgICAgICAgICAgPC9vcHRpb24+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvc2VsZWN0PlxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxicj48L2JyPlxyXG4gICAgICAgICAgPGxhYmVsPlxyXG4gICAgICAgICAgICBMb2NhdGlvblxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICB2YWx1ZT17bG9jYXRpb259XHJcbiAgICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRMb2NhdGlvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8UGhvdG9VcGxvYWQga2V5PXtyZWZyZXNoS2V5fSBvblVwbG9hZD17c2V0SW1hZ2V9IC8+XHJcbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17c3VibWl0dGluZyB8fCAhaW1hZ2V9PlxyXG4gICAgICAgICAgICB7c3VibWl0dGluZyA/IFwiQ3JlYXRpbmcuLi5cIiA6IFwiQ3JlYXRlIGxpc3RpbmdcIn1cclxuICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgICA8YnI+PC9icj5cclxuXHJcbiAgICAgICAge2Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiPntlcnJvcn08L3A+fVxyXG4gICAgICAgIHttZXNzYWdlICYmIDxwIHJvbGU9XCJzdGF0dXNcIj57bWVzc2FnZX08L3A+fVxyXG4gICAgICA8L3NlY3Rpb24+XHJcblxyXG4gICAgICA8UG9zdHNMaXN0IHJlZnJlc2hLZXk9e3JlZnJlc2hLZXl9IC8+XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKTtcclxufVxyXG4iXX0=