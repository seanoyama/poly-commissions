import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/MessagesPage.tsx");const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import "/src/App.css";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=2b466928";
import MessagesList from "/src/MessagesList.tsx";
import MessageForm from "/src/MessageForm.tsx";
import { useAuth } from "/src/SessionContext.tsx";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/MessagesPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function MessagesPage() {
	_s();
	const { user } = useAuth();
	const { chat_id } = useParams();
	const [refreshKey, setRefreshKey] = useState(0);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "main",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", { children: "Messages" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MessagesList, {
				chat_id,
				refreshKey
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV(MessageForm, {
				chat_id,
				user_id: user?.id,
				onMessageSent: () => setRefreshKey((key) => key + 1)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
}
_s(MessagesPage, "LYezC+ux7QwMJqSwjCCZYmY05Kc=", false, function() {
	return [useAuth, useParams];
});
_c = MessagesPage;
var _c;
$RefreshReg$(_c, "MessagesPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/MessagesPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/MessagesPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/MessagesPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/pages/MessagesPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMsaUJBQWlCO0FBQzFCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8saUJBQWlCO0FBQ3hCLFNBQVMsZUFBZTs7OztBQUV4QixlQUFlLFNBQVMsZUFBZTs7Q0FDckMsTUFBTSxFQUFFLFNBQVMsUUFBUTtDQUN6QixNQUFNLEVBQUUsWUFBWSxVQUFVO0NBQzlCLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUM7Q0FFOUMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsTUFBRCxZQUFJLFdBQVk7Ozs7O0dBQ2hCLHdCQUFDLGNBQUQ7SUFBdUI7SUFBcUI7R0FBYTs7Ozs7R0FDekQsd0JBQUMsYUFBRDtJQUNXO0lBQ1QsU0FBUyxNQUFNO0lBQ2YscUJBQXFCLGVBQWUsUUFBUSxNQUFNLENBQUM7R0FDcEQ7Ozs7O0VBQ0U7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIk1lc3NhZ2VzUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vQXBwLmNzc1wiO1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgTWVzc2FnZXNMaXN0IGZyb20gXCIuLi9NZXNzYWdlc0xpc3RcIjtcclxuaW1wb3J0IE1lc3NhZ2VGb3JtIGZyb20gXCIuLi9NZXNzYWdlRm9ybVwiO1xyXG5pbXBvcnQgeyB1c2VBdXRoIH0gZnJvbSBcIi4uL1Nlc3Npb25Db250ZXh0XCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNZXNzYWdlc1BhZ2UoKSB7XHJcbiAgY29uc3QgeyB1c2VyIH0gPSB1c2VBdXRoKCk7XHJcbiAgY29uc3QgeyBjaGF0X2lkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBbcmVmcmVzaEtleSwgc2V0UmVmcmVzaEtleV0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwibWFpblwiPlxyXG4gICAgICA8aDE+TWVzc2FnZXM8L2gxPlxyXG4gICAgICA8TWVzc2FnZXNMaXN0IGNoYXRfaWQ9e2NoYXRfaWR9IHJlZnJlc2hLZXk9e3JlZnJlc2hLZXl9IC8+XHJcbiAgICAgIDxNZXNzYWdlRm9ybVxyXG4gICAgICAgIGNoYXRfaWQ9e2NoYXRfaWR9XHJcbiAgICAgICAgdXNlcl9pZD17dXNlcj8uaWR9XHJcbiAgICAgICAgb25NZXNzYWdlU2VudD17KCkgPT4gc2V0UmVmcmVzaEtleSgoa2V5KSA9PiBrZXkgKyAxKX1cclxuICAgICAgLz5cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl19