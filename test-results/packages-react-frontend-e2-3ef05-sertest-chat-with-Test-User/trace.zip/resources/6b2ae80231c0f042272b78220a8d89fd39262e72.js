import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/MessagesList.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import "/src/App.css";
import { UserName } from "/src/services/userData.tsx";
import { ReadableDate } from "/src/services/dateConverter.tsx";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessagesList.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function MessagesList(props) {
	_s();
	const chat_id = props.chat_id;
	const refreshKey = props.refreshKey;
	// url variable in case we go #public
	// let API_URL = "http://localhost:8000";
	const [messages, setMessages] = useState([]);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(true);
	useEffect(() => {
		let url = `${API_URL}/messages`;
		if (chat_id) {
			url += "?chat_id=" + chat_id;
		}
		setLoading(true);
		setError("");
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load messages");
			}
			return response.json();
		}).then((data) => {
			setMessages(data);
		}).catch((err) => {
			setError(err.message);
		}).finally(() => {
			setLoading(false);
		});
	}, [chat_id, refreshKey]);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		error && /* @__PURE__ */ _jsxDEV("p", {
			className: "error-message",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 56,
			columnNumber: 17
		}, this),
		loading && messages.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "Loading..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 57,
			columnNumber: 44
		}, this),
		!loading && !error && messages.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No messages yet." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 59,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "posts-list-grid",
			children: messages.map((message) => /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV(ReadableDate, { iso_string: message.created_at }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 13
				}, this),
				" ",
				/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 65,
					columnNumber: 63
				}, this),
				/* @__PURE__ */ _jsxDEV(UserName, { uuid: message.user_id }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 13
				}, this),
				" :",
				/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 67,
					columnNumber: 13
				}, this),
				message.body,
				/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 69,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 70,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 55,
		columnNumber: 5
	}, this);
}
_s(MessagesList, "3hdJmtiSBU6ScAu0B7t9etlW2Ns=");
_c = MessagesList;
var _c;
$RefreshReg$(_c, "MessagesList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/MessagesList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessagesList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessagesList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/MessagesList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPO0FBQ1AsU0FBUSxnQkFBZTtBQUN2QixTQUFRLG9CQUFtQjtBQUMzQixTQUFRLGVBQWM7Ozs7QUFZdEIsZUFBZSxTQUFTLGFBQWEsT0FBWTs7Q0FDL0MsTUFBTSxVQUFVLE1BQU07Q0FDdEIsTUFBTSxhQUFhLE1BQU07OztDQUl6QixNQUFNLENBQUMsVUFBVSxlQUFlLFNBQW9CLENBQUMsQ0FBQztDQUN0RCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlCLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FFM0MsZ0JBQWdCO0VBQ2QsSUFBSSxNQUFNLEdBQUcsUUFBUTtFQUNyQixJQUFJLFNBQVM7R0FDWCxPQUFPLGNBQVk7RUFDckI7RUFFQSxXQUFXLElBQUk7RUFDZixTQUFTLEVBQUU7RUFFWCxNQUFNLEdBQUcsQ0FBQyxDQUNQLE1BQU0sYUFBYTtHQUNsQixJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLHlCQUF5QjtHQUMzQztHQUNBLE9BQU8sU0FBUyxLQUFLO0VBQ3ZCLENBQUMsQ0FBQyxDQUNELE1BQU0sU0FBUztHQUNkLFlBQVksSUFBSTtFQUNsQixDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQWU7R0FDckIsU0FBUyxJQUFJLE9BQU87RUFDdEIsQ0FBQyxDQUFDLENBQ0QsY0FBYztHQUNiLFdBQVcsS0FBSztFQUNsQixDQUFDO0NBQ0wsR0FBRyxDQUFDLFNBQVMsVUFBVSxDQUFDO0NBRXhCLE9BQ0Usd0JBQUMsT0FBRDtFQUNHLFNBQVMsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBaUI7RUFBUzs7Ozs7RUFDaEQsV0FBVyxTQUFTLFdBQVcsS0FBSyx3QkFBQyxLQUFELFlBQUcsYUFBYTs7Ozs7RUFDcEQsQ0FBQyxXQUFXLENBQUMsU0FBUyxTQUFTLFdBQVcsS0FDekMsd0JBQUMsS0FBRCxZQUFHLG1CQUFtQjs7Ozs7RUFHeEIsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFDaEIsU0FBUyxLQUFLLFlBQ2Isd0JBQUMsT0FBRDtJQUNFLHdCQUFDLGNBQUQsRUFBYyxZQUFhLFFBQVEsV0FBYTs7Ozs7SUFBQztJQUFDLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7SUFDMUQsd0JBQUMsVUFBRCxFQUFVLE1BQU8sUUFBUSxRQUFXOzs7OztJQUFDO0lBQ3JDLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7SUFDTixRQUFRO0lBQ1osd0JBQUMsTUFBRCxDQUFROzs7OztJQUNSLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7R0FDSDs7OztXQUVOO0VBQ007Ozs7O0NBQ047Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTWVzc2FnZXNMaXN0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xyXG5pbXBvcnQge1VzZXJOYW1lfSBmcm9tIFwiLi9zZXJ2aWNlcy91c2VyRGF0YVwiO1xyXG5pbXBvcnQge1JlYWRhYmxlRGF0ZX0gZnJvbSBcIi4vc2VydmljZXMvZGF0ZUNvbnZlcnRlclwiO1xyXG5pbXBvcnQge0FQSV9VUkx9IGZyb20gXCIuL2NvbnN0YW50c1wiXHJcblxyXG50eXBlIE1lc3NhZ2UgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxuICBjaGF0X2lkOiBzdHJpbmc7XHJcbiAgdXNlcl9pZDogbnVtYmVyO1xyXG4gIGJvZHk6IHN0cmluZztcclxuICBpbWFnZXM6IHN0cmluZztcclxuICByZXBseV90bzogc3RyaW5nO1xyXG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE1lc3NhZ2VzTGlzdChwcm9wczogYW55KSB7XHJcbiAgY29uc3QgY2hhdF9pZCA9IHByb3BzLmNoYXRfaWQ7XHJcbiAgY29uc3QgcmVmcmVzaEtleSA9IHByb3BzLnJlZnJlc2hLZXk7XHJcbiAgLy8gdXJsIHZhcmlhYmxlIGluIGNhc2Ugd2UgZ28gI3B1YmxpY1xyXG4gIC8vIGxldCBBUElfVVJMID0gXCJodHRwOi8vbG9jYWxob3N0OjgwMDBcIjtcclxuICBcclxuICBjb25zdCBbbWVzc2FnZXMsIHNldE1lc3NhZ2VzXSA9IHVzZVN0YXRlPE1lc3NhZ2VbXT4oW10pO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCB1cmwgPSBgJHtBUElfVVJMfS9tZXNzYWdlc2A7XHJcbiAgICBpZiAoY2hhdF9pZCkge1xyXG4gICAgICB1cmwgKz0gXCI/Y2hhdF9pZD1cIitjaGF0X2lkO1xyXG4gICAgfVxyXG5cclxuICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcbiAgICBzZXRFcnJvcihcIlwiKTtcclxuXHJcbiAgICBmZXRjaCh1cmwpXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBsb2FkIG1lc3NhZ2VzXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuanNvbigpIGFzIFByb21pc2U8TWVzc2FnZVtdPjtcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBzZXRNZXNzYWdlcyhkYXRhKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnI6IEVycm9yKSA9PiB7XHJcbiAgICAgICAgc2V0RXJyb3IoZXJyLm1lc3NhZ2UpO1xyXG4gICAgICB9KVxyXG4gICAgICAuZmluYWxseSgoKSA9PiB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH0pO1xyXG4gIH0sIFtjaGF0X2lkLCByZWZyZXNoS2V5XSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2PlxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3ItbWVzc2FnZVwiPntlcnJvcn08L3A+fVxyXG4gICAgICB7bG9hZGluZyAmJiBtZXNzYWdlcy5sZW5ndGggPT09IDAgJiYgPHA+TG9hZGluZy4uLjwvcD59XHJcbiAgICAgIHshbG9hZGluZyAmJiAhZXJyb3IgJiYgbWVzc2FnZXMubGVuZ3RoID09PSAwICYmIChcclxuICAgICAgICA8cD5ObyBtZXNzYWdlcyB5ZXQuPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicG9zdHMtbGlzdC1ncmlkXCI+XHJcbiAgICAgICAge21lc3NhZ2VzLm1hcCgobWVzc2FnZSkgPT4gKFxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPFJlYWRhYmxlRGF0ZSBpc29fc3RyaW5nPXsobWVzc2FnZS5jcmVhdGVkX2F0KX0vPiA8YnI+PC9icj5cclxuICAgICAgICAgICAgPFVzZXJOYW1lIHV1aWQ9eyhtZXNzYWdlLnVzZXJfaWQpfSAvPiA6XHJcbiAgICAgICAgICAgIDxicj48L2JyPlxyXG4gICAgICAgICAgICAge21lc3NhZ2UuYm9keX1cclxuICAgICAgICAgIDxicj48L2JyPlxyXG4gICAgICAgICAgPGJyPjwvYnI+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICBcclxuICAgICAgICApKX1cclxuICAgICAgPC9zZWN0aW9uPlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=