import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/PostsList.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import "/src/App.css";
import Checkout from "/src/paypal.tsx";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/PostsList.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function PostsList(props) {
	_s();
	const user_id = props.user_id;
	const refreshKey = props.refreshKey;
	// url variable in case we go #public
	// let API_URL = "http://localhost:8000";
	const [posts, setPosts] = useState([]);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(true);
	useEffect(() => {
		let url = `${API_URL}/posts`;
		if (user_id) {
			url += `?user_id=${encodeURIComponent(user_id)}`;
		}
		setLoading(true);
		setError("");
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load posts");
			}
			return response.json();
		}).then((data) => {
			setPosts(data);
		}).catch((err) => {
			setError(err.message);
		}).finally(() => {
			setLoading(false);
		});
	}, [user_id, refreshKey]);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "posts-lists",
		children: [
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error-message",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 53,
				columnNumber: 17
			}, this),
			loading && posts.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "Loading..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 41
			}, this),
			!loading && !error && posts.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No posts yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("section", {
				className: "posts-list-grid",
				children: posts.map((post) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("article", {
					className: "posts-list-card",
					children: [/* @__PURE__ */ _jsxDEV("img", {
						className: "posts-list-image",
						src: post.images[0],
						alt: post.title
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 63,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "posts-list-info",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: ["$", post.price] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 70,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "posts-list-title",
								children: post.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 71,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "posts-list-details",
								children: [
									post.category,
									" · ",
									post.location
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 72,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("a", {
								href: `http://localhost:5173/posts/${post.id}`,
								children: "View More"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV(Checkout, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 80,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 15
					}, this)]
				}, post.id, true, {
					fileName: _jsxFileName,
					lineNumber: 62,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 83,
					columnNumber: 13
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 5
	}, this);
}
_s(PostsList, "zt0j3PaC8FqH/qsgLRLfyLzQNps=");
_c = PostsList;
var _c;
$RefreshReg$(_c, "PostsList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/PostsList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/PostsList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/PostsList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/PostsList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPO0FBQ1AsT0FBTyxjQUFjO0FBQ3JCLFNBQVMsZUFBZTs7OztBQVV4QixlQUFlLFNBQVMsVUFBVSxPQUFZOztDQUM1QyxNQUFNLFVBQVUsTUFBTTtDQUN0QixNQUFNLGFBQWEsTUFBTTs7O0NBSXpCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBaUIsQ0FBQyxDQUFDO0NBQzdDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBaUIsRUFBRTtDQUM3QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUUzQyxnQkFBZ0I7RUFDZCxJQUFJLE1BQU0sR0FBRyxRQUFRO0VBQ3JCLElBQUksU0FBUztHQUNYLE9BQU8sWUFBWSxtQkFBbUIsT0FBTztFQUMvQztFQUVBLFdBQVcsSUFBSTtFQUNmLFNBQVMsRUFBRTtFQUVYLE1BQU0sR0FBRyxDQUFDLENBQ1AsTUFBTSxhQUFhO0dBQ2xCLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQU0sc0JBQXNCO0dBQ3hDO0dBQ0EsT0FBTyxTQUFTLEtBQUs7RUFDdkIsQ0FBQyxDQUFDLENBQ0QsTUFBTSxTQUFTO0dBQ2QsU0FBUyxJQUFJO0VBQ2YsQ0FBQyxDQUFDLENBQ0QsT0FBTyxRQUFlO0dBQ3JCLFNBQVMsSUFBSSxPQUFPO0VBQ3RCLENBQUMsQ0FBQyxDQUNELGNBQWM7R0FDYixXQUFXLEtBQUs7RUFDbEIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxTQUFTLFVBQVUsQ0FBQztDQUV4QixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0csU0FBUyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFpQjtHQUFTOzs7OztHQUNoRCxXQUFXLE1BQU0sV0FBVyxLQUFLLHdCQUFDLEtBQUQsWUFBRyxhQUFhOzs7OztHQUNqRCxDQUFDLFdBQVcsQ0FBQyxTQUFTLE1BQU0sV0FBVyxLQUN0Qyx3QkFBQyxLQUFELFlBQUcsZ0JBQWdCOzs7OztHQUdyQix3QkFBQyxXQUFEO0lBQVMsV0FBVTtjQUNoQixNQUFNLEtBQUssU0FDVix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBbkIsQ0FDRSx3QkFBQyxPQUFEO01BQ0UsV0FBVTtNQUNWLEtBQUssS0FBSyxPQUFPO01BQ2pCLEtBQUssS0FBSztLQUNYOzs7O2VBRUQsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWY7T0FDRSx3QkFBQyxNQUFELGFBQUksS0FBRSxLQUFLLEtBQVU7Ozs7O09BQ3JCLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFvQixLQUFLO09BQVM7Ozs7O09BQy9DLHdCQUFDLEtBQUQ7UUFBRyxXQUFVO2tCQUFiO1NBQ0csS0FBSztTQUFTO1NBQUksS0FBSztRQUN2Qjs7Ozs7O09BQ0gsd0JBQUMsS0FBRDtRQUNFLE1BQU0sK0JBQStCLEtBQUs7a0JBQU07T0FFL0M7Ozs7O09BRUgsd0JBQUMsVUFBRCxDQUFXOzs7OztNQUNSOzs7OzthQUNFO09BcEJpQyxLQUFLOzs7O1dBb0J0QyxHQUNULHdCQUFDLE1BQUQsQ0FBUTs7OztZQUNMOzs7O1lBQ047R0FDTTs7Ozs7RUFDRjs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUG9zdHNMaXN0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCBcIi4vQXBwLmNzc1wiO1xyXG5pbXBvcnQgQ2hlY2tvdXQgZnJvbSBcIi4vcGF5cGFsXCI7XHJcbmltcG9ydCB7IEFQSV9VUkwgfSBmcm9tIFwiLi9jb25zdGFudHNcIlxyXG5cclxudHlwZSBQb3N0ID0ge1xyXG4gIGlkOiBzdHJpbmc7XHJcbiAgdGl0bGU6IHN0cmluZztcclxuICBwcmljZTogbnVtYmVyO1xyXG4gIGNhdGVnb3J5OiBzdHJpbmc7XHJcbiAgbG9jYXRpb246IHN0cmluZztcclxuICBpbWFnZXM6IHN0cmluZztcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUG9zdHNMaXN0KHByb3BzOiBhbnkpIHtcclxuICBjb25zdCB1c2VyX2lkID0gcHJvcHMudXNlcl9pZDtcclxuICBjb25zdCByZWZyZXNoS2V5ID0gcHJvcHMucmVmcmVzaEtleTtcclxuICAvLyB1cmwgdmFyaWFibGUgaW4gY2FzZSB3ZSBnbyAjcHVibGljXHJcbiAgLy8gbGV0IEFQSV9VUkwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODAwMFwiO1xyXG5cclxuICBjb25zdCBbcG9zdHMsIHNldFBvc3RzXSA9IHVzZVN0YXRlPFBvc3RbXT4oW10pO1xyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGU8c3RyaW5nPihcIlwiKTtcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCB1cmwgPSBgJHtBUElfVVJMfS9wb3N0c2A7XHJcbiAgICBpZiAodXNlcl9pZCkge1xyXG4gICAgICB1cmwgKz0gYD91c2VyX2lkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KHVzZXJfaWQpfWA7XHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG5cclxuICAgIGZldGNoKHVybClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ291bGQgbm90IGxvYWQgcG9zdHNcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5qc29uKCkgYXMgUHJvbWlzZTxQb3N0W10+O1xyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgIHNldFBvc3RzKGRhdGEpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycjogRXJyb3IpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfSk7XHJcbiAgfSwgW3VzZXJfaWQsIHJlZnJlc2hLZXldKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvc3RzLWxpc3RzXCI+XHJcbiAgICAgIHtlcnJvciAmJiA8cCBjbGFzc05hbWU9XCJlcnJvci1tZXNzYWdlXCI+e2Vycm9yfTwvcD59XHJcbiAgICAgIHtsb2FkaW5nICYmIHBvc3RzLmxlbmd0aCA9PT0gMCAmJiA8cD5Mb2FkaW5nLi4uPC9wPn1cclxuICAgICAgeyFsb2FkaW5nICYmICFlcnJvciAmJiBwb3N0cy5sZW5ndGggPT09IDAgJiYgKFxyXG4gICAgICAgIDxwPk5vIHBvc3RzIHlldC48L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwb3N0cy1saXN0LWdyaWRcIj5cclxuICAgICAgICB7cG9zdHMubWFwKChwb3N0KSA9PiAoXHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJwb3N0cy1saXN0LWNhcmRcIiBrZXk9e3Bvc3QuaWR9PlxyXG4gICAgICAgICAgICAgIDxpbWdcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBvc3RzLWxpc3QtaW1hZ2VcIlxyXG4gICAgICAgICAgICAgICAgc3JjPXtwb3N0LmltYWdlc1swXX1cclxuICAgICAgICAgICAgICAgIGFsdD17cG9zdC50aXRsZX1cclxuICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3RzLWxpc3QtaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgPGgyPiR7cG9zdC5wcmljZX08L2gyPlxyXG4gICAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwicG9zdHMtbGlzdC10aXRsZVwiPntwb3N0LnRpdGxlfTwvcD5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInBvc3RzLWxpc3QtZGV0YWlsc1wiPlxyXG4gICAgICAgICAgICAgICAgICB7cG9zdC5jYXRlZ29yeX0gwrcge3Bvc3QubG9jYXRpb259XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgICAgICA8YVxyXG4gICAgICAgICAgICAgICAgICBocmVmPXtgaHR0cDovL2xvY2FsaG9zdDo1MTczL3Bvc3RzLyR7cG9zdC5pZH1gfT5cclxuICAgICAgICAgICAgICAgICAgVmlldyBNb3JlXHJcbiAgICAgICAgICAgICAgICA8L2E+XHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIDxDaGVja291dCAvPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgICAgIDxicj48L2JyPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgKSl9XHJcbiAgICAgIDwvc2VjdGlvbj5cclxuICAgIDwvc2VjdGlvbj5cclxuICApO1xyXG59XHJcbiJdfQ==