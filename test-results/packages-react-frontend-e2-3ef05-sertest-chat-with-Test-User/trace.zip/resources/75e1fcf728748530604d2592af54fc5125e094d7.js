import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/SessionContext.tsx");const createContext = __vite__cjsImport0_react["createContext"]; const useContext = __vite__cjsImport0_react["useContext"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import "/src/App.css";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SessionContext.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$(), _s2 = $RefreshSig$();
const AuthContext = createContext(undefined);
_c = AuthContext;
export function AuthProvider({ children }) {
	_s();
	const url = `${API_URL}/auth/`;
	const [session, setSession] = useState();
	useEffect(() => {
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load user");
			}
			return response.json();
		}).then((data) => {
			setSession(data.session);
		}).catch((err) => {
			console.log(err);
		});
	}, []);
	return /* @__PURE__ */ _jsxDEV(AuthContext.Provider, {
		value: {
			session,
			user: session?.user ?? null
		},
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_s(AuthProvider, "6i9JHLpHr8MIXgD97drXj6xyd14=");
_c2 = AuthProvider;
export function useAuth() {
	_s2();
	const context = useContext(AuthContext);
	if (!context) {
		throw new Error("useAuth must be used inside AuthProvider");
	}
	return context;
}
_s2(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c, _c2;
$RefreshReg$(_c, "AuthContext");
$RefreshReg$(_c2, "AuthProvider");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/SessionContext.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SessionContext.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SessionContext.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/SessionContext.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FDRSxlQUNBLFlBQ0EsV0FDQSxnQkFFSztBQUVQLE9BQU87QUFFUCxTQUFRLGVBQWM7Ozs7QUFPdEIsTUFBTSxjQUFjLGNBQ2xCLFNBQ0Y7O0FBRUEsT0FBTyxTQUFTLGFBQWEsRUFDM0IsWUFHQzs7Q0FHRCxNQUFNLE1BQU0sR0FBRyxRQUFRO0NBQ3ZCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBa0I7Q0FDaEQsZ0JBQWdCO0VBQ2QsTUFBTSxHQUFHLENBQUMsQ0FDUCxNQUFNLGFBQWE7R0FDbEIsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFBTSxxQkFBcUI7R0FDdkM7R0FFQSxPQUFPLFNBQVMsS0FBSztFQUN2QixDQUFDLENBQUMsQ0FDRCxNQUFNLFNBQVM7R0FDZCxXQUFXLEtBQUssT0FBTztFQUN6QixDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQWU7R0FDckIsUUFBUSxJQUFJLEdBQUc7RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsT0FDRSx3QkFBQyxZQUFZLFVBQWI7RUFDRSxPQUFPO0dBQ0k7R0FDVCxNQUFNLFNBQVMsUUFBUTtFQUN6QjtFQUNDO0NBQ21COzs7OztBQUUxQjs7O0FBRUEsT0FBTyxTQUFTLFVBQVU7O0NBQ3hCLE1BQU0sVUFBVSxXQUFXLFdBQVc7Q0FDdEMsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLElBQUksTUFBTSwwQ0FBMEM7Q0FDNUQ7Q0FDQSxPQUFPO0FBQ1QiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU2Vzc2lvbkNvbnRleHQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7XHJcbiAgY3JlYXRlQ29udGV4dCxcclxuICB1c2VDb250ZXh0LFxyXG4gIHVzZUVmZmVjdCxcclxuICB1c2VTdGF0ZSxcclxuICB0eXBlIFJlYWN0Tm9kZVxyXG59IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IFwiLi9BcHAuY3NzXCI7XHJcbmltcG9ydCB0eXBlIHsgU2Vzc2lvbiwgVXNlciB9IGZyb20gXCJAc3VwYWJhc2Uvc3VwYWJhc2UtanNcIjtcclxuaW1wb3J0IHtBUElfVVJMfSBmcm9tIFwiLi9jb25zdGFudHNcIlxyXG5cclxudHlwZSBBdXRoQ29udGV4dFZhbHVlID0ge1xyXG4gIHNlc3Npb246IFNlc3Npb24gfCB1bmRlZmluZWQ7XHJcbiAgdXNlcjogVXNlciB8IG51bGw7XHJcbn07XHJcblxyXG5jb25zdCBBdXRoQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQ8QXV0aENvbnRleHRWYWx1ZSB8IHVuZGVmaW5lZD4oXHJcbiAgdW5kZWZpbmVkXHJcbik7XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gQXV0aFByb3ZpZGVyKHtcclxuICBjaGlsZHJlblxyXG59OiB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufSkge1xyXG4gIHR5cGUgU2Vzc2lvblJlc3BvbnNlID0geyBzZXNzaW9uOiBTZXNzaW9uIH07XHJcblxyXG4gIGNvbnN0IHVybCA9IGAke0FQSV9VUkx9L2F1dGgvYDtcclxuICBjb25zdCBbc2Vzc2lvbiwgc2V0U2Vzc2lvbl0gPSB1c2VTdGF0ZTxTZXNzaW9uPigpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaCh1cmwpXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBsb2FkIHVzZXJcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuanNvbigpIGFzIFByb21pc2U8U2Vzc2lvblJlc3BvbnNlPjtcclxuICAgICAgfSlcclxuICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICBzZXRTZXNzaW9uKGRhdGEuc2Vzc2lvbik7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyOiBFcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgIH0pO1xyXG4gIH0sIFtdKTtcclxuICByZXR1cm4gKFxyXG4gICAgPEF1dGhDb250ZXh0LlByb3ZpZGVyXHJcbiAgICAgIHZhbHVlPXt7XHJcbiAgICAgICAgc2Vzc2lvbjogc2Vzc2lvbixcclxuICAgICAgICB1c2VyOiBzZXNzaW9uPy51c2VyID8/IG51bGxcclxuICAgICAgfX0+XHJcbiAgICAgIHtjaGlsZHJlbn1cclxuICAgIDwvQXV0aENvbnRleHQuUHJvdmlkZXI+XHJcbiAgKTtcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIHVzZUF1dGgoKSB7XHJcbiAgY29uc3QgY29udGV4dCA9IHVzZUNvbnRleHQoQXV0aENvbnRleHQpO1xyXG4gIGlmICghY29udGV4dCkge1xyXG4gICAgdGhyb3cgbmV3IEVycm9yKFwidXNlQXV0aCBtdXN0IGJlIHVzZWQgaW5zaWRlIEF1dGhQcm92aWRlclwiKTtcclxuICB9XHJcbiAgcmV0dXJuIGNvbnRleHQ7XHJcbn1cclxuIl19