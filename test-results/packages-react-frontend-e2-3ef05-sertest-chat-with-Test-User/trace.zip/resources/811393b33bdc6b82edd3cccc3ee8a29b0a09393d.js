import { r as __toESM, t as require_react } from "/node_modules/.vite/deps/react-mlDlaWW9.js?v=2b466928";
// ../../node_modules/@paypal/react-paypal-js/dist/esm/react-paypal-js.js
var import_react = /* @__PURE__ */ __toESM(require_react());
/*!
* react-paypal-js v10.6.1 (2026-10-23T18:33:08.669Z)
* Copyright 2020-present, PayPal, Inc. All rights reserved.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
* https://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
/**
* Enum for the SDK script resolve status,
*
* @enum {string}
*/
var SCRIPT_LOADING_STATE;
(function(SCRIPT_LOADING_STATE) {
	SCRIPT_LOADING_STATE["INITIAL"] = "initial";
	SCRIPT_LOADING_STATE["PENDING"] = "pending";
	SCRIPT_LOADING_STATE["REJECTED"] = "rejected";
	SCRIPT_LOADING_STATE["RESOLVED"] = "resolved";
})(SCRIPT_LOADING_STATE || (SCRIPT_LOADING_STATE = {}));
/**
* Enum for the PayPalScriptProvider context dispatch actions
*
* @enum {string}
*/
var DISPATCH_ACTION;
(function(DISPATCH_ACTION) {
	DISPATCH_ACTION["LOADING_STATUS"] = "setLoadingStatus";
	DISPATCH_ACTION["RESET_OPTIONS"] = "resetOptions";
	DISPATCH_ACTION["SET_BRAINTREE_INSTANCE"] = "braintreeInstance";
})(DISPATCH_ACTION || (DISPATCH_ACTION = {}));
/**
* Enum for all the available hosted fields
*
* @enum {string}
*/
var PAYPAL_HOSTED_FIELDS_TYPES;
(function(PAYPAL_HOSTED_FIELDS_TYPES) {
	PAYPAL_HOSTED_FIELDS_TYPES["NUMBER"] = "number";
	PAYPAL_HOSTED_FIELDS_TYPES["CVV"] = "cvv";
	PAYPAL_HOSTED_FIELDS_TYPES["EXPIRATION_DATE"] = "expirationDate";
	PAYPAL_HOSTED_FIELDS_TYPES["EXPIRATION_MONTH"] = "expirationMonth";
	PAYPAL_HOSTED_FIELDS_TYPES["EXPIRATION_YEAR"] = "expirationYear";
	PAYPAL_HOSTED_FIELDS_TYPES["POSTAL_CODE"] = "postalCode";
})(PAYPAL_HOSTED_FIELDS_TYPES || (PAYPAL_HOSTED_FIELDS_TYPES = {}));
var extendStatics = function(d, b) {
	extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d, b) {
		d.__proto__ = b;
	} || function(d, b) {
		for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p];
	};
	return extendStatics(d, b);
};
function __extends(d, b) {
	if (typeof b !== "function" && b !== null) throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
	extendStatics(d, b);
	function __() {
		this.constructor = d;
	}
	d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
	__assign = Object.assign || function __assign(t) {
		for (var s, i = 1, n = arguments.length; i < n; i++) {
			s = arguments[i];
			for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
		}
		return t;
	};
	return __assign.apply(this, arguments);
};
function __rest$1(s, e) {
	var t = {};
	for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
	if (s != null && typeof Object.getOwnPropertySymbols === "function") {
		for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
	}
	return t;
}
function __spreadArray(to, from, pack) {
	if (pack || arguments.length === 2) {
		for (var i = 0, l = from.length, ar; i < l; i++) if (ar || !(i in from)) {
			if (!ar) ar = Array.prototype.slice.call(from, 0, i);
			ar[i] = from[i];
		}
	}
	return to.concat(ar || Array.prototype.slice.call(from));
}
/*********************************************
* Common reference to the script identifier *
*********************************************/
var SCRIPT_ID = "data-react-paypal-script-id";
var SDK_SETTINGS = {
	DATA_CLIENT_TOKEN: "dataClientToken",
	DATA_JS_SDK_LIBRARY: "dataJsSdkLibrary",
	DATA_LIBRARY_VALUE: "react-paypal-js",
	DATA_NAMESPACE: "dataNamespace",
	DATA_SDK_INTEGRATION_SOURCE: "dataSdkIntegrationSource",
	DATA_USER_ID_TOKEN: "dataUserIdToken"
};
var LOAD_SCRIPT_ERROR = "Failed to load the PayPal JS SDK script.";
/****************************
* Braintree error messages *
****************************/
var EMPTY_BRAINTREE_AUTHORIZATION_ERROR_MESSAGE = "Invalid authorization data. Use dataClientToken or dataUserIdToken to authorize.";
var braintreeVersion = "3.117.0";
var BRAINTREE_SOURCE = "https://js.braintreegateway.com/web/".concat(braintreeVersion, "/js/client.min.js");
var BRAINTREE_PAYPAL_CHECKOUT_SOURCE = "https://js.braintreegateway.com/web/".concat(braintreeVersion, "/js/paypal-checkout.min.js");
/*********************
* PayPal namespaces *
*********************/
var DEFAULT_PAYPAL_NAMESPACE = "paypal";
var DEFAULT_BRAINTREE_NAMESPACE = "braintree";
/*****************
* Hosted Fields *
*****************/
var HOSTED_FIELDS_CHILDREN_ERROR = "To use HostedFields you must use it with at least 3 children with types: [number, cvv, expirationDate] includes";
var HOSTED_FIELDS_DUPLICATE_CHILDREN_ERROR = "Cannot use duplicate HostedFields as children";
/*******************
* Script Provider *
*******************/
var SCRIPT_PROVIDER_REDUCER_ERROR = "usePayPalScriptReducer must be used within a PayPalScriptProvider";
var CARD_FIELDS_DUPLICATE_CHILDREN_ERROR = "Cannot use duplicate CardFields as children";
var CARD_FIELDS_CONTEXT_ERROR = "Individual CardFields must be rendered inside the PayPalCardFieldsProvider";
/**
* Get the namespace from the window in the browser
* this is useful to get the paypal object from window
* after load PayPal SDK script
*
* @param namespace the name space to return
* @returns the namespace if exists or undefined otherwise
*/
function getPayPalWindowNamespace$1(namespace) {
	if (namespace === void 0) namespace = DEFAULT_PAYPAL_NAMESPACE;
	return window[namespace];
}
/**
* Get a namespace from the window in the browser
* this is useful to get the braintree from window
* after load Braintree script
*
* @param namespace the name space to return
* @returns the namespace if exists or undefined otherwise
*/
function getBraintreeWindowNamespace(namespace) {
	if (namespace === void 0) namespace = DEFAULT_BRAINTREE_NAMESPACE;
	return window[namespace];
}
/**
* Creates a string hash code based on the string argument
*
* @param str the source input string to hash
* @returns string hash code
*/
function hashStr(str) {
	var hash = "";
	for (var i = 0; i < str.length; i++) {
		var total = str[i].charCodeAt(0) * i;
		if (str[i + 1]) total += str[i + 1].charCodeAt(0) * (i - 1);
		hash += String.fromCharCode(97 + Math.abs(total) % 26);
	}
	return hash;
}
/**
* Read an own property from an options object, ignoring any value inherited
* from the prototype chain, to prevent prototype-polluted values (CWE-1321)
* from being silently accepted when the caller's options object omits the
* property. Local copy of the equivalent helper in @paypal/paypal-js's
* src/utils.ts, which isn't exported from that package's public entry points.
*/
function getOwnProperty$1(options, key) {
	return Object.prototype.hasOwnProperty.call(options, key) ? options[key] : void 0;
}
function generateErrorMessage(_a) {
	var reactComponentName = _a.reactComponentName, sdkComponentKey = _a.sdkComponentKey, _b = _a.sdkRequestedComponents, sdkRequestedComponents = _b === void 0 ? "" : _b, _c = _a.sdkDataNamespace, sdkDataNamespace = _c === void 0 ? DEFAULT_PAYPAL_NAMESPACE : _c;
	var requiredOptionCapitalized = sdkComponentKey.charAt(0).toUpperCase().concat(sdkComponentKey.substring(1));
	var errorMessage = "Unable to render <".concat(reactComponentName, " /> because window.").concat(sdkDataNamespace, ".").concat(requiredOptionCapitalized, " is undefined.");
	var requestedComponents = typeof sdkRequestedComponents === "string" ? sdkRequestedComponents : sdkRequestedComponents.join(",");
	if (!requestedComponents.includes(sdkComponentKey)) {
		var expectedComponents = [requestedComponents, sdkComponentKey].filter(Boolean).join();
		errorMessage += "\nTo fix the issue, add '".concat(sdkComponentKey, "' to the list of components passed to the parent PayPalScriptProvider:") + "\n`<PayPalScriptProvider options={{ components: '".concat(expectedComponents, "'}}>`.");
	}
	return errorMessage;
}
/**
* Generate a new random identifier for react-paypal-js
*
* @returns the {@code string} containing the random library name
*/
function getScriptID(options) {
	var _a = options, _b = SCRIPT_ID;
	_a[_b];
	var paypalScriptOptions = __rest$1(_a, [_b + ""]);
	return "react-paypal-js-".concat(hashStr(JSON.stringify(paypalScriptOptions)));
}
/**
* Destroy the PayPal SDK from the document page
*
* @param reactPayPalScriptID the script identifier
*/
function destroySDKScript(reactPayPalScriptID) {
	var scriptNode = self.document.querySelector("script[".concat(SCRIPT_ID, "=\"").concat(reactPayPalScriptID, "\"]"));
	if (scriptNode === null || scriptNode === void 0 ? void 0 : scriptNode.parentNode) scriptNode.parentNode.removeChild(scriptNode);
}
/**
* Reducer function to handle complex state changes on the context
*
* @param state  the current state on the context object
* @param action the action to be executed on the previous state
* @returns a the same state if the action wasn't found, or a new state otherwise
*/
function scriptReducer(state, action) {
	var _a, _b;
	switch (action.type) {
		case DISPATCH_ACTION.LOADING_STATUS:
			if (typeof action.value === "object") return __assign(__assign({}, state), {
				loadingStatus: action.value.state,
				loadingStatusErrorMessage: action.value.message
			});
			return __assign(__assign({}, state), { loadingStatus: action.value });
		case DISPATCH_ACTION.RESET_OPTIONS:
			destroySDKScript(state.options[SCRIPT_ID]);
			return __assign(__assign({}, state), {
				loadingStatus: SCRIPT_LOADING_STATE.PENDING,
				options: __assign(__assign((_a = {}, _a[SDK_SETTINGS.DATA_SDK_INTEGRATION_SOURCE] = SDK_SETTINGS.DATA_LIBRARY_VALUE, _a), action.value), (_b = {}, _b[SCRIPT_ID] = "".concat(getScriptID(action.value)), _b))
			});
		case DISPATCH_ACTION.SET_BRAINTREE_INSTANCE: return __assign(__assign({}, state), { braintreePayPalCheckoutInstance: action.value });
		default: return state;
	}
}
var ScriptContext = (0, import_react.createContext)(null);
/**
* Check if the context is valid and ready to dispatch actions.
*
* @param scriptContext the result of connecting to the context provider
* @returns strict context avoiding null values in the type
*/
function validateReducer(scriptContext) {
	if (typeof (scriptContext === null || scriptContext === void 0 ? void 0 : scriptContext.dispatch) === "function" && scriptContext.dispatch.length !== 0) return scriptContext;
	throw new Error(SCRIPT_PROVIDER_REDUCER_ERROR);
}
/**
* Check if the dataClientToken or the dataUserIdToken are
* set in the options of the context.
* @type dataClientToken is use to pass a client token
* @type dataUserIdToken is use to pass a client tokenization key
*
* @param scriptContext the result of connecting to the context provider
* @throws an {@link Error} if both dataClientToken and the dataUserIdToken keys are null or undefined
* @returns strict context if one of the keys are defined
*/
var validateBraintreeAuthorizationData = function(scriptContext) {
	var _a, _b;
	if (!((_a = scriptContext === null || scriptContext === void 0 ? void 0 : scriptContext.options) === null || _a === void 0 ? void 0 : _a[SDK_SETTINGS.DATA_CLIENT_TOKEN]) && !((_b = scriptContext === null || scriptContext === void 0 ? void 0 : scriptContext.options) === null || _b === void 0 ? void 0 : _b[SDK_SETTINGS.DATA_USER_ID_TOKEN])) throw new Error(EMPTY_BRAINTREE_AUTHORIZATION_ERROR_MESSAGE);
	return scriptContext;
};
/**
* Custom hook to get access to the Script context and
* dispatch actions to modify the state on the {@link ScriptProvider} component
*
* @returns a tuple containing the state of the context and
* a dispatch function to modify the state
*/
function usePayPalScriptReducer() {
	var scriptContext = validateReducer((0, import_react.useContext)(ScriptContext));
	return [__assign(__assign({}, scriptContext), {
		isInitial: scriptContext.loadingStatus === SCRIPT_LOADING_STATE.INITIAL,
		isPending: scriptContext.loadingStatus === SCRIPT_LOADING_STATE.PENDING,
		isResolved: scriptContext.loadingStatus === SCRIPT_LOADING_STATE.RESOLVED,
		isRejected: scriptContext.loadingStatus === SCRIPT_LOADING_STATE.REJECTED
	}), scriptContext.dispatch];
}
/**
* Custom hook to get access to the ScriptProvider context
*
* @returns the latest state of the context
*/
function useScriptProviderContext() {
	var scriptContext = validateBraintreeAuthorizationData(validateReducer((0, import_react.useContext)(ScriptContext)));
	return [scriptContext, scriptContext.dispatch];
}
var PayPalHostedFieldsContext = (0, import_react.createContext)({});
/**
* Custom hook to get access to the PayPal Hosted Fields instance.
* The instance represent the returned object after the render process
* With this object a user can submit the fields and dynamically modify the cards
*
* @returns the hosted fields instance if is available in the component
*/
function usePayPalHostedFields() {
	return (0, import_react.useContext)(PayPalHostedFieldsContext);
}
/**
* `useProxyProps` can be used to maintain a reference to an updated props, without that change triggering
* another re-render. This is useful if, for example, some props should be passed through a parent component to
* a child function that contains code that needs the most up-to-date-reference, without causing the parent to
* rerender.
*/
function useProxyProps(props) {
	var proxyRef = (0, import_react.useRef)(new Proxy({}, { get: function(target, prop, receiver) {
		/**
		*
		* If target[prop] is a function, return a function that accesses
		* this function off the target object. We can mutate the target with
		* new copies of this function without having to re-render the
		* SDK components to pass new callbacks.
		*
		* */
		if (typeof target[prop] === "function") return function() {
			var args = [];
			for (var _i = 0; _i < arguments.length; _i++) args[_i] = arguments[_i];
			return target[prop].apply(target, args);
		};
		return Reflect.get(target, prop, receiver);
	} }));
	proxyRef.current = Object.assign(proxyRef.current, props);
	return proxyRef.current;
}
var PayPalButtonsErrorBoundary = function(_super) {
	__extends(PayPalButtonsErrorBoundary, _super);
	function PayPalButtonsErrorBoundary(props) {
		var _this = _super.call(this, props) || this;
		_this.state = { hasError: false };
		return _this;
	}
	PayPalButtonsErrorBoundary.getDerivedStateFromError = function() {
		return { hasError: true };
	};
	PayPalButtonsErrorBoundary.prototype.componentDidCatch = function(error, errorInfo) {
		console.error("Error in PayPalButtons component:", error, errorInfo);
		if (typeof this.props.onError === "function") this.props.onError({
			message: error.message,
			name: error.name,
			stack: error.stack,
			componentStack: errorInfo.componentStack
		});
	};
	PayPalButtonsErrorBoundary.prototype.render = function() {
		if (this.state.hasError) return null;
		return this.props.children;
	};
	return PayPalButtonsErrorBoundary;
}(import_react.Component);
/**
The inner component that renders the PayPal buttons. This component is wrapped in an error boundary to catch and handle any errors that may occur during rendering or interaction with the PayPal buttons.
*/
var PayPalButtonsInner = function(_a) {
	var _b;
	var _c = _a.className, className = _c === void 0 ? "" : _c, _d = _a.disabled, disabled = _d === void 0 ? false : _d, children = _a.children, _e = _a.forceReRender, forceReRender = _e === void 0 ? [] : _e, buttonProps = __rest$1(_a, [
		"className",
		"disabled",
		"children",
		"forceReRender"
	]);
	var isDisabledStyle = disabled ? { opacity: .38 } : {};
	var classNames = "".concat(className, " ").concat(disabled ? "paypal-buttons-disabled" : "").trim();
	var buttonsContainerRef = (0, import_react.useRef)(null);
	var buttons = (0, import_react.useRef)(null);
	var proxyProps = useProxyProps(buttonProps);
	var _f = usePayPalScriptReducer()[0], isResolved = _f.isResolved, options = _f.options;
	var _g = (0, import_react.useState)(null), initActions = _g[0], setInitActions = _g[1];
	var _h = (0, import_react.useState)(true), isEligible = _h[0], setIsEligible = _h[1];
	var setErrorState = (0, import_react.useState)(null)[1];
	function closeButtonsComponent() {
		if (buttons.current !== null) buttons.current.close().catch(function() {});
	}
	if ((_b = buttons.current) === null || _b === void 0 ? void 0 : _b.updateProps) buttons.current.updateProps({ message: buttonProps.message });
	(0, import_react.useEffect)(function() {
		if (isResolved === false) return closeButtonsComponent;
		var paypalWindowNamespace = getPayPalWindowNamespace$1(getOwnProperty$1(options, "dataNamespace"));
		if (paypalWindowNamespace === void 0 || paypalWindowNamespace.Buttons === void 0) {
			setErrorState(function() {
				throw new Error(generateErrorMessage({
					reactComponentName: PayPalButtons.displayName,
					sdkComponentKey: "buttons",
					sdkRequestedComponents: options.components,
					sdkDataNamespace: getOwnProperty$1(options, "dataNamespace")
				}));
			});
			return closeButtonsComponent;
		}
		var decoratedOnInit = function(data, actions) {
			setInitActions(actions);
			if (typeof buttonProps.onInit === "function") buttonProps.onInit(data, actions);
		};
		try {
			buttons.current = paypalWindowNamespace.Buttons(__assign(__assign({}, proxyProps), { onInit: decoratedOnInit }));
		} catch (err) {
			return setErrorState(function() {
				throw new Error("Failed to render <PayPalButtons /> component. Failed to initialize:  ".concat(err));
			});
		}
		if (buttons.current.isEligible() === false) {
			setIsEligible(false);
			return closeButtonsComponent;
		}
		if (!buttonsContainerRef.current) return closeButtonsComponent;
		buttons.current.render(buttonsContainerRef.current).catch(function(err) {
			if (buttonsContainerRef.current === null || buttonsContainerRef.current.children.length === 0) return;
			setErrorState(function() {
				throw new Error("Failed to render <PayPalButtons /> component. ".concat(err));
			});
		});
		return closeButtonsComponent;
	}, __spreadArray(__spreadArray([isResolved], forceReRender, true), [buttonProps.fundingSource], false));
	(0, import_react.useEffect)(function() {
		if (initActions === null) return;
		if (disabled === true) initActions.disable().catch(function() {});
		else initActions.enable().catch(function() {});
	}, [disabled, initActions]);
	return import_react.createElement(import_react.Fragment, null, isEligible ? import_react.createElement("div", {
		ref: buttonsContainerRef,
		style: isDisabledStyle,
		className: classNames
	}) : children);
};
PayPalButtonsInner.displayName = "PayPalButtons";
/**
This `<PayPalButtons />` component supports rendering [buttons](https://developer.paypal.com/docs/business/javascript-sdk/javascript-sdk-reference/#buttons) for PayPal, Venmo, and alternative payment methods.
It relies on the `<PayPalScriptProvider />` parent component for managing state related to loading the JS SDK script.
*/
var PayPalButtons = function(props) {
	return import_react.createElement(PayPalButtonsErrorBoundary, { onError: props.onError }, import_react.createElement(PayPalButtonsInner, __assign({}, props)));
};
PayPalButtons.displayName = "PayPalButtons";
function __rest(s, e) {
	var t = {};
	for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
	if (s != null && typeof Object.getOwnPropertySymbols === "function") {
		for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
	}
	return t;
}
function findScript(url, attributes) {
	var currentScript = document.querySelector("script[src=\"".concat(url, "\"]"));
	if (currentScript === null) return null;
	var nextScript = createScriptElement(url, attributes);
	var currentScriptClone = currentScript.cloneNode();
	delete currentScriptClone.dataset.uidAuto;
	if (Object.keys(currentScriptClone.dataset).length !== Object.keys(nextScript.dataset).length) return null;
	var isExactMatch = true;
	Object.keys(currentScriptClone.dataset).forEach(function(key) {
		if (currentScriptClone.dataset[key] !== nextScript.dataset[key]) isExactMatch = false;
	});
	return isExactMatch ? currentScript : null;
}
function insertScriptElement(_a) {
	var url = _a.url, attributes = _a.attributes, onSuccess = _a.onSuccess, onError = _a.onError;
	var newScript = createScriptElement(url, attributes);
	newScript.onerror = onError;
	newScript.onload = onSuccess;
	document.head.insertBefore(newScript, document.head.firstElementChild);
}
function processOptions(options) {
	var customSdkBaseUrl = getOwnProperty(options, "sdkBaseUrl");
	var environment = getOwnProperty(options, "environment");
	options.environment;
	options.sdkBaseUrl;
	var rest = __rest(options, ["environment", "sdkBaseUrl"]);
	var sdkBaseUrl = customSdkBaseUrl || processSdkBaseUrl(environment);
	var optionsWithStringIndex = rest;
	var _a = Object.keys(optionsWithStringIndex).filter(function(key) {
		return typeof optionsWithStringIndex[key] !== "undefined" && optionsWithStringIndex[key] !== null && optionsWithStringIndex[key] !== "";
	}).reduce(function(accumulator, key) {
		var value = optionsWithStringIndex[key].toString();
		key = camelCaseToKebabCase(key);
		if (key.substring(0, 4) === "data" || key === "crossorigin") accumulator.attributes[key] = value;
		else accumulator.queryParams[key] = value;
		return accumulator;
	}, {
		queryParams: {},
		attributes: {}
	}), queryParams = _a.queryParams, attributes = _a.attributes;
	var merchantId = getOwnProperty(queryParams, "merchant-id");
	if (merchantId && merchantId.indexOf(",") !== -1) {
		attributes["data-merchant-id"] = merchantId;
		queryParams["merchant-id"] = "*";
	}
	return {
		url: "".concat(sdkBaseUrl, "?").concat(objectToQueryString(queryParams)),
		attributes
	};
}
function camelCaseToKebabCase(str) {
	var replacer = function(match, indexOfMatch) {
		return (indexOfMatch ? "-" : "") + match.toLowerCase();
	};
	return str.replace(/[A-Z]+(?![a-z])|[A-Z]/g, replacer);
}
function objectToQueryString(params) {
	var queryString = "";
	Object.keys(params).forEach(function(key) {
		if (queryString.length !== 0) queryString += "&";
		queryString += key + "=" + params[key];
	});
	return queryString;
}
function processSdkBaseUrl(environment) {
	return environment === "sandbox" ? "https://www.sandbox.paypal.com/sdk/js" : "https://www.paypal.com/sdk/js";
}
function createScriptElement(url, attributes) {
	if (attributes === void 0) attributes = {};
	var newScript = document.createElement("script");
	newScript.src = url;
	Object.keys(attributes).forEach(function(key) {
		newScript.setAttribute(key, attributes[key]);
		if (key === "data-csp-nonce") newScript.setAttribute("nonce", attributes["data-csp-nonce"]);
	});
	return newScript;
}
function getOwnProperty(options, key) {
	return Object.prototype.hasOwnProperty.call(options, key) ? options[key] : void 0;
}
function loadScript(options, PromisePonyfill) {
	if (PromisePonyfill === void 0) PromisePonyfill = Promise;
	validateArguments(options, PromisePonyfill);
	if (typeof document === "undefined") return PromisePonyfill.resolve(null);
	var _a = processOptions(options), url = _a.url, attributes = _a.attributes;
	var namespace = getOwnProperty(attributes, "data-namespace") || "paypal";
	var existingWindowNamespace = getPayPalWindowNamespace(namespace);
	if (!getOwnProperty(attributes, "data-js-sdk-library")) attributes["data-js-sdk-library"] = "paypal-js";
	if (findScript(url, attributes) && existingWindowNamespace) return PromisePonyfill.resolve(existingWindowNamespace);
	return loadCustomScript({
		url,
		attributes
	}, PromisePonyfill).then(function() {
		var newWindowNamespace = getPayPalWindowNamespace(namespace);
		if (newWindowNamespace) return newWindowNamespace;
		throw new Error("The window.".concat(namespace, " global variable is not available."));
	});
}
function loadCustomScript(options, PromisePonyfill) {
	if (PromisePonyfill === void 0) PromisePonyfill = Promise;
	validateArguments(options, PromisePonyfill);
	var url = getOwnProperty(options, "url");
	var attributes = getOwnProperty(options, "attributes");
	if (typeof url !== "string" || url.length === 0) throw new Error("Invalid url.");
	if (typeof attributes !== "undefined" && typeof attributes !== "object") throw new Error("Expected attributes to be an object.");
	return new PromisePonyfill(function(resolve, reject) {
		if (typeof document === "undefined") return resolve();
		insertScriptElement({
			url,
			attributes,
			onSuccess: function() {
				return resolve();
			},
			onError: function() {
				return reject(new Error("The script \"".concat(url, "\" failed to load. Check the HTTP status code and response body in DevTools to learn more.")));
			}
		});
	});
}
function getPayPalWindowNamespace(namespace) {
	return window[namespace];
}
function validateArguments(options, PromisePonyfill) {
	if (typeof options !== "object" || options === null) throw new Error("Expected an options object.");
	var environment = getOwnProperty(options, "environment");
	if (environment && environment !== "production" && environment !== "sandbox") throw new Error("The `environment` option must be either \"production\" or \"sandbox\".");
	if (typeof PromisePonyfill !== "undefined" && typeof PromisePonyfill !== "function") throw new Error("Expected PromisePonyfill to be a function.");
}
/**
* Simple check to determine if the Braintree is a valid namespace.
*
* @param braintreeSource the source {@link BraintreeNamespace}
* @returns a boolean representing if the namespace is valid.
*/
var isValidBraintreeNamespace = function(braintreeSource) {
	var _a, _b;
	if (typeof ((_a = braintreeSource === null || braintreeSource === void 0 ? void 0 : braintreeSource.client) === null || _a === void 0 ? void 0 : _a.create) !== "function" && typeof ((_b = braintreeSource === null || braintreeSource === void 0 ? void 0 : braintreeSource.paypalCheckout) === null || _b === void 0 ? void 0 : _b.create) !== "function") throw new Error("The braintreeNamespace property is not a valid BraintreeNamespace type.");
	return true;
};
/**
* Use `actions.braintree` to provide an interface for the paypalCheckoutInstance
* through the createOrder, createBillingAgreement and onApprove callbacks
*
* @param braintreeButtonProps the component button options
* @returns a new copy of the component button options casted as {@link PayPalButtonsComponentProps}
*/
var decorateActions = function(buttonProps, payPalCheckoutInstance) {
	var createOrderRef = buttonProps.createOrder;
	var createBillingAgreementRef = buttonProps.createBillingAgreement;
	var onApproveRef = buttonProps.onApprove;
	if (typeof createOrderRef === "function") buttonProps.createOrder = function(data, actions) {
		return createOrderRef(data, __assign(__assign({}, actions), { braintree: payPalCheckoutInstance }));
	};
	if (typeof createBillingAgreementRef === "function") buttonProps.createBillingAgreement = function(data, actions) {
		return createBillingAgreementRef(data, __assign(__assign({}, actions), { braintree: payPalCheckoutInstance }));
	};
	if (typeof onApproveRef === "function") buttonProps.onApprove = function(data, actions) {
		return onApproveRef(data, __assign(__assign({}, actions), { braintree: payPalCheckoutInstance }));
	};
	return __assign({}, buttonProps);
};
/**
* Get the Braintree namespace from the component props.
* If the prop `braintreeNamespace` is undefined will try to load it from the CDN.
* This function allows users to set the braintree manually on the `BraintreePayPalButtons` component.
*
* Use case can be for example legacy sites using AMD/UMD modules,
* trying to integrate the `BraintreePayPalButtons` component.
* If we attempt to load the Braintree from the CDN won't define the braintree namespace.
* This happens because the braintree script is an UMD module.
* After detecting the AMD on the global scope will create an anonymous module using `define`
* and the `BraintreePayPalButtons` won't be able to get access to the `window.braintree` namespace
* from the global context.
*
* @param braintreeSource the source {@link BraintreeNamespace}
* @returns the {@link BraintreeNamespace}
*/
var getBraintreeNamespace = function(braintreeSource) {
	if (braintreeSource && isValidBraintreeNamespace(braintreeSource)) return Promise.resolve(braintreeSource);
	return Promise.all([loadCustomScript({ url: BRAINTREE_SOURCE }), loadCustomScript({ url: BRAINTREE_PAYPAL_CHECKOUT_SOURCE })]).then(function() {
		return getBraintreeWindowNamespace();
	});
};
/**
This `<BraintreePayPalButtons />` component renders the [Braintree PayPal Buttons](https://developer.paypal.com/braintree/docs/guides/paypal/overview) for Braintree Merchants.
It relies on the `<PayPalScriptProvider />` parent component for managing state related to loading the JS SDK script.

Note: You are able to make your integration using the client token or using the tokenization key.

- To use the client token integration set the key `dataClientToken` in the `PayPayScriptProvider` component's options.
- To use the tokenization key integration set the key `dataUserIdToken` in the `PayPayScriptProvider` component's options.
*/
var BraintreePayPalButtons = function(_a) {
	var _b = _a.className, className = _b === void 0 ? "" : _b, _c = _a.disabled, disabled = _c === void 0 ? false : _c, children = _a.children, _d = _a.forceReRender, forceReRender = _d === void 0 ? [] : _d, braintreeNamespace = _a.braintreeNamespace, merchantAccountId = _a.merchantAccountId, buttonProps = __rest$1(_a, [
		"className",
		"disabled",
		"children",
		"forceReRender",
		"braintreeNamespace",
		"merchantAccountId"
	]);
	var setErrorState = (0, import_react.useState)(null)[1];
	var _f = useScriptProviderContext(), providerContext = _f[0], dispatch = _f[1];
	(0, import_react.useEffect)(function() {
		getBraintreeNamespace(braintreeNamespace).then(function(braintree) {
			var clientTokenizationKey = providerContext.options[SDK_SETTINGS.DATA_USER_ID_TOKEN];
			var clientToken = providerContext.options[SDK_SETTINGS.DATA_CLIENT_TOKEN];
			return braintree.client.create({ authorization: clientTokenizationKey || clientToken }).then(function(clientInstance) {
				var merchantProp = merchantAccountId ? { merchantAccountId } : {};
				return braintree.paypalCheckout.create(__assign(__assign({}, merchantProp), { client: clientInstance }));
			}).then(function(paypalCheckoutInstance) {
				dispatch({
					type: DISPATCH_ACTION.SET_BRAINTREE_INSTANCE,
					value: paypalCheckoutInstance
				});
			});
		}).catch(function(err) {
			setErrorState(function() {
				throw new Error("".concat(LOAD_SCRIPT_ERROR, " ").concat(err));
			});
		});
	}, [providerContext.options]);
	return import_react.createElement(import_react.Fragment, null, providerContext.braintreePayPalCheckoutInstance && import_react.createElement(PayPalButtons, __assign({
		className,
		disabled,
		forceReRender
	}, decorateActions(buttonProps, providerContext.braintreePayPalCheckoutInstance)), children));
};
/**
The `<PayPalMarks />` component is used for conditionally rendering different payment options using radio buttons.
The [Display PayPal Buttons with other Payment Methods guide](https://developer.paypal.com/docs/business/checkout/add-capabilities/buyer-experience/#display-paypal-buttons-with-other-payment-methods) describes this style of integration in detail.
It relies on the `<PayPalScriptProvider />` parent component for managing state related to loading the JS SDK script.

This component can also be configured to use a single funding source similar to the [standalone buttons](https://developer.paypal.com/docs/business/checkout/configure-payments/standalone-buttons/) approach.
A `FUNDING` object is exported by this library which has a key for every available funding source option.
*/
var PayPalMarks = function(_a) {
	var _b = _a.className, className = _b === void 0 ? "" : _b, children = _a.children, markProps = __rest$1(_a, ["className", "children"]);
	var _c = usePayPalScriptReducer()[0], isResolved = _c.isResolved, options = _c.options;
	var markContainerRef = (0, import_react.useRef)(null);
	var _d = (0, import_react.useState)(true), isEligible = _d[0], setIsEligible = _d[1];
	var setErrorState = (0, import_react.useState)(null)[1];
	/**
	* Render PayPal Mark into the DOM
	*/
	var renderPayPalMark = function(mark) {
		var current = markContainerRef.current;
		if (!current || !mark.isEligible()) return setIsEligible(false);
		if (current.firstChild) current.removeChild(current.firstChild);
		mark.render(current).catch(function(err) {
			if (current === null || current.children.length === 0) return;
			setErrorState(function() {
				throw new Error("Failed to render <PayPalMarks /> component. ".concat(err));
			});
		});
	};
	(0, import_react.useEffect)(function() {
		if (isResolved === false) return;
		var paypalWindowNamespace = getPayPalWindowNamespace$1(getOwnProperty$1(options, "dataNamespace"));
		if (paypalWindowNamespace === void 0 || paypalWindowNamespace.Marks === void 0) return setErrorState(function() {
			throw new Error(generateErrorMessage({
				reactComponentName: PayPalMarks.displayName,
				sdkComponentKey: "marks",
				sdkRequestedComponents: options.components,
				sdkDataNamespace: getOwnProperty$1(options, "dataNamespace")
			}));
		});
		renderPayPalMark(paypalWindowNamespace.Marks(__assign({}, markProps)));
	}, [isResolved, markProps.fundingSource]);
	return import_react.createElement(import_react.Fragment, null, isEligible ? import_react.createElement("div", {
		ref: markContainerRef,
		className
	}) : children);
};
PayPalMarks.displayName = "PayPalMarks";
/**
This `<PayPalMessages />` messages component renders a credit messaging on upstream merchant sites.
It relies on the `<PayPalScriptProvider />` parent component for managing state related to loading the JS SDK script.
*/
var PayPalMessages = function(_a) {
	var _b = _a.className, className = _b === void 0 ? "" : _b, _c = _a.forceReRender, forceReRender = _c === void 0 ? [] : _c, messageProps = __rest$1(_a, ["className", "forceReRender"]);
	var _d = usePayPalScriptReducer()[0], isResolved = _d.isResolved, options = _d.options;
	var messagesContainerRef = (0, import_react.useRef)(null);
	var messages = (0, import_react.useRef)(null);
	var setErrorState = (0, import_react.useState)(null)[1];
	(0, import_react.useEffect)(function() {
		if (isResolved === false) return;
		var paypalWindowNamespace = getPayPalWindowNamespace$1(getOwnProperty$1(options, "dataNamespace"));
		if (paypalWindowNamespace === void 0 || paypalWindowNamespace.Messages === void 0) return setErrorState(function() {
			throw new Error(generateErrorMessage({
				reactComponentName: PayPalMessages.displayName,
				sdkComponentKey: "messages",
				sdkRequestedComponents: options.components,
				sdkDataNamespace: getOwnProperty$1(options, "dataNamespace")
			}));
		});
		messages.current = paypalWindowNamespace.Messages(__assign({}, messageProps));
		messages.current.render(messagesContainerRef.current).catch(function(err) {
			if (messagesContainerRef.current === null || messagesContainerRef.current.children.length === 0) return;
			setErrorState(function() {
				throw new Error("Failed to render <PayPalMessages /> component. ".concat(err));
			});
		});
	}, __spreadArray([isResolved], forceReRender, true));
	return import_react.createElement("div", {
		ref: messagesContainerRef,
		className
	});
};
PayPalMessages.displayName = "PayPalMessages";
/**
This `<PayPalScriptProvider />` component takes care of loading the JS SDK `<script>`.
It manages state for script loading so children components like `<PayPalButtons />` know when it's safe to use the `window.paypal` global namespace.

Note: You always should use this component as a wrapper for  `PayPalButtons`, `PayPalMarks`, `PayPalMessages` and `BraintreePayPalButtons` components.
*/
var PayPalScriptProvider = function(_a) {
	var _b;
	var _c = _a.options, options = _c === void 0 ? { clientId: "test" } : _c, children = _a.children, _d = _a.deferLoading, deferLoading = _d === void 0 ? false : _d;
	var _e = (0, import_react.useReducer)(scriptReducer, {
		options: __assign(__assign({}, options), (_b = {}, _b[SDK_SETTINGS.DATA_JS_SDK_LIBRARY] = SDK_SETTINGS.DATA_LIBRARY_VALUE, _b[SDK_SETTINGS.DATA_SDK_INTEGRATION_SOURCE] = SDK_SETTINGS.DATA_LIBRARY_VALUE, _b[SCRIPT_ID] = "".concat(getScriptID(options)), _b)),
		loadingStatus: deferLoading ? SCRIPT_LOADING_STATE.INITIAL : SCRIPT_LOADING_STATE.PENDING
	}), state = _e[0], dispatch = _e[1];
	(0, import_react.useEffect)(function() {
		if (deferLoading === false && state.loadingStatus === SCRIPT_LOADING_STATE.INITIAL) return dispatch({
			type: DISPATCH_ACTION.LOADING_STATUS,
			value: SCRIPT_LOADING_STATE.PENDING
		});
		if (state.loadingStatus !== SCRIPT_LOADING_STATE.PENDING) return;
		var isSubscribed = true;
		loadScript(state.options).then(function() {
			if (isSubscribed) dispatch({
				type: DISPATCH_ACTION.LOADING_STATUS,
				value: SCRIPT_LOADING_STATE.RESOLVED
			});
		}).catch(function(err) {
			console.error("".concat(LOAD_SCRIPT_ERROR, " ").concat(err));
			if (isSubscribed) dispatch({
				type: DISPATCH_ACTION.LOADING_STATUS,
				value: {
					state: SCRIPT_LOADING_STATE.REJECTED,
					message: String(err)
				}
			});
		});
		return function() {
			isSubscribed = false;
		};
	}, [
		state.options,
		deferLoading,
		state.loadingStatus
	]);
	return import_react.createElement(ScriptContext.Provider, { value: __assign(__assign({}, state), { dispatch }) }, children);
};
/**
* Custom hook to store registered hosted fields children
* Each `PayPalHostedField` component should be registered on the parent provider
*
* @param initialValue the initially registered components
* @returns at first, an {@link Object} containing the registered hosted fields,
* and at the second a function handler to register the hosted fields components
*/
var useHostedFieldsRegister = function(initialValue) {
	if (initialValue === void 0) initialValue = {};
	var registeredFields = (0, import_react.useRef)(initialValue);
	var registerHostedField = function(component) {
		registeredFields.current = __assign(__assign({}, registeredFields.current), component);
	};
	return [registeredFields, registerHostedField];
};
/**
* Throw an exception if the HostedFields is not found in the paypal namespace
* Probably cause for this problem is not sending the hosted-fields string
* as part of the components props in options
* {@code <PayPalScriptProvider options={{ components: 'hosted-fields'}}>}
*
* @param param0 and object containing the components and namespace defined in options
* @throws {@code Error}
*
*/
var generateMissingHostedFieldsError = function(_a) {
	var _b = _a.components, components = _b === void 0 ? "" : _b, _d = _a[SDK_SETTINGS.DATA_NAMESPACE], dataNamespace = _d === void 0 ? DEFAULT_PAYPAL_NAMESPACE : _d;
	var expectedComponents = components ? "".concat(components, ",hosted-fields") : "hosted-fields";
	var errorMessage = "Unable to render <PayPalHostedFieldsProvider /> because window.".concat(dataNamespace, ".HostedFields is undefined.");
	if (!components.includes("hosted-fields")) errorMessage += "\nTo fix the issue, add 'hosted-fields' to the list of components passed to the parent PayPalScriptProvider: <PayPalScriptProvider options={{ components: '".concat(expectedComponents, "'}}>");
	return errorMessage;
};
/**
* Validate the expiration date component. Valid combinations are:
* 1- Only the `expirationDate` field exists.
* 2- Only the `expirationMonth` and `expirationYear` fields exist. Cannot be used with the `expirationDate` field.
*
* @param registerTypes
* @returns @type {true} when the children are valid
*/
var validateExpirationDate = function(registerTypes) {
	return !registerTypes.includes(PAYPAL_HOSTED_FIELDS_TYPES.EXPIRATION_DATE) && !registerTypes.includes(PAYPAL_HOSTED_FIELDS_TYPES.EXPIRATION_MONTH) && !registerTypes.includes(PAYPAL_HOSTED_FIELDS_TYPES.EXPIRATION_YEAR);
};
/**
* Check if we find the [number, expiration, cvv] in children
*
* @param requiredChildren the list with required children [number, expiration, cvv]
* @param registerTypes    the list of all the children types pass to the parent
* @throw an @type {Error} when not find the default children
*/
var hasDefaultChildren = function(registerTypes) {
	if (!registerTypes.includes(PAYPAL_HOSTED_FIELDS_TYPES.NUMBER) || !registerTypes.includes(PAYPAL_HOSTED_FIELDS_TYPES.CVV) || validateExpirationDate(registerTypes)) throw new Error(HOSTED_FIELDS_CHILDREN_ERROR);
};
/**
* Check if we don't have duplicate children types
*
* @param registerTypes the list of all the children types pass to the parent
* @throw an @type {Error} when duplicate types was found
*/
var noDuplicateChildren = function(registerTypes) {
	if (registerTypes.length !== new Set(registerTypes).size) throw new Error(HOSTED_FIELDS_DUPLICATE_CHILDREN_ERROR);
};
/**
* Validate the hosted field children in the PayPalHostedFieldsProvider component.
* These are the rules:
* 1- We need to find 3 default children for number, expiration, cvv
* 2- No duplicate children are allowed
* 3- No invalid combinations of `expirationDate`, `expirationMonth`, and `expirationYear`
*
* @param childrenList     the list of children
* @param requiredChildren the list with required children [number, expiration, cvv]
*/
var validateHostedFieldChildren = function(registeredFields) {
	hasDefaultChildren(registeredFields);
	noDuplicateChildren(registeredFields);
};
/**
This `<PayPalHostedFieldsProvider />` provider component wraps the form field elements and accepts props like `createOrder()`.

This provider component is designed to be used with the `<PayPalHostedField />` component.

Warning: If you don't see anything in the screen probably your client is ineligible.
To handle this problem make sure to use the prop `notEligibleError` and pass a component with a custom message.
Take a look to this link if that is the case: https://developer.paypal.com/docs/checkout/advanced/integrate/
*/
var PayPalHostedFieldsProvider = function(_a) {
	var styles = _a.styles, createOrder = _a.createOrder, notEligibleError = _a.notEligibleError, children = _a.children, installments = _a.installments;
	var _b = useScriptProviderContext()[0], options = _b.options, loadingStatus = _b.loadingStatus;
	var _c = (0, import_react.useState)(true), isEligible = _c[0], setIsEligible = _c[1];
	var _d = (0, import_react.useState)(), cardFields = _d[0], setCardFields = _d[1];
	var setErrorState = (0, import_react.useState)(null)[1];
	var hostedFieldsContainerRef = (0, import_react.useRef)(null);
	var hostedFields = (0, import_react.useRef)();
	var _f = useHostedFieldsRegister(), registeredFields = _f[0], registerHostedField = _f[1];
	(0, import_react.useEffect)(function() {
		validateHostedFieldChildren(Object.keys(registeredFields.current));
		if (!(loadingStatus === SCRIPT_LOADING_STATE.RESOLVED)) return;
		hostedFields.current = getPayPalWindowNamespace$1(getOwnProperty$1(options, "dataNamespace")).HostedFields;
		if (!hostedFields.current) throw new Error(generateMissingHostedFieldsError({
			components: options.components,
			dataNamespace: getOwnProperty$1(options, "dataNamespace")
		}));
		if (!hostedFields.current.isEligible()) return setIsEligible(false);
		if (cardFields) cardFields.teardown();
		hostedFields.current.render({
			createOrder,
			fields: registeredFields.current,
			installments,
			styles
		}).then(function(cardFieldsInstance) {
			if (hostedFieldsContainerRef.current) setCardFields(cardFieldsInstance);
		}).catch(function(err) {
			setErrorState(function() {
				throw new Error("Failed to render <PayPalHostedFieldsProvider /> component. ".concat(err));
			});
		});
	}, [loadingStatus, styles]);
	return import_react.createElement("div", { ref: hostedFieldsContainerRef }, isEligible ? import_react.createElement(PayPalHostedFieldsContext.Provider, { value: {
		cardFields,
		registerHostedField
	} }, children) : notEligibleError);
};
/**
This `<PayPalHostedField />` component renders individual fields for [Hosted Fields](https://developer.paypal.com/docs/business/checkout/advanced-card-payments/integrate#3-add-javascript-sdk-and-card-form) integrations.
It relies on the `<PayPalHostedFieldsProvider />` parent component for managing state related to loading the JS SDK script
and execute some validations before the rendering the fields.

To use the PayPal hosted fields you need to define at least three fields:

- A card number field
- The CVV code from the client card
- The expiration date

You can define the expiration date as a single field similar to the example below,
or you are able to define it in [two separate fields](https://paypal.github.io/paypal-js/web-sdk-v5-react-storybook/?path=/docs/paypal-paypalhostedfields--expiration-date). One for the month and second for year.

Note: Take care when using multiple instances of the PayPal Hosted Fields on the same page.
The component will fail to render when any of the selectors return more than one element.
*/
var PayPalHostedField = function(_a) {
	var hostedFieldType = _a.hostedFieldType, options = _a.options, props = __rest$1(_a, ["hostedFieldType", "options"]);
	var hostedFieldContext = (0, import_react.useContext)(PayPalHostedFieldsContext);
	(0, import_react.useEffect)(function() {
		var _a;
		if (!(hostedFieldContext === null || hostedFieldContext === void 0 ? void 0 : hostedFieldContext.registerHostedField)) throw new Error("The HostedField cannot be register in the PayPalHostedFieldsProvider parent component");
		hostedFieldContext.registerHostedField((_a = {}, _a[hostedFieldType] = {
			selector: options.selector,
			placeholder: options.placeholder,
			type: options.type,
			formatInput: options.formatInput,
			maskInput: options.maskInput,
			select: options.select,
			maxlength: options.maxlength,
			minlength: options.minlength,
			prefill: options.prefill,
			rejectUnsupportedCards: options.rejectUnsupportedCards
		}, _a));
	}, []);
	return import_react.createElement("div", __assign({}, props));
};
/**
* Throw an exception if the CardFields is not found in the paypal namespace
* Probably cause for this problem is not sending the card-fields string
* as part of the components props in options
* {@code <PayPalScriptProvider options={{ components: 'card-fields'}}>}
*
* @param param0 and object containing the components and namespace defined in options
* @throws {@code Error}
*
*/
var generateMissingCardFieldsError = function(_a) {
	var _b = _a.components, components = _b === void 0 ? "" : _b, _d = _a[SDK_SETTINGS.DATA_NAMESPACE], dataNamespace = _d === void 0 ? DEFAULT_PAYPAL_NAMESPACE : _d;
	var expectedComponents = components ? "".concat(components, ",card-fields") : "card-fields";
	var errorMessage = "Unable to render <PayPalCardFieldsProvider /> because window.".concat(dataNamespace, ".CardFields is undefined.");
	if (!components.includes("card-fields")) errorMessage += "\nTo fix the issue, add 'card-fields' to the list of components passed to the parent PayPalScriptProvider: <PayPalScriptProvider options={{ components: '".concat(expectedComponents, "'}}>");
	return errorMessage;
};
function ignore() {}
function hasChildren(container) {
	var _a;
	return !!((_a = container.current) === null || _a === void 0 ? void 0 : _a.children.length);
}
var PayPalCardFieldsContext = (0, import_react.createContext)({
	cardFieldsForm: null,
	fields: {},
	registerField: ignore,
	unregisterField: ignore
});
var usePayPalCardFields = function() {
	return (0, import_react.useContext)(PayPalCardFieldsContext);
};
var usePayPalCardFieldsRegistry = function() {
	var setError = (0, import_react.useState)(null)[1];
	var registeredFields = (0, import_react.useRef)({});
	var registerField = function() {
		var props = [];
		for (var _i = 0; _i < arguments.length; _i++) props[_i] = arguments[_i];
		var fieldName = props[0], options = props[1], cardFields = props[2];
		if (registeredFields.current[fieldName]) setError(function() {
			throw new Error(CARD_FIELDS_DUPLICATE_CHILDREN_ERROR);
		});
		registeredFields.current[fieldName] = cardFields === null || cardFields === void 0 ? void 0 : cardFields[fieldName](options);
		return registeredFields.current[fieldName];
	};
	var unregisterField = function(fieldName) {
		var field = registeredFields.current[fieldName];
		if (field) {
			field.close().catch(ignore);
			delete registeredFields.current[fieldName];
		}
	};
	return {
		fields: registeredFields.current,
		registerField,
		unregisterField
	};
};
var FullWidthContainer = function(_a) {
	var children = _a.children;
	return import_react.createElement("div", { style: { width: "100%" } }, children);
};
/**
The `<PayPalCardFieldsProvider />` is a context provider that is designed to support the rendering and state management of PayPal CardFields in your application.

The context provider will initialize the `CardFields` instance from the JS SDK and determine eligibility to render the CardField components. Once the `CardFields` are initialized, the context provider will manage the state of the `CardFields` instance as well as the reference to each individual card field.

Passing the `inputEvents` and `style` props to the context provider will apply them to each of the individual field components.

The state managed by the provider is accessible through our custom hook `usePayPalCardFields`.

*/
var PayPalCardFieldsProvider = function(_a) {
	var children = _a.children, props = __rest$1(_a, ["children"]);
	var proxyInputEvents = useProxyProps(props.inputEvents);
	var proxyProps = useProxyProps(props);
	var _b = usePayPalScriptReducer()[0], isResolved = _b.isResolved, options = _b.options;
	var _c = usePayPalCardFieldsRegistry(), fields = _c.fields, registerField = _c.registerField, unregisterField = _c.unregisterField;
	var _d = (0, import_react.useState)(null), cardFieldsForm = _d[0], setCardFieldsForm = _d[1];
	var cardFieldsInstance = (0, import_react.useRef)(null);
	var _e = (0, import_react.useState)(false), isEligible = _e[0], setIsEligible = _e[1];
	var setError = (0, import_react.useState)(null)[1];
	(0, import_react.useEffect)(function() {
		var _a, _b, _c;
		if (!isResolved) return;
		if (props.inputEvents) proxyProps.inputEvents = proxyInputEvents;
		try {
			cardFieldsInstance.current = (_c = (_b = (_a = getPayPalWindowNamespace$1(getOwnProperty$1(options, "dataNamespace"))).CardFields) === null || _b === void 0 ? void 0 : _b.call(_a, __assign({}, proxyProps))) !== null && _c !== void 0 ? _c : null;
		} catch (error) {
			setError(function() {
				throw new Error("Failed to render <PayPalCardFieldsProvider /> component. Failed to initialize:  ".concat(error));
			});
			return;
		}
		if (!cardFieldsInstance.current) {
			setError(function() {
				throw new Error(generateMissingCardFieldsError({
					components: options.components,
					dataNamespace: getOwnProperty$1(options, "dataNamespace")
				}));
			});
			return;
		}
		setIsEligible(cardFieldsInstance.current.isEligible());
		setCardFieldsForm(cardFieldsInstance.current);
		return function() {
			setCardFieldsForm(null);
			cardFieldsInstance.current = null;
		};
	}, [isResolved]);
	if (!isEligible) return import_react.createElement("div", null);
	return import_react.createElement(FullWidthContainer, null, import_react.createElement(PayPalCardFieldsContext.Provider, { value: {
		cardFieldsForm,
		fields,
		registerField,
		unregisterField
	} }, children));
};
var PayPalCardField = function(_a) {
	var className = _a.className, fieldName = _a.fieldName, options = __rest$1(_a, ["className", "fieldName"]);
	var _b = usePayPalCardFields(), cardFieldsForm = _b.cardFieldsForm, registerField = _b.registerField, unregisterField = _b.unregisterField;
	var containerRef = (0, import_react.useRef)(null);
	var proxyInputEvents = useProxyProps(options.inputEvents);
	var setError = (0, import_react.useState)(null)[1];
	function closeComponent() {
		unregisterField(fieldName);
	}
	(0, import_react.useEffect)(function() {
		if (!cardFieldsForm) {
			setError(function() {
				throw new Error(CARD_FIELDS_CONTEXT_ERROR);
			});
			return closeComponent;
		}
		if (!containerRef.current) return closeComponent;
		if (options.inputEvents) options.inputEvents = proxyInputEvents;
		var registeredField = registerField(fieldName, options, cardFieldsForm);
		registeredField === null || registeredField === void 0 || registeredField.render(containerRef.current).catch(function(err) {
			if (!hasChildren(containerRef)) return;
			setError(function() {
				throw new Error("Failed to render <PayPal".concat(fieldName, " /> component. ").concat(err));
			});
		});
		return closeComponent;
	}, []);
	return import_react.createElement("div", {
		ref: containerRef,
		className
	});
};
var PayPalNameField = function(options) {
	return import_react.createElement(PayPalCardField, __assign({ fieldName: "NameField" }, options));
};
var PayPalNumberField = function(options) {
	return import_react.createElement(PayPalCardField, __assign({ fieldName: "NumberField" }, options));
};
var PayPalExpiryField = function(options) {
	return import_react.createElement(PayPalCardField, __assign({ fieldName: "ExpiryField" }, options));
};
var PayPalCVVField = function(options) {
	return import_react.createElement(PayPalCardField, __assign({ fieldName: "CVVField" }, options));
};
var FlexContainer = function(_a) {
	var children = _a.children;
	return import_react.createElement("div", { style: {
		display: "flex",
		width: "100%"
	} }, children);
};
/**
This `<PayPalCardFieldsForm />` component renders the 4 individual fields for [Card Fields](https://developer.paypal.com/docs/business/checkout/advanced-card-payments/integrate#3-add-javascript-sdk-and-card-form) integrations.
This setup relies on the `<PayPalCardFieldsProvider />` parent component, which manages the state related to loading the JS SDK script and performs certain validations before rendering the fields.



Note: If you want to have more granular control over the layout of how the fields are rendered, you can alternatively use our Individual Fields.
*/
var PayPalCardFieldsForm = function(_a) {
	var className = _a.className;
	return import_react.createElement("div", { className }, import_react.createElement(PayPalCardField, { fieldName: "NameField" }), import_react.createElement(PayPalCardField, { fieldName: "NumberField" }), import_react.createElement(FlexContainer, null, import_react.createElement(FullWidthContainer, null, import_react.createElement(PayPalCardField, { fieldName: "ExpiryField" })), import_react.createElement(FullWidthContainer, null, import_react.createElement(PayPalCardField, { fieldName: "CVVField" }))));
};
var FUNDING$1 = {
	PAYPAL: "paypal",
	VENMO: "venmo",
	APPLEPAY: "applepay",
	ITAU: "itau",
	CREDIT: "credit",
	PAYLATER: "paylater",
	CARD: "card",
	IDEAL: "ideal",
	SEPA: "sepa",
	BANCONTACT: "bancontact",
	GIROPAY: "giropay",
	SOFORT: "sofort",
	EPS: "eps",
	MYBANK: "mybank",
	P24: "p24",
	PAYU: "payu",
	BLIK: "blik",
	TRUSTLY: "trustly",
	OXXO: "oxxo",
	BOLETO: "boleto",
	BOLETOBANCARIO: "boletobancario",
	WECHATPAY: "wechatpay",
	MERCADOPAGO: "mercadopago",
	MULTIBANCO: "multibanco",
	SATISPAY: "satispay",
	PAIDY: "paidy",
	ZIMPLER: "zimpler",
	MAXIMA: "maxima"
};
FUNDING$1.IDEAL, FUNDING$1.BANCONTACT, FUNDING$1.GIROPAY, FUNDING$1.SOFORT, FUNDING$1.EPS, FUNDING$1.MYBANK, FUNDING$1.P24, FUNDING$1.PAYU, FUNDING$1.BLIK, FUNDING$1.TRUSTLY, FUNDING$1.OXXO, FUNDING$1.BOLETO, FUNDING$1.BOLETOBANCARIO, FUNDING$1.WECHATPAY, FUNDING$1.MERCADOPAGO, FUNDING$1.MULTIBANCO, FUNDING$1.SATISPAY, FUNDING$1.PAIDY, FUNDING$1.MAXIMA, FUNDING$1.ZIMPLER;
var FUNDING = FUNDING$1;
export { BraintreePayPalButtons, DISPATCH_ACTION, FUNDING, PAYPAL_HOSTED_FIELDS_TYPES, PayPalButtons, PayPalCVVField, PayPalCardFieldsContext, PayPalCardFieldsForm, PayPalCardFieldsProvider, PayPalExpiryField, PayPalHostedField, PayPalHostedFieldsProvider, PayPalMarks, PayPalMessages, PayPalNameField, PayPalNumberField, PayPalScriptProvider, SCRIPT_LOADING_STATE, ScriptContext, destroySDKScript, getScriptID, scriptReducer, usePayPalCardFields, usePayPalHostedFields, usePayPalScriptReducer, useScriptProviderContext };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHBheXBhbF9yZWFjdC1wYXlwYWwtanMuanMiLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsInVzZVJlZiIsIkNvbXBvbmVudCIsInVzZVN0YXRlIiwidXNlUmVkdWNlciJdLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL25vZGVfbW9kdWxlcy9AcGF5cGFsL3JlYWN0LXBheXBhbC1qcy9kaXN0L2VzbS9yZWFjdC1wYXlwYWwtanMuanMiXSwic291cmNlc0NvbnRlbnQiOlsiLyohXG4gKiByZWFjdC1wYXlwYWwtanMgdjEwLjYuMSAoMjAyNi0xMC0yM1QxODozMzowOC42NjlaKVxuICogQ29weXJpZ2h0IDIwMjAtcHJlc2VudCwgUGF5UGFsLCBJbmMuIEFsbCByaWdodHMgcmVzZXJ2ZWQuXG4gKlxuICogTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKTtcbiAqIHlvdSBtYXkgbm90IHVzZSB0aGlzIGZpbGUgZXhjZXB0IGluIGNvbXBsaWFuY2Ugd2l0aCB0aGUgTGljZW5zZS5cbiAqIFlvdSBtYXkgb2J0YWluIGEgY29weSBvZiB0aGUgTGljZW5zZSBhdFxuICpcbiAqIGh0dHBzOi8vd3d3LmFwYWNoZS5vcmcvbGljZW5zZXMvTElDRU5TRS0yLjBcbiAqXG4gKiBVbmxlc3MgcmVxdWlyZWQgYnkgYXBwbGljYWJsZSBsYXcgb3IgYWdyZWVkIHRvIGluIHdyaXRpbmcsIHNvZnR3YXJlXG4gKiBkaXN0cmlidXRlZCB1bmRlciB0aGUgTGljZW5zZSBpcyBkaXN0cmlidXRlZCBvbiBhbiBcIkFTIElTXCIgQkFTSVMsXG4gKiBXSVRIT1VUIFdBUlJBTlRJRVMgT1IgQ09ORElUSU9OUyBPRiBBTlkgS0lORCwgZWl0aGVyIGV4cHJlc3Mgb3IgaW1wbGllZC5cbiAqIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZyBwZXJtaXNzaW9ucyBhbmRcbiAqIGxpbWl0YXRpb25zIHVuZGVyIHRoZSBMaWNlbnNlLlxuICovXG5pbXBvcnQgUmVhY3QsIHsgY3JlYXRlQ29udGV4dCwgdXNlQ29udGV4dCwgdXNlUmVmLCBDb21wb25lbnQsIHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZHVjZXIgfSBmcm9tICdyZWFjdCc7XG5cbi8qKlxuICogRW51bSBmb3IgdGhlIFNESyBzY3JpcHQgcmVzb2x2ZSBzdGF0dXMsXG4gKlxuICogQGVudW0ge3N0cmluZ31cbiAqL1xudmFyIFNDUklQVF9MT0FESU5HX1NUQVRFO1xuKGZ1bmN0aW9uIChTQ1JJUFRfTE9BRElOR19TVEFURSkge1xuICBTQ1JJUFRfTE9BRElOR19TVEFURVtcIklOSVRJQUxcIl0gPSBcImluaXRpYWxcIjtcbiAgU0NSSVBUX0xPQURJTkdfU1RBVEVbXCJQRU5ESU5HXCJdID0gXCJwZW5kaW5nXCI7XG4gIFNDUklQVF9MT0FESU5HX1NUQVRFW1wiUkVKRUNURURcIl0gPSBcInJlamVjdGVkXCI7XG4gIFNDUklQVF9MT0FESU5HX1NUQVRFW1wiUkVTT0xWRURcIl0gPSBcInJlc29sdmVkXCI7XG59KShTQ1JJUFRfTE9BRElOR19TVEFURSB8fCAoU0NSSVBUX0xPQURJTkdfU1RBVEUgPSB7fSkpO1xuLyoqXG4gKiBFbnVtIGZvciB0aGUgUGF5UGFsU2NyaXB0UHJvdmlkZXIgY29udGV4dCBkaXNwYXRjaCBhY3Rpb25zXG4gKlxuICogQGVudW0ge3N0cmluZ31cbiAqL1xudmFyIERJU1BBVENIX0FDVElPTjtcbihmdW5jdGlvbiAoRElTUEFUQ0hfQUNUSU9OKSB7XG4gIERJU1BBVENIX0FDVElPTltcIkxPQURJTkdfU1RBVFVTXCJdID0gXCJzZXRMb2FkaW5nU3RhdHVzXCI7XG4gIERJU1BBVENIX0FDVElPTltcIlJFU0VUX09QVElPTlNcIl0gPSBcInJlc2V0T3B0aW9uc1wiO1xuICBESVNQQVRDSF9BQ1RJT05bXCJTRVRfQlJBSU5UUkVFX0lOU1RBTkNFXCJdID0gXCJicmFpbnRyZWVJbnN0YW5jZVwiO1xufSkoRElTUEFUQ0hfQUNUSU9OIHx8IChESVNQQVRDSF9BQ1RJT04gPSB7fSkpO1xuLyoqXG4gKiBFbnVtIGZvciBhbGwgdGhlIGF2YWlsYWJsZSBob3N0ZWQgZmllbGRzXG4gKlxuICogQGVudW0ge3N0cmluZ31cbiAqL1xudmFyIFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTO1xuKGZ1bmN0aW9uIChQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFUykge1xuICBQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFU1tcIk5VTUJFUlwiXSA9IFwibnVtYmVyXCI7XG4gIFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTW1wiQ1ZWXCJdID0gXCJjdnZcIjtcbiAgUEFZUEFMX0hPU1RFRF9GSUVMRFNfVFlQRVNbXCJFWFBJUkFUSU9OX0RBVEVcIl0gPSBcImV4cGlyYXRpb25EYXRlXCI7XG4gIFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTW1wiRVhQSVJBVElPTl9NT05USFwiXSA9IFwiZXhwaXJhdGlvbk1vbnRoXCI7XG4gIFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTW1wiRVhQSVJBVElPTl9ZRUFSXCJdID0gXCJleHBpcmF0aW9uWWVhclwiO1xuICBQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFU1tcIlBPU1RBTF9DT0RFXCJdID0gXCJwb3N0YWxDb2RlXCI7XG59KShQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFUyB8fCAoUEFZUEFMX0hPU1RFRF9GSUVMRFNfVFlQRVMgPSB7fSkpO1xudmFyIGV4dGVuZFN0YXRpY3MgPSBmdW5jdGlvbiAoZCwgYikge1xuICBleHRlbmRTdGF0aWNzID0gT2JqZWN0LnNldFByb3RvdHlwZU9mIHx8IHtcbiAgICBfX3Byb3RvX186IFtdXG4gIH0gaW5zdGFuY2VvZiBBcnJheSAmJiBmdW5jdGlvbiAoZCwgYikge1xuICAgIGQuX19wcm90b19fID0gYjtcbiAgfSB8fCBmdW5jdGlvbiAoZCwgYikge1xuICAgIGZvciAodmFyIHAgaW4gYikgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChiLCBwKSkgZFtwXSA9IGJbcF07XG4gIH07XG4gIHJldHVybiBleHRlbmRTdGF0aWNzKGQsIGIpO1xufTtcbmZ1bmN0aW9uIF9fZXh0ZW5kcyhkLCBiKSB7XG4gIGlmICh0eXBlb2YgYiAhPT0gXCJmdW5jdGlvblwiICYmIGIgIT09IG51bGwpIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDbGFzcyBleHRlbmRzIHZhbHVlIFwiICsgU3RyaW5nKGIpICsgXCIgaXMgbm90IGEgY29uc3RydWN0b3Igb3IgbnVsbFwiKTtcbiAgZXh0ZW5kU3RhdGljcyhkLCBiKTtcbiAgZnVuY3Rpb24gX18oKSB7XG4gICAgdGhpcy5jb25zdHJ1Y3RvciA9IGQ7XG4gIH1cbiAgZC5wcm90b3R5cGUgPSBiID09PSBudWxsID8gT2JqZWN0LmNyZWF0ZShiKSA6IChfXy5wcm90b3R5cGUgPSBiLnByb3RvdHlwZSwgbmV3IF9fKCkpO1xufVxudmFyIF9fYXNzaWduID0gZnVuY3Rpb24gKCkge1xuICBfX2Fzc2lnbiA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gX19hc3NpZ24odCkge1xuICAgIGZvciAodmFyIHMsIGkgPSAxLCBuID0gYXJndW1lbnRzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgcyA9IGFyZ3VtZW50c1tpXTtcbiAgICAgIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSkgdFtwXSA9IHNbcF07XG4gICAgfVxuICAgIHJldHVybiB0O1xuICB9O1xuICByZXR1cm4gX19hc3NpZ24uYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbn07XG5mdW5jdGlvbiBfX3Jlc3QkMShzLCBlKSB7XG4gIHZhciB0ID0ge307XG4gIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKSB0W3BdID0gc1twXTtcbiAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKSBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKSB0W3BbaV1dID0gc1twW2ldXTtcbiAgfVxuICByZXR1cm4gdDtcbn1cbmZ1bmN0aW9uIF9fc3ByZWFkQXJyYXkodG8sIGZyb20sIHBhY2spIHtcbiAgaWYgKHBhY2sgfHwgYXJndW1lbnRzLmxlbmd0aCA9PT0gMikgZm9yICh2YXIgaSA9IDAsIGwgPSBmcm9tLmxlbmd0aCwgYXI7IGkgPCBsOyBpKyspIHtcbiAgICBpZiAoYXIgfHwgIShpIGluIGZyb20pKSB7XG4gICAgICBpZiAoIWFyKSBhciA9IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20sIDAsIGkpO1xuICAgICAgYXJbaV0gPSBmcm9tW2ldO1xuICAgIH1cbiAgfVxuICByZXR1cm4gdG8uY29uY2F0KGFyIHx8IEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGZyb20pKTtcbn1cbnR5cGVvZiBTdXBwcmVzc2VkRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IFN1cHByZXNzZWRFcnJvciA6IGZ1bmN0aW9uIChlcnJvciwgc3VwcHJlc3NlZCwgbWVzc2FnZSkge1xuICB2YXIgZSA9IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgcmV0dXJuIGUubmFtZSA9IFwiU3VwcHJlc3NlZEVycm9yXCIsIGUuZXJyb3IgPSBlcnJvciwgZS5zdXBwcmVzc2VkID0gc3VwcHJlc3NlZCwgZTtcbn07XG5cbi8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKipcbiAqIENvbW1vbiByZWZlcmVuY2UgdG8gdGhlIHNjcmlwdCBpZGVudGlmaWVyICpcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4vLyBrZWVwIHRoaXMgc2NyaXB0IGlkIHZhbHVlIGluIGtlYmFiLWNhc2UgZm9ybWF0XG52YXIgU0NSSVBUX0lEID0gXCJkYXRhLXJlYWN0LXBheXBhbC1zY3JpcHQtaWRcIjtcbnZhciBTREtfU0VUVElOR1MgPSB7XG4gIERBVEFfQ0xJRU5UX1RPS0VOOiBcImRhdGFDbGllbnRUb2tlblwiLFxuICBEQVRBX0pTX1NES19MSUJSQVJZOiBcImRhdGFKc1Nka0xpYnJhcnlcIixcbiAgREFUQV9MSUJSQVJZX1ZBTFVFOiBcInJlYWN0LXBheXBhbC1qc1wiLFxuICBEQVRBX05BTUVTUEFDRTogXCJkYXRhTmFtZXNwYWNlXCIsXG4gIERBVEFfU0RLX0lOVEVHUkFUSU9OX1NPVVJDRTogXCJkYXRhU2RrSW50ZWdyYXRpb25Tb3VyY2VcIixcbiAgREFUQV9VU0VSX0lEX1RPS0VOOiBcImRhdGFVc2VySWRUb2tlblwiXG59O1xudmFyIExPQURfU0NSSVBUX0VSUk9SID0gXCJGYWlsZWQgdG8gbG9hZCB0aGUgUGF5UGFsIEpTIFNESyBzY3JpcHQuXCI7XG4vKioqKioqKioqKioqKioqKioqKioqKioqKioqKlxuICogQnJhaW50cmVlIGVycm9yIG1lc3NhZ2VzICpcbiAqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xudmFyIEVNUFRZX0JSQUlOVFJFRV9BVVRIT1JJWkFUSU9OX0VSUk9SX01FU1NBR0UgPSBcIkludmFsaWQgYXV0aG9yaXphdGlvbiBkYXRhLiBVc2UgZGF0YUNsaWVudFRva2VuIG9yIGRhdGFVc2VySWRUb2tlbiB0byBhdXRob3JpemUuXCI7XG52YXIgYnJhaW50cmVlVmVyc2lvbiA9IFwiMy4xMTcuMFwiO1xudmFyIEJSQUlOVFJFRV9TT1VSQ0UgPSBcImh0dHBzOi8vanMuYnJhaW50cmVlZ2F0ZXdheS5jb20vd2ViL1wiLmNvbmNhdChicmFpbnRyZWVWZXJzaW9uLCBcIi9qcy9jbGllbnQubWluLmpzXCIpO1xudmFyIEJSQUlOVFJFRV9QQVlQQUxfQ0hFQ0tPVVRfU09VUkNFID0gXCJodHRwczovL2pzLmJyYWludHJlZWdhdGV3YXkuY29tL3dlYi9cIi5jb25jYXQoYnJhaW50cmVlVmVyc2lvbiwgXCIvanMvcGF5cGFsLWNoZWNrb3V0Lm1pbi5qc1wiKTtcbi8qKioqKioqKioqKioqKioqKioqKipcbiAqIFBheVBhbCBuYW1lc3BhY2VzICpcbiAqKioqKioqKioqKioqKioqKioqKiovXG52YXIgREVGQVVMVF9QQVlQQUxfTkFNRVNQQUNFID0gXCJwYXlwYWxcIjtcbnZhciBERUZBVUxUX0JSQUlOVFJFRV9OQU1FU1BBQ0UgPSBcImJyYWludHJlZVwiO1xuLyoqKioqKioqKioqKioqKioqXG4gKiBIb3N0ZWQgRmllbGRzICpcbiAqKioqKioqKioqKioqKioqKi9cbnZhciBIT1NURURfRklFTERTX0NISUxEUkVOX0VSUk9SID0gXCJUbyB1c2UgSG9zdGVkRmllbGRzIHlvdSBtdXN0IHVzZSBpdCB3aXRoIGF0IGxlYXN0IDMgY2hpbGRyZW4gd2l0aCB0eXBlczogW251bWJlciwgY3Z2LCBleHBpcmF0aW9uRGF0ZV0gaW5jbHVkZXNcIjtcbnZhciBIT1NURURfRklFTERTX0RVUExJQ0FURV9DSElMRFJFTl9FUlJPUiA9IFwiQ2Fubm90IHVzZSBkdXBsaWNhdGUgSG9zdGVkRmllbGRzIGFzIGNoaWxkcmVuXCI7XG4vKioqKioqKioqKioqKioqKioqKlxuICogU2NyaXB0IFByb3ZpZGVyICpcbiAqKioqKioqKioqKioqKioqKioqL1xudmFyIFNDUklQVF9QUk9WSURFUl9SRURVQ0VSX0VSUk9SID0gXCJ1c2VQYXlQYWxTY3JpcHRSZWR1Y2VyIG11c3QgYmUgdXNlZCB3aXRoaW4gYSBQYXlQYWxTY3JpcHRQcm92aWRlclwiO1xudmFyIENBUkRfRklFTERTX0RVUExJQ0FURV9DSElMRFJFTl9FUlJPUiA9IFwiQ2Fubm90IHVzZSBkdXBsaWNhdGUgQ2FyZEZpZWxkcyBhcyBjaGlsZHJlblwiO1xudmFyIENBUkRfRklFTERTX0NPTlRFWFRfRVJST1IgPSBcIkluZGl2aWR1YWwgQ2FyZEZpZWxkcyBtdXN0IGJlIHJlbmRlcmVkIGluc2lkZSB0aGUgUGF5UGFsQ2FyZEZpZWxkc1Byb3ZpZGVyXCI7XG5cbi8qKlxuICogR2V0IHRoZSBuYW1lc3BhY2UgZnJvbSB0aGUgd2luZG93IGluIHRoZSBicm93c2VyXG4gKiB0aGlzIGlzIHVzZWZ1bCB0byBnZXQgdGhlIHBheXBhbCBvYmplY3QgZnJvbSB3aW5kb3dcbiAqIGFmdGVyIGxvYWQgUGF5UGFsIFNESyBzY3JpcHRcbiAqXG4gKiBAcGFyYW0gbmFtZXNwYWNlIHRoZSBuYW1lIHNwYWNlIHRvIHJldHVyblxuICogQHJldHVybnMgdGhlIG5hbWVzcGFjZSBpZiBleGlzdHMgb3IgdW5kZWZpbmVkIG90aGVyd2lzZVxuICovXG5mdW5jdGlvbiBnZXRQYXlQYWxXaW5kb3dOYW1lc3BhY2UkMShuYW1lc3BhY2UpIHtcbiAgaWYgKG5hbWVzcGFjZSA9PT0gdm9pZCAwKSB7XG4gICAgbmFtZXNwYWNlID0gREVGQVVMVF9QQVlQQUxfTkFNRVNQQUNFO1xuICB9XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gIHJldHVybiB3aW5kb3dbbmFtZXNwYWNlXTtcbn1cbi8qKlxuICogR2V0IGEgbmFtZXNwYWNlIGZyb20gdGhlIHdpbmRvdyBpbiB0aGUgYnJvd3NlclxuICogdGhpcyBpcyB1c2VmdWwgdG8gZ2V0IHRoZSBicmFpbnRyZWUgZnJvbSB3aW5kb3dcbiAqIGFmdGVyIGxvYWQgQnJhaW50cmVlIHNjcmlwdFxuICpcbiAqIEBwYXJhbSBuYW1lc3BhY2UgdGhlIG5hbWUgc3BhY2UgdG8gcmV0dXJuXG4gKiBAcmV0dXJucyB0aGUgbmFtZXNwYWNlIGlmIGV4aXN0cyBvciB1bmRlZmluZWQgb3RoZXJ3aXNlXG4gKi9cbmZ1bmN0aW9uIGdldEJyYWludHJlZVdpbmRvd05hbWVzcGFjZShuYW1lc3BhY2UpIHtcbiAgaWYgKG5hbWVzcGFjZSA9PT0gdm9pZCAwKSB7XG4gICAgbmFtZXNwYWNlID0gREVGQVVMVF9CUkFJTlRSRUVfTkFNRVNQQUNFO1xuICB9XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvbm8tZXhwbGljaXQtYW55XG4gIHJldHVybiB3aW5kb3dbbmFtZXNwYWNlXTtcbn1cbi8qKlxuICogQ3JlYXRlcyBhIHN0cmluZyBoYXNoIGNvZGUgYmFzZWQgb24gdGhlIHN0cmluZyBhcmd1bWVudFxuICpcbiAqIEBwYXJhbSBzdHIgdGhlIHNvdXJjZSBpbnB1dCBzdHJpbmcgdG8gaGFzaFxuICogQHJldHVybnMgc3RyaW5nIGhhc2ggY29kZVxuICovXG5mdW5jdGlvbiBoYXNoU3RyKHN0cikge1xuICB2YXIgaGFzaCA9IFwiXCI7XG4gIGZvciAodmFyIGkgPSAwOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgdmFyIHRvdGFsID0gc3RyW2ldLmNoYXJDb2RlQXQoMCkgKiBpO1xuICAgIGlmIChzdHJbaSArIDFdKSB7XG4gICAgICB0b3RhbCArPSBzdHJbaSArIDFdLmNoYXJDb2RlQXQoMCkgKiAoaSAtIDEpO1xuICAgIH1cbiAgICBoYXNoICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoOTcgKyBNYXRoLmFicyh0b3RhbCkgJSAyNik7XG4gIH1cbiAgcmV0dXJuIGhhc2g7XG59XG4vKipcbiAqIFJlYWQgYW4gb3duIHByb3BlcnR5IGZyb20gYW4gb3B0aW9ucyBvYmplY3QsIGlnbm9yaW5nIGFueSB2YWx1ZSBpbmhlcml0ZWRcbiAqIGZyb20gdGhlIHByb3RvdHlwZSBjaGFpbiwgdG8gcHJldmVudCBwcm90b3R5cGUtcG9sbHV0ZWQgdmFsdWVzIChDV0UtMTMyMSlcbiAqIGZyb20gYmVpbmcgc2lsZW50bHkgYWNjZXB0ZWQgd2hlbiB0aGUgY2FsbGVyJ3Mgb3B0aW9ucyBvYmplY3Qgb21pdHMgdGhlXG4gKiBwcm9wZXJ0eS4gTG9jYWwgY29weSBvZiB0aGUgZXF1aXZhbGVudCBoZWxwZXIgaW4gQHBheXBhbC9wYXlwYWwtanMnc1xuICogc3JjL3V0aWxzLnRzLCB3aGljaCBpc24ndCBleHBvcnRlZCBmcm9tIHRoYXQgcGFja2FnZSdzIHB1YmxpYyBlbnRyeSBwb2ludHMuXG4gKi9cbmZ1bmN0aW9uIGdldE93blByb3BlcnR5JDEob3B0aW9ucywga2V5KSB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob3B0aW9ucywga2V5KSA/IG9wdGlvbnNba2V5XSA6IHVuZGVmaW5lZDtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlRXJyb3JNZXNzYWdlKF9hKSB7XG4gIHZhciByZWFjdENvbXBvbmVudE5hbWUgPSBfYS5yZWFjdENvbXBvbmVudE5hbWUsXG4gICAgc2RrQ29tcG9uZW50S2V5ID0gX2Euc2RrQ29tcG9uZW50S2V5LFxuICAgIF9iID0gX2Euc2RrUmVxdWVzdGVkQ29tcG9uZW50cyxcbiAgICBzZGtSZXF1ZXN0ZWRDb21wb25lbnRzID0gX2IgPT09IHZvaWQgMCA/IFwiXCIgOiBfYixcbiAgICBfYyA9IF9hLnNka0RhdGFOYW1lc3BhY2UsXG4gICAgc2RrRGF0YU5hbWVzcGFjZSA9IF9jID09PSB2b2lkIDAgPyBERUZBVUxUX1BBWVBBTF9OQU1FU1BBQ0UgOiBfYztcbiAgdmFyIHJlcXVpcmVkT3B0aW9uQ2FwaXRhbGl6ZWQgPSBzZGtDb21wb25lbnRLZXkuY2hhckF0KDApLnRvVXBwZXJDYXNlKCkuY29uY2F0KHNka0NvbXBvbmVudEtleS5zdWJzdHJpbmcoMSkpO1xuICB2YXIgZXJyb3JNZXNzYWdlID0gXCJVbmFibGUgdG8gcmVuZGVyIDxcIi5jb25jYXQocmVhY3RDb21wb25lbnROYW1lLCBcIiAvPiBiZWNhdXNlIHdpbmRvdy5cIikuY29uY2F0KHNka0RhdGFOYW1lc3BhY2UsIFwiLlwiKS5jb25jYXQocmVxdWlyZWRPcHRpb25DYXBpdGFsaXplZCwgXCIgaXMgdW5kZWZpbmVkLlwiKTtcbiAgLy8gVGhlIEpTIFNESyBvbmx5IGxvYWRzIHRoZSBidXR0b25zIGNvbXBvbmVudCBieSBkZWZhdWx0LlxuICAvLyBBbGwgb3RoZXIgY29tcG9uZW50cyBsaWtlIG1lc3NhZ2VzIGFuZCBtYXJrcyBtdXN0IGJlIHJlcXVlc3RlZCB1c2luZyB0aGUgXCJjb21wb25lbnRzXCIgcXVlcnkgcGFyYW1ldGVyXG4gIHZhciByZXF1ZXN0ZWRDb21wb25lbnRzID0gdHlwZW9mIHNka1JlcXVlc3RlZENvbXBvbmVudHMgPT09IFwic3RyaW5nXCIgPyBzZGtSZXF1ZXN0ZWRDb21wb25lbnRzIDogc2RrUmVxdWVzdGVkQ29tcG9uZW50cy5qb2luKFwiLFwiKTtcbiAgaWYgKCFyZXF1ZXN0ZWRDb21wb25lbnRzLmluY2x1ZGVzKHNka0NvbXBvbmVudEtleSkpIHtcbiAgICB2YXIgZXhwZWN0ZWRDb21wb25lbnRzID0gW3JlcXVlc3RlZENvbXBvbmVudHMsIHNka0NvbXBvbmVudEtleV0uZmlsdGVyKEJvb2xlYW4pLmpvaW4oKTtcbiAgICBlcnJvck1lc3NhZ2UgKz0gXCJcXG5UbyBmaXggdGhlIGlzc3VlLCBhZGQgJ1wiLmNvbmNhdChzZGtDb21wb25lbnRLZXksIFwiJyB0byB0aGUgbGlzdCBvZiBjb21wb25lbnRzIHBhc3NlZCB0byB0aGUgcGFyZW50IFBheVBhbFNjcmlwdFByb3ZpZGVyOlwiKSArIFwiXFxuYDxQYXlQYWxTY3JpcHRQcm92aWRlciBvcHRpb25zPXt7IGNvbXBvbmVudHM6ICdcIi5jb25jYXQoZXhwZWN0ZWRDb21wb25lbnRzLCBcIid9fT5gLlwiKTtcbiAgfVxuICByZXR1cm4gZXJyb3JNZXNzYWdlO1xufVxuXG4vKipcbiAqIEdlbmVyYXRlIGEgbmV3IHJhbmRvbSBpZGVudGlmaWVyIGZvciByZWFjdC1wYXlwYWwtanNcbiAqXG4gKiBAcmV0dXJucyB0aGUge0Bjb2RlIHN0cmluZ30gY29udGFpbmluZyB0aGUgcmFuZG9tIGxpYnJhcnkgbmFtZVxuICovXG5mdW5jdGlvbiBnZXRTY3JpcHRJRChvcHRpb25zKSB7XG4gIC8vIGV4Y2x1ZGUgdGhlIGRhdGEtcmVhY3QtcGF5cGFsLXNjcmlwdC1pZCB2YWx1ZSBmcm9tIHRoZSBvcHRpb25zIGhhc2hcbiAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICB2YXIgX2EgPSBvcHRpb25zLFxuICAgIF9iID0gU0NSSVBUX0lEO1xuICBfYVtfYl07XG4gIHZhciBwYXlwYWxTY3JpcHRPcHRpb25zID0gX19yZXN0JDEoX2EsIFtfYiArIFwiXCJdKTtcbiAgcmV0dXJuIFwicmVhY3QtcGF5cGFsLWpzLVwiLmNvbmNhdChoYXNoU3RyKEpTT04uc3RyaW5naWZ5KHBheXBhbFNjcmlwdE9wdGlvbnMpKSk7XG59XG4vKipcbiAqIERlc3Ryb3kgdGhlIFBheVBhbCBTREsgZnJvbSB0aGUgZG9jdW1lbnQgcGFnZVxuICpcbiAqIEBwYXJhbSByZWFjdFBheVBhbFNjcmlwdElEIHRoZSBzY3JpcHQgaWRlbnRpZmllclxuICovXG5mdW5jdGlvbiBkZXN0cm95U0RLU2NyaXB0KHJlYWN0UGF5UGFsU2NyaXB0SUQpIHtcbiAgdmFyIHNjcmlwdE5vZGUgPSBzZWxmLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJzY3JpcHRbXCIuY29uY2F0KFNDUklQVF9JRCwgXCI9XFxcIlwiKS5jb25jYXQocmVhY3RQYXlQYWxTY3JpcHRJRCwgXCJcXFwiXVwiKSk7XG4gIGlmIChzY3JpcHROb2RlID09PSBudWxsIHx8IHNjcmlwdE5vZGUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjcmlwdE5vZGUucGFyZW50Tm9kZSkge1xuICAgIHNjcmlwdE5vZGUucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHROb2RlKTtcbiAgfVxufVxuLyoqXG4gKiBSZWR1Y2VyIGZ1bmN0aW9uIHRvIGhhbmRsZSBjb21wbGV4IHN0YXRlIGNoYW5nZXMgb24gdGhlIGNvbnRleHRcbiAqXG4gKiBAcGFyYW0gc3RhdGUgIHRoZSBjdXJyZW50IHN0YXRlIG9uIHRoZSBjb250ZXh0IG9iamVjdFxuICogQHBhcmFtIGFjdGlvbiB0aGUgYWN0aW9uIHRvIGJlIGV4ZWN1dGVkIG9uIHRoZSBwcmV2aW91cyBzdGF0ZVxuICogQHJldHVybnMgYSB0aGUgc2FtZSBzdGF0ZSBpZiB0aGUgYWN0aW9uIHdhc24ndCBmb3VuZCwgb3IgYSBuZXcgc3RhdGUgb3RoZXJ3aXNlXG4gKi9cbmZ1bmN0aW9uIHNjcmlwdFJlZHVjZXIoc3RhdGUsIGFjdGlvbikge1xuICB2YXIgX2EsIF9iO1xuICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XG4gICAgY2FzZSBESVNQQVRDSF9BQ1RJT04uTE9BRElOR19TVEFUVVM6XG4gICAgICBpZiAodHlwZW9mIGFjdGlvbi52YWx1ZSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICByZXR1cm4gX19hc3NpZ24oX19hc3NpZ24oe30sIHN0YXRlKSwge1xuICAgICAgICAgIGxvYWRpbmdTdGF0dXM6IGFjdGlvbi52YWx1ZS5zdGF0ZSxcbiAgICAgICAgICBsb2FkaW5nU3RhdHVzRXJyb3JNZXNzYWdlOiBhY3Rpb24udmFsdWUubWVzc2FnZVxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICAgIHJldHVybiBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgc3RhdGUpLCB7XG4gICAgICAgIGxvYWRpbmdTdGF0dXM6IGFjdGlvbi52YWx1ZVxuICAgICAgfSk7XG4gICAgY2FzZSBESVNQQVRDSF9BQ1RJT04uUkVTRVRfT1BUSU9OUzpcbiAgICAgIC8vIGRlc3Ryb3kgZXhpc3Rpbmcgc2NyaXB0IHRvIG1ha2Ugc3VyZSBvbmx5IG9uZSBzY3JpcHQgbG9hZHMgYXQgYSB0aW1lXG4gICAgICBkZXN0cm95U0RLU2NyaXB0KHN0YXRlLm9wdGlvbnNbU0NSSVBUX0lEXSk7XG4gICAgICByZXR1cm4gX19hc3NpZ24oX19hc3NpZ24oe30sIHN0YXRlKSwge1xuICAgICAgICBsb2FkaW5nU3RhdHVzOiBTQ1JJUFRfTE9BRElOR19TVEFURS5QRU5ESU5HLFxuICAgICAgICBvcHRpb25zOiBfX2Fzc2lnbihfX2Fzc2lnbigoX2EgPSB7fSwgX2FbU0RLX1NFVFRJTkdTLkRBVEFfU0RLX0lOVEVHUkFUSU9OX1NPVVJDRV0gPSBTREtfU0VUVElOR1MuREFUQV9MSUJSQVJZX1ZBTFVFLCBfYSksIGFjdGlvbi52YWx1ZSksIChfYiA9IHt9LCBfYltTQ1JJUFRfSURdID0gXCJcIi5jb25jYXQoZ2V0U2NyaXB0SUQoYWN0aW9uLnZhbHVlKSksIF9iKSlcbiAgICAgIH0pO1xuICAgIGNhc2UgRElTUEFUQ0hfQUNUSU9OLlNFVF9CUkFJTlRSRUVfSU5TVEFOQ0U6XG4gICAgICByZXR1cm4gX19hc3NpZ24oX19hc3NpZ24oe30sIHN0YXRlKSwge1xuICAgICAgICBicmFpbnRyZWVQYXlQYWxDaGVja291dEluc3RhbmNlOiBhY3Rpb24udmFsdWVcbiAgICAgIH0pO1xuICAgIGRlZmF1bHQ6XG4gICAgICB7XG4gICAgICAgIHJldHVybiBzdGF0ZTtcbiAgICAgIH1cbiAgfVxufVxuLy8gQ3JlYXRlIHRoZSBSZWFjdCBjb250ZXh0IHRvIHVzZSBpbiB0aGUgc2NyaXB0IHByb3ZpZGVyIGNvbXBvbmVudFxudmFyIFNjcmlwdENvbnRleHQgPSBjcmVhdGVDb250ZXh0KG51bGwpO1xuXG4vKipcbiAqIENoZWNrIGlmIHRoZSBjb250ZXh0IGlzIHZhbGlkIGFuZCByZWFkeSB0byBkaXNwYXRjaCBhY3Rpb25zLlxuICpcbiAqIEBwYXJhbSBzY3JpcHRDb250ZXh0IHRoZSByZXN1bHQgb2YgY29ubmVjdGluZyB0byB0aGUgY29udGV4dCBwcm92aWRlclxuICogQHJldHVybnMgc3RyaWN0IGNvbnRleHQgYXZvaWRpbmcgbnVsbCB2YWx1ZXMgaW4gdGhlIHR5cGVcbiAqL1xuZnVuY3Rpb24gdmFsaWRhdGVSZWR1Y2VyKHNjcmlwdENvbnRleHQpIHtcbiAgaWYgKHR5cGVvZiAoc2NyaXB0Q29udGV4dCA9PT0gbnVsbCB8fCBzY3JpcHRDb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzY3JpcHRDb250ZXh0LmRpc3BhdGNoKSA9PT0gXCJmdW5jdGlvblwiICYmIHNjcmlwdENvbnRleHQuZGlzcGF0Y2gubGVuZ3RoICE9PSAwKSB7XG4gICAgcmV0dXJuIHNjcmlwdENvbnRleHQ7XG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKFNDUklQVF9QUk9WSURFUl9SRURVQ0VSX0VSUk9SKTtcbn1cbi8qKlxuICogQ2hlY2sgaWYgdGhlIGRhdGFDbGllbnRUb2tlbiBvciB0aGUgZGF0YVVzZXJJZFRva2VuIGFyZVxuICogc2V0IGluIHRoZSBvcHRpb25zIG9mIHRoZSBjb250ZXh0LlxuICogQHR5cGUgZGF0YUNsaWVudFRva2VuIGlzIHVzZSB0byBwYXNzIGEgY2xpZW50IHRva2VuXG4gKiBAdHlwZSBkYXRhVXNlcklkVG9rZW4gaXMgdXNlIHRvIHBhc3MgYSBjbGllbnQgdG9rZW5pemF0aW9uIGtleVxuICpcbiAqIEBwYXJhbSBzY3JpcHRDb250ZXh0IHRoZSByZXN1bHQgb2YgY29ubmVjdGluZyB0byB0aGUgY29udGV4dCBwcm92aWRlclxuICogQHRocm93cyBhbiB7QGxpbmsgRXJyb3J9IGlmIGJvdGggZGF0YUNsaWVudFRva2VuIGFuZCB0aGUgZGF0YVVzZXJJZFRva2VuIGtleXMgYXJlIG51bGwgb3IgdW5kZWZpbmVkXG4gKiBAcmV0dXJucyBzdHJpY3QgY29udGV4dCBpZiBvbmUgb2YgdGhlIGtleXMgYXJlIGRlZmluZWRcbiAqL1xudmFyIHZhbGlkYXRlQnJhaW50cmVlQXV0aG9yaXphdGlvbkRhdGEgPSBmdW5jdGlvbiAoc2NyaXB0Q29udGV4dCkge1xuICB2YXIgX2EsIF9iO1xuICBpZiAoISgoX2EgPSBzY3JpcHRDb250ZXh0ID09PSBudWxsIHx8IHNjcmlwdENvbnRleHQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHNjcmlwdENvbnRleHQub3B0aW9ucykgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hW1NES19TRVRUSU5HUy5EQVRBX0NMSUVOVF9UT0tFTl0pICYmICEoKF9iID0gc2NyaXB0Q29udGV4dCA9PT0gbnVsbCB8fCBzY3JpcHRDb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBzY3JpcHRDb250ZXh0Lm9wdGlvbnMpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYltTREtfU0VUVElOR1MuREFUQV9VU0VSX0lEX1RPS0VOXSkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoRU1QVFlfQlJBSU5UUkVFX0FVVEhPUklaQVRJT05fRVJST1JfTUVTU0FHRSk7XG4gIH1cbiAgcmV0dXJuIHNjcmlwdENvbnRleHQ7XG59O1xuXG4vKipcbiAqIEN1c3RvbSBob29rIHRvIGdldCBhY2Nlc3MgdG8gdGhlIFNjcmlwdCBjb250ZXh0IGFuZFxuICogZGlzcGF0Y2ggYWN0aW9ucyB0byBtb2RpZnkgdGhlIHN0YXRlIG9uIHRoZSB7QGxpbmsgU2NyaXB0UHJvdmlkZXJ9IGNvbXBvbmVudFxuICpcbiAqIEByZXR1cm5zIGEgdHVwbGUgY29udGFpbmluZyB0aGUgc3RhdGUgb2YgdGhlIGNvbnRleHQgYW5kXG4gKiBhIGRpc3BhdGNoIGZ1bmN0aW9uIHRvIG1vZGlmeSB0aGUgc3RhdGVcbiAqL1xuZnVuY3Rpb24gdXNlUGF5UGFsU2NyaXB0UmVkdWNlcigpIHtcbiAgdmFyIHNjcmlwdENvbnRleHQgPSB2YWxpZGF0ZVJlZHVjZXIodXNlQ29udGV4dChTY3JpcHRDb250ZXh0KSk7XG4gIHZhciBkZXJpdmVkU3RhdHVzQ29udGV4dCA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCBzY3JpcHRDb250ZXh0KSwge1xuICAgIGlzSW5pdGlhbDogc2NyaXB0Q29udGV4dC5sb2FkaW5nU3RhdHVzID09PSBTQ1JJUFRfTE9BRElOR19TVEFURS5JTklUSUFMLFxuICAgIGlzUGVuZGluZzogc2NyaXB0Q29udGV4dC5sb2FkaW5nU3RhdHVzID09PSBTQ1JJUFRfTE9BRElOR19TVEFURS5QRU5ESU5HLFxuICAgIGlzUmVzb2x2ZWQ6IHNjcmlwdENvbnRleHQubG9hZGluZ1N0YXR1cyA9PT0gU0NSSVBUX0xPQURJTkdfU1RBVEUuUkVTT0xWRUQsXG4gICAgaXNSZWplY3RlZDogc2NyaXB0Q29udGV4dC5sb2FkaW5nU3RhdHVzID09PSBTQ1JJUFRfTE9BRElOR19TVEFURS5SRUpFQ1RFRFxuICB9KTtcbiAgcmV0dXJuIFtkZXJpdmVkU3RhdHVzQ29udGV4dCwgc2NyaXB0Q29udGV4dC5kaXNwYXRjaF07XG59XG4vKipcbiAqIEN1c3RvbSBob29rIHRvIGdldCBhY2Nlc3MgdG8gdGhlIFNjcmlwdFByb3ZpZGVyIGNvbnRleHRcbiAqXG4gKiBAcmV0dXJucyB0aGUgbGF0ZXN0IHN0YXRlIG9mIHRoZSBjb250ZXh0XG4gKi9cbmZ1bmN0aW9uIHVzZVNjcmlwdFByb3ZpZGVyQ29udGV4dCgpIHtcbiAgdmFyIHNjcmlwdENvbnRleHQgPSB2YWxpZGF0ZUJyYWludHJlZUF1dGhvcml6YXRpb25EYXRhKHZhbGlkYXRlUmVkdWNlcih1c2VDb250ZXh0KFNjcmlwdENvbnRleHQpKSk7XG4gIHJldHVybiBbc2NyaXB0Q29udGV4dCwgc2NyaXB0Q29udGV4dC5kaXNwYXRjaF07XG59XG5cbi8vIENyZWF0ZSB0aGUgUmVhY3QgY29udGV4dCB0byB1c2UgaW4gdGhlIFBheVBhbCBob3N0ZWQgZmllbGRzIHByb3ZpZGVyXG52YXIgUGF5UGFsSG9zdGVkRmllbGRzQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoe30pO1xuXG4vKipcbiAqIEN1c3RvbSBob29rIHRvIGdldCBhY2Nlc3MgdG8gdGhlIFBheVBhbCBIb3N0ZWQgRmllbGRzIGluc3RhbmNlLlxuICogVGhlIGluc3RhbmNlIHJlcHJlc2VudCB0aGUgcmV0dXJuZWQgb2JqZWN0IGFmdGVyIHRoZSByZW5kZXIgcHJvY2Vzc1xuICogV2l0aCB0aGlzIG9iamVjdCBhIHVzZXIgY2FuIHN1Ym1pdCB0aGUgZmllbGRzIGFuZCBkeW5hbWljYWxseSBtb2RpZnkgdGhlIGNhcmRzXG4gKlxuICogQHJldHVybnMgdGhlIGhvc3RlZCBmaWVsZHMgaW5zdGFuY2UgaWYgaXMgYXZhaWxhYmxlIGluIHRoZSBjb21wb25lbnRcbiAqL1xuZnVuY3Rpb24gdXNlUGF5UGFsSG9zdGVkRmllbGRzKCkge1xuICByZXR1cm4gdXNlQ29udGV4dChQYXlQYWxIb3N0ZWRGaWVsZHNDb250ZXh0KTtcbn1cblxuLyoqXG4gKiBgdXNlUHJveHlQcm9wc2AgY2FuIGJlIHVzZWQgdG8gbWFpbnRhaW4gYSByZWZlcmVuY2UgdG8gYW4gdXBkYXRlZCBwcm9wcywgd2l0aG91dCB0aGF0IGNoYW5nZSB0cmlnZ2VyaW5nXG4gKiBhbm90aGVyIHJlLXJlbmRlci4gVGhpcyBpcyB1c2VmdWwgaWYsIGZvciBleGFtcGxlLCBzb21lIHByb3BzIHNob3VsZCBiZSBwYXNzZWQgdGhyb3VnaCBhIHBhcmVudCBjb21wb25lbnQgdG9cbiAqIGEgY2hpbGQgZnVuY3Rpb24gdGhhdCBjb250YWlucyBjb2RlIHRoYXQgbmVlZHMgdGhlIG1vc3QgdXAtdG8tZGF0ZS1yZWZlcmVuY2UsIHdpdGhvdXQgY2F1c2luZyB0aGUgcGFyZW50IHRvXG4gKiByZXJlbmRlci5cbiAqL1xuZnVuY3Rpb24gdXNlUHJveHlQcm9wcyhwcm9wcykge1xuICB2YXIgcHJveHlSZWYgPSB1c2VSZWYobmV3IFByb3h5KHt9LCB7XG4gICAgZ2V0OiBmdW5jdGlvbiAodGFyZ2V0LCBwcm9wLCByZWNlaXZlcikge1xuICAgICAgLyoqXG4gICAgICAgKlxuICAgICAgICogSWYgdGFyZ2V0W3Byb3BdIGlzIGEgZnVuY3Rpb24sIHJldHVybiBhIGZ1bmN0aW9uIHRoYXQgYWNjZXNzZXNcbiAgICAgICAqIHRoaXMgZnVuY3Rpb24gb2ZmIHRoZSB0YXJnZXQgb2JqZWN0LiBXZSBjYW4gbXV0YXRlIHRoZSB0YXJnZXQgd2l0aFxuICAgICAgICogbmV3IGNvcGllcyBvZiB0aGlzIGZ1bmN0aW9uIHdpdGhvdXQgaGF2aW5nIHRvIHJlLXJlbmRlciB0aGVcbiAgICAgICAqIFNESyBjb21wb25lbnRzIHRvIHBhc3MgbmV3IGNhbGxiYWNrcy5cbiAgICAgICAqXG4gICAgICAgKiAqL1xuICAgICAgaWYgKHR5cGVvZiB0YXJnZXRbcHJvcF0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHZhciBhcmdzID0gW107XG4gICAgICAgICAgZm9yICh2YXIgX2kgPSAwOyBfaSA8IGFyZ3VtZW50cy5sZW5ndGg7IF9pKyspIHtcbiAgICAgICAgICAgIGFyZ3NbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXS5hcHBseSh0YXJnZXQsIGFyZ3MpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIFJlZmxlY3QuZ2V0KHRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpO1xuICAgIH1cbiAgfSkpO1xuICBwcm94eVJlZi5jdXJyZW50ID0gT2JqZWN0LmFzc2lnbihwcm94eVJlZi5jdXJyZW50LCBwcm9wcyk7XG4gIHJldHVybiBwcm94eVJlZi5jdXJyZW50O1xufVxudmFyIFBheVBhbEJ1dHRvbnNFcnJvckJvdW5kYXJ5ID0gLyoqIEBjbGFzcyAqL2Z1bmN0aW9uIChfc3VwZXIpIHtcbiAgX19leHRlbmRzKFBheVBhbEJ1dHRvbnNFcnJvckJvdW5kYXJ5LCBfc3VwZXIpO1xuICBmdW5jdGlvbiBQYXlQYWxCdXR0b25zRXJyb3JCb3VuZGFyeShwcm9wcykge1xuICAgIHZhciBfdGhpcyA9IF9zdXBlci5jYWxsKHRoaXMsIHByb3BzKSB8fCB0aGlzO1xuICAgIF90aGlzLnN0YXRlID0ge1xuICAgICAgaGFzRXJyb3I6IGZhbHNlXG4gICAgfTtcbiAgICByZXR1cm4gX3RoaXM7XG4gIH1cbiAgUGF5UGFsQnV0dG9uc0Vycm9yQm91bmRhcnkuZ2V0RGVyaXZlZFN0YXRlRnJvbUVycm9yID0gZnVuY3Rpb24gKCkge1xuICAgIHJldHVybiB7XG4gICAgICBoYXNFcnJvcjogdHJ1ZVxuICAgIH07XG4gIH07XG4gIFBheVBhbEJ1dHRvbnNFcnJvckJvdW5kYXJ5LnByb3RvdHlwZS5jb21wb25lbnREaWRDYXRjaCA9IGZ1bmN0aW9uIChlcnJvciwgZXJyb3JJbmZvKSB7XG4gICAgY29uc29sZS5lcnJvcihcIkVycm9yIGluIFBheVBhbEJ1dHRvbnMgY29tcG9uZW50OlwiLCBlcnJvciwgZXJyb3JJbmZvKTtcbiAgICAvLyBpZiBvbkVycm9yIGNhbGxiYWNrIGlzIHByb3ZpZGVkLCBjYWxsIGl0IHdpdGggdGhlIGVycm9yIGRldGFpbHNcbiAgICAvLyBkb24ndCByZXRocm93IHRoZSBlcnJvciwgYXMgd2Ugd2FudCB0byBwcmV2ZW50IHRoZSBlbnRpcmUgYXBwIGZyb20gY3Jhc2hpbmdcbiAgICBpZiAodHlwZW9mIHRoaXMucHJvcHMub25FcnJvciA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICB0aGlzLnByb3BzLm9uRXJyb3Ioe1xuICAgICAgICBtZXNzYWdlOiBlcnJvci5tZXNzYWdlLFxuICAgICAgICBuYW1lOiBlcnJvci5uYW1lLFxuICAgICAgICBzdGFjazogZXJyb3Iuc3RhY2ssXG4gICAgICAgIGNvbXBvbmVudFN0YWNrOiBlcnJvckluZm8uY29tcG9uZW50U3RhY2tcbiAgICAgIH0pO1xuICAgIH1cbiAgfTtcbiAgUGF5UGFsQnV0dG9uc0Vycm9yQm91bmRhcnkucHJvdG90eXBlLnJlbmRlciA9IGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodGhpcy5zdGF0ZS5oYXNFcnJvcikge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnByb3BzLmNoaWxkcmVuO1xuICB9O1xuICByZXR1cm4gUGF5UGFsQnV0dG9uc0Vycm9yQm91bmRhcnk7XG59KENvbXBvbmVudCk7XG5cbi8qKlxuVGhlIGlubmVyIGNvbXBvbmVudCB0aGF0IHJlbmRlcnMgdGhlIFBheVBhbCBidXR0b25zLiBUaGlzIGNvbXBvbmVudCBpcyB3cmFwcGVkIGluIGFuIGVycm9yIGJvdW5kYXJ5IHRvIGNhdGNoIGFuZCBoYW5kbGUgYW55IGVycm9ycyB0aGF0IG1heSBvY2N1ciBkdXJpbmcgcmVuZGVyaW5nIG9yIGludGVyYWN0aW9uIHdpdGggdGhlIFBheVBhbCBidXR0b25zLlxuICovXG52YXIgUGF5UGFsQnV0dG9uc0lubmVyID0gZnVuY3Rpb24gKF9hKSB7XG4gIHZhciBfYjtcbiAgdmFyIF9jID0gX2EuY2xhc3NOYW1lLFxuICAgIGNsYXNzTmFtZSA9IF9jID09PSB2b2lkIDAgPyBcIlwiIDogX2MsXG4gICAgX2QgPSBfYS5kaXNhYmxlZCxcbiAgICBkaXNhYmxlZCA9IF9kID09PSB2b2lkIDAgPyBmYWxzZSA6IF9kLFxuICAgIGNoaWxkcmVuID0gX2EuY2hpbGRyZW4sXG4gICAgX2UgPSBfYS5mb3JjZVJlUmVuZGVyLFxuICAgIGZvcmNlUmVSZW5kZXIgPSBfZSA9PT0gdm9pZCAwID8gW10gOiBfZSxcbiAgICBidXR0b25Qcm9wcyA9IF9fcmVzdCQxKF9hLCBbXCJjbGFzc05hbWVcIiwgXCJkaXNhYmxlZFwiLCBcImNoaWxkcmVuXCIsIFwiZm9yY2VSZVJlbmRlclwiXSk7XG4gIHZhciBpc0Rpc2FibGVkU3R5bGUgPSBkaXNhYmxlZCA/IHtcbiAgICBvcGFjaXR5OiAwLjM4XG4gIH0gOiB7fTtcbiAgdmFyIGNsYXNzTmFtZXMgPSBcIlwiLmNvbmNhdChjbGFzc05hbWUsIFwiIFwiKS5jb25jYXQoZGlzYWJsZWQgPyBcInBheXBhbC1idXR0b25zLWRpc2FibGVkXCIgOiBcIlwiKS50cmltKCk7XG4gIHZhciBidXR0b25zQ29udGFpbmVyUmVmID0gdXNlUmVmKG51bGwpO1xuICB2YXIgYnV0dG9ucyA9IHVzZVJlZihudWxsKTtcbiAgdmFyIHByb3h5UHJvcHMgPSB1c2VQcm94eVByb3BzKGJ1dHRvblByb3BzKTtcbiAgdmFyIF9mID0gdXNlUGF5UGFsU2NyaXB0UmVkdWNlcigpWzBdLFxuICAgIGlzUmVzb2x2ZWQgPSBfZi5pc1Jlc29sdmVkLFxuICAgIG9wdGlvbnMgPSBfZi5vcHRpb25zO1xuICB2YXIgX2cgPSB1c2VTdGF0ZShudWxsKSxcbiAgICBpbml0QWN0aW9ucyA9IF9nWzBdLFxuICAgIHNldEluaXRBY3Rpb25zID0gX2dbMV07XG4gIHZhciBfaCA9IHVzZVN0YXRlKHRydWUpLFxuICAgIGlzRWxpZ2libGUgPSBfaFswXSxcbiAgICBzZXRJc0VsaWdpYmxlID0gX2hbMV07XG4gIHZhciBfaiA9IHVzZVN0YXRlKG51bGwpLFxuICAgIHNldEVycm9yU3RhdGUgPSBfalsxXTtcbiAgZnVuY3Rpb24gY2xvc2VCdXR0b25zQ29tcG9uZW50KCkge1xuICAgIGlmIChidXR0b25zLmN1cnJlbnQgIT09IG51bGwpIHtcbiAgICAgIGJ1dHRvbnMuY3VycmVudC5jbG9zZSgpLmNhdGNoKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgLy8gaWdub3JlIGVycm9ycyB3aGVuIGNsb3NpbmcgdGhlIGNvbXBvbmVudFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGlmICgoX2IgPSBidXR0b25zLmN1cnJlbnQpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi51cGRhdGVQcm9wcykge1xuICAgIGJ1dHRvbnMuY3VycmVudC51cGRhdGVQcm9wcyh7XG4gICAgICBtZXNzYWdlOiBidXR0b25Qcm9wcy5tZXNzYWdlXG4gICAgfSk7XG4gIH1cbiAgLy8gdXNlRWZmZWN0IGhvb2sgZm9yIHJlbmRlcmluZyB0aGUgYnV0dG9uc1xuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIC8vIHZlcmlmeSB0aGUgc2RrIHNjcmlwdCBoYXMgc3VjY2Vzc2Z1bGx5IGxvYWRlZFxuICAgIGlmIChpc1Jlc29sdmVkID09PSBmYWxzZSkge1xuICAgICAgcmV0dXJuIGNsb3NlQnV0dG9uc0NvbXBvbmVudDtcbiAgICB9XG4gICAgdmFyIHBheXBhbFdpbmRvd05hbWVzcGFjZSA9IGdldFBheVBhbFdpbmRvd05hbWVzcGFjZSQxKGdldE93blByb3BlcnR5JDEob3B0aW9ucywgXCJkYXRhTmFtZXNwYWNlXCIpKTtcbiAgICAvLyB2ZXJpZnkgZGVwZW5kZW5jeSBvbiB3aW5kb3cgb2JqZWN0XG4gICAgaWYgKHBheXBhbFdpbmRvd05hbWVzcGFjZSA9PT0gdW5kZWZpbmVkIHx8IHBheXBhbFdpbmRvd05hbWVzcGFjZS5CdXR0b25zID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHNldEVycm9yU3RhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZ2VuZXJhdGVFcnJvck1lc3NhZ2Uoe1xuICAgICAgICAgIHJlYWN0Q29tcG9uZW50TmFtZTogUGF5UGFsQnV0dG9ucy5kaXNwbGF5TmFtZSxcbiAgICAgICAgICBzZGtDb21wb25lbnRLZXk6IFwiYnV0dG9uc1wiLFxuICAgICAgICAgIHNka1JlcXVlc3RlZENvbXBvbmVudHM6IG9wdGlvbnMuY29tcG9uZW50cyxcbiAgICAgICAgICBzZGtEYXRhTmFtZXNwYWNlOiBnZXRPd25Qcm9wZXJ0eSQxKG9wdGlvbnMsIFwiZGF0YU5hbWVzcGFjZVwiKVxuICAgICAgICB9KSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBjbG9zZUJ1dHRvbnNDb21wb25lbnQ7XG4gICAgfVxuICAgIHZhciBkZWNvcmF0ZWRPbkluaXQgPSBmdW5jdGlvbiAoZGF0YSwgYWN0aW9ucykge1xuICAgICAgc2V0SW5pdEFjdGlvbnMoYWN0aW9ucyk7XG4gICAgICBpZiAodHlwZW9mIGJ1dHRvblByb3BzLm9uSW5pdCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgIGJ1dHRvblByb3BzLm9uSW5pdChkYXRhLCBhY3Rpb25zKTtcbiAgICAgIH1cbiAgICB9O1xuICAgIHRyeSB7XG4gICAgICBidXR0b25zLmN1cnJlbnQgPSBwYXlwYWxXaW5kb3dOYW1lc3BhY2UuQnV0dG9ucyhfX2Fzc2lnbihfX2Fzc2lnbih7fSwgcHJveHlQcm9wcyksIHtcbiAgICAgICAgb25Jbml0OiBkZWNvcmF0ZWRPbkluaXRcbiAgICAgIH0pKTtcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHJldHVybiBzZXRFcnJvclN0YXRlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHJlbmRlciA8UGF5UGFsQnV0dG9ucyAvPiBjb21wb25lbnQuIEZhaWxlZCB0byBpbml0aWFsaXplOiAgXCIuY29uY2F0KGVycikpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIC8vIG9ubHkgcmVuZGVyIHRoZSBidXR0b24gd2hlbiBlbGlnaWJsZVxuICAgIGlmIChidXR0b25zLmN1cnJlbnQuaXNFbGlnaWJsZSgpID09PSBmYWxzZSkge1xuICAgICAgc2V0SXNFbGlnaWJsZShmYWxzZSk7XG4gICAgICByZXR1cm4gY2xvc2VCdXR0b25zQ29tcG9uZW50O1xuICAgIH1cbiAgICBpZiAoIWJ1dHRvbnNDb250YWluZXJSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuIGNsb3NlQnV0dG9uc0NvbXBvbmVudDtcbiAgICB9XG4gICAgYnV0dG9ucy5jdXJyZW50LnJlbmRlcihidXR0b25zQ29udGFpbmVyUmVmLmN1cnJlbnQpLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIC8vIGNvbXBvbmVudCBmYWlsZWQgdG8gcmVuZGVyLCBwb3NzaWJseSBiZWNhdXNlIGl0IHdhcyBjbG9zZWQgb3IgZGVzdHJveWVkLlxuICAgICAgaWYgKGJ1dHRvbnNDb250YWluZXJSZWYuY3VycmVudCA9PT0gbnVsbCB8fCBidXR0b25zQ29udGFpbmVyUmVmLmN1cnJlbnQuY2hpbGRyZW4ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIC8vIHBheXBhbCBidXR0b25zIGNvbnRhaW5lciBpcyBubyBsb25nZXIgaW4gdGhlIERPTSwgd2UgY2FuIHNhZmVseSBpZ25vcmUgdGhlIGVycm9yXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIHBheXBhbCBidXR0b25zIGNvbnRhaW5lciBpcyBzdGlsbCBpbiB0aGUgRE9NXG4gICAgICBzZXRFcnJvclN0YXRlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHJlbmRlciA8UGF5UGFsQnV0dG9ucyAvPiBjb21wb25lbnQuIFwiLmNvbmNhdChlcnIpKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIHJldHVybiBjbG9zZUJ1dHRvbnNDb21wb25lbnQ7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHJlYWN0LWhvb2tzL2V4aGF1c3RpdmUtZGVwc1xuICB9LCBfX3NwcmVhZEFycmF5KF9fc3ByZWFkQXJyYXkoW2lzUmVzb2x2ZWRdLCBmb3JjZVJlUmVuZGVyLCB0cnVlKSwgW2J1dHRvblByb3BzLmZ1bmRpbmdTb3VyY2VdLCBmYWxzZSkpO1xuICAvLyB1c2VFZmZlY3QgaG9vayBmb3IgbWFuYWdpbmcgZGlzYWJsZWQgc3RhdGVcbiAgdXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoaW5pdEFjdGlvbnMgPT09IG51bGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKGRpc2FibGVkID09PSB0cnVlKSB7XG4gICAgICBpbml0QWN0aW9ucy5kaXNhYmxlKCkuY2F0Y2goZnVuY3Rpb24gKCkge1xuICAgICAgICAvLyBpZ25vcmUgZXJyb3JzIHdoZW4gZGlzYWJsaW5nIHRoZSBjb21wb25lbnRcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBpbml0QWN0aW9ucy5lbmFibGUoKS5jYXRjaChmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8vIGlnbm9yZSBlcnJvcnMgd2hlbiBlbmFibGluZyB0aGUgY29tcG9uZW50XG4gICAgICB9KTtcbiAgICB9XG4gIH0sIFtkaXNhYmxlZCwgaW5pdEFjdGlvbnNdKTtcbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUmVhY3QuRnJhZ21lbnQsIG51bGwsIGlzRWxpZ2libGUgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHtcbiAgICByZWY6IGJ1dHRvbnNDb250YWluZXJSZWYsXG4gICAgc3R5bGU6IGlzRGlzYWJsZWRTdHlsZSxcbiAgICBjbGFzc05hbWU6IGNsYXNzTmFtZXNcbiAgfSkgOiBjaGlsZHJlbik7XG59O1xuUGF5UGFsQnV0dG9uc0lubmVyLmRpc3BsYXlOYW1lID0gXCJQYXlQYWxCdXR0b25zXCI7XG4vKipcblRoaXMgYDxQYXlQYWxCdXR0b25zIC8+YCBjb21wb25lbnQgc3VwcG9ydHMgcmVuZGVyaW5nIFtidXR0b25zXShodHRwczovL2RldmVsb3Blci5wYXlwYWwuY29tL2RvY3MvYnVzaW5lc3MvamF2YXNjcmlwdC1zZGsvamF2YXNjcmlwdC1zZGstcmVmZXJlbmNlLyNidXR0b25zKSBmb3IgUGF5UGFsLCBWZW5tbywgYW5kIGFsdGVybmF0aXZlIHBheW1lbnQgbWV0aG9kcy5cbkl0IHJlbGllcyBvbiB0aGUgYDxQYXlQYWxTY3JpcHRQcm92aWRlciAvPmAgcGFyZW50IGNvbXBvbmVudCBmb3IgbWFuYWdpbmcgc3RhdGUgcmVsYXRlZCB0byBsb2FkaW5nIHRoZSBKUyBTREsgc2NyaXB0LlxuKi9cbnZhciBQYXlQYWxCdXR0b25zID0gZnVuY3Rpb24gKHByb3BzKSB7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbEJ1dHRvbnNFcnJvckJvdW5kYXJ5LCB7XG4gICAgb25FcnJvcjogcHJvcHMub25FcnJvclxuICB9LCBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbEJ1dHRvbnNJbm5lciwgX19hc3NpZ24oe30sIHByb3BzKSkpO1xufTtcblBheVBhbEJ1dHRvbnMuZGlzcGxheU5hbWUgPSBcIlBheVBhbEJ1dHRvbnNcIjtcbmZ1bmN0aW9uIF9fcmVzdChzLCBlKSB7XG4gIHZhciB0ID0ge307XG4gIGZvciAodmFyIHAgaW4gcykgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChzLCBwKSAmJiBlLmluZGV4T2YocCkgPCAwKSB0W3BdID0gc1twXTtcbiAgaWYgKHMgIT0gbnVsbCAmJiB0eXBlb2YgT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyA9PT0gXCJmdW5jdGlvblwiKSBmb3IgKHZhciBpID0gMCwgcCA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMocyk7IGkgPCBwLmxlbmd0aDsgaSsrKSB7XG4gICAgaWYgKGUuaW5kZXhPZihwW2ldKSA8IDAgJiYgT2JqZWN0LnByb3RvdHlwZS5wcm9wZXJ0eUlzRW51bWVyYWJsZS5jYWxsKHMsIHBbaV0pKSB0W3BbaV1dID0gc1twW2ldXTtcbiAgfVxuICByZXR1cm4gdDtcbn1cbnR5cGVvZiBTdXBwcmVzc2VkRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IFN1cHByZXNzZWRFcnJvciA6IGZ1bmN0aW9uIChlcnJvciwgc3VwcHJlc3NlZCwgbWVzc2FnZSkge1xuICB2YXIgZSA9IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgcmV0dXJuIGUubmFtZSA9IFwiU3VwcHJlc3NlZEVycm9yXCIsIGUuZXJyb3IgPSBlcnJvciwgZS5zdXBwcmVzc2VkID0gc3VwcHJlc3NlZCwgZTtcbn07XG5mdW5jdGlvbiBmaW5kU2NyaXB0KHVybCwgYXR0cmlidXRlcykge1xuICB2YXIgY3VycmVudFNjcmlwdCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoXCJzY3JpcHRbc3JjPVxcXCJcIi5jb25jYXQodXJsLCBcIlxcXCJdXCIpKTtcbiAgaWYgKGN1cnJlbnRTY3JpcHQgPT09IG51bGwpIHJldHVybiBudWxsO1xuICB2YXIgbmV4dFNjcmlwdCA9IGNyZWF0ZVNjcmlwdEVsZW1lbnQodXJsLCBhdHRyaWJ1dGVzKTtcbiAgdmFyIGN1cnJlbnRTY3JpcHRDbG9uZSA9IGN1cnJlbnRTY3JpcHQuY2xvbmVOb2RlKCk7XG4gIGRlbGV0ZSBjdXJyZW50U2NyaXB0Q2xvbmUuZGF0YXNldC51aWRBdXRvO1xuICBpZiAoT2JqZWN0LmtleXMoY3VycmVudFNjcmlwdENsb25lLmRhdGFzZXQpLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMobmV4dFNjcmlwdC5kYXRhc2V0KS5sZW5ndGgpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuICB2YXIgaXNFeGFjdE1hdGNoID0gdHJ1ZTtcbiAgT2JqZWN0LmtleXMoY3VycmVudFNjcmlwdENsb25lLmRhdGFzZXQpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgIGlmIChjdXJyZW50U2NyaXB0Q2xvbmUuZGF0YXNldFtrZXldICE9PSBuZXh0U2NyaXB0LmRhdGFzZXRba2V5XSkge1xuICAgICAgaXNFeGFjdE1hdGNoID0gZmFsc2U7XG4gICAgfVxuICB9KTtcbiAgcmV0dXJuIGlzRXhhY3RNYXRjaCA/IGN1cnJlbnRTY3JpcHQgOiBudWxsO1xufVxuZnVuY3Rpb24gaW5zZXJ0U2NyaXB0RWxlbWVudChfYSkge1xuICB2YXIgdXJsID0gX2EudXJsLFxuICAgIGF0dHJpYnV0ZXMgPSBfYS5hdHRyaWJ1dGVzLFxuICAgIG9uU3VjY2VzcyA9IF9hLm9uU3VjY2VzcyxcbiAgICBvbkVycm9yID0gX2Eub25FcnJvcjtcbiAgdmFyIG5ld1NjcmlwdCA9IGNyZWF0ZVNjcmlwdEVsZW1lbnQodXJsLCBhdHRyaWJ1dGVzKTtcbiAgbmV3U2NyaXB0Lm9uZXJyb3IgPSBvbkVycm9yO1xuICBuZXdTY3JpcHQub25sb2FkID0gb25TdWNjZXNzO1xuICBkb2N1bWVudC5oZWFkLmluc2VydEJlZm9yZShuZXdTY3JpcHQsIGRvY3VtZW50LmhlYWQuZmlyc3RFbGVtZW50Q2hpbGQpO1xufVxuZnVuY3Rpb24gcHJvY2Vzc09wdGlvbnMob3B0aW9ucykge1xuICB2YXIgY3VzdG9tU2RrQmFzZVVybCA9IGdldE93blByb3BlcnR5KG9wdGlvbnMsIFwic2RrQmFzZVVybFwiKTtcbiAgdmFyIGVudmlyb25tZW50ID0gZ2V0T3duUHJvcGVydHkob3B0aW9ucywgXCJlbnZpcm9ubWVudFwiKTtcbiAgb3B0aW9ucy5lbnZpcm9ubWVudDtcbiAgb3B0aW9ucy5zZGtCYXNlVXJsO1xuICB2YXIgcmVzdCA9IF9fcmVzdChvcHRpb25zLCBbXCJlbnZpcm9ubWVudFwiLCBcInNka0Jhc2VVcmxcIl0pO1xuICB2YXIgc2RrQmFzZVVybCA9IGN1c3RvbVNka0Jhc2VVcmwgfHwgcHJvY2Vzc1Nka0Jhc2VVcmwoZW52aXJvbm1lbnQpO1xuICB2YXIgb3B0aW9uc1dpdGhTdHJpbmdJbmRleCA9IHJlc3Q7XG4gIHZhciBfYSA9IE9iamVjdC5rZXlzKG9wdGlvbnNXaXRoU3RyaW5nSW5kZXgpLmZpbHRlcihmdW5jdGlvbiAoa2V5KSB7XG4gICAgICByZXR1cm4gdHlwZW9mIG9wdGlvbnNXaXRoU3RyaW5nSW5kZXhba2V5XSAhPT0gXCJ1bmRlZmluZWRcIiAmJiBvcHRpb25zV2l0aFN0cmluZ0luZGV4W2tleV0gIT09IG51bGwgJiYgb3B0aW9uc1dpdGhTdHJpbmdJbmRleFtrZXldICE9PSBcIlwiO1xuICAgIH0pLnJlZHVjZShmdW5jdGlvbiAoYWNjdW11bGF0b3IsIGtleSkge1xuICAgICAgdmFyIHZhbHVlID0gb3B0aW9uc1dpdGhTdHJpbmdJbmRleFtrZXldLnRvU3RyaW5nKCk7XG4gICAgICBrZXkgPSBjYW1lbENhc2VUb0tlYmFiQ2FzZShrZXkpO1xuICAgICAgaWYgKGtleS5zdWJzdHJpbmcoMCwgNCkgPT09IFwiZGF0YVwiIHx8IGtleSA9PT0gXCJjcm9zc29yaWdpblwiKSB7XG4gICAgICAgIGFjY3VtdWxhdG9yLmF0dHJpYnV0ZXNba2V5XSA9IHZhbHVlO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgYWNjdW11bGF0b3IucXVlcnlQYXJhbXNba2V5XSA9IHZhbHVlO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH0sIHtcbiAgICAgIHF1ZXJ5UGFyYW1zOiB7fSxcbiAgICAgIGF0dHJpYnV0ZXM6IHt9XG4gICAgfSksXG4gICAgcXVlcnlQYXJhbXMgPSBfYS5xdWVyeVBhcmFtcyxcbiAgICBhdHRyaWJ1dGVzID0gX2EuYXR0cmlidXRlcztcbiAgdmFyIG1lcmNoYW50SWQgPSBnZXRPd25Qcm9wZXJ0eShxdWVyeVBhcmFtcywgXCJtZXJjaGFudC1pZFwiKTtcbiAgaWYgKG1lcmNoYW50SWQgJiYgbWVyY2hhbnRJZC5pbmRleE9mKFwiLFwiKSAhPT0gLTEpIHtcbiAgICBhdHRyaWJ1dGVzW1wiZGF0YS1tZXJjaGFudC1pZFwiXSA9IG1lcmNoYW50SWQ7XG4gICAgcXVlcnlQYXJhbXNbXCJtZXJjaGFudC1pZFwiXSA9IFwiKlwiO1xuICB9XG4gIHJldHVybiB7XG4gICAgdXJsOiBcIlwiLmNvbmNhdChzZGtCYXNlVXJsLCBcIj9cIikuY29uY2F0KG9iamVjdFRvUXVlcnlTdHJpbmcocXVlcnlQYXJhbXMpKSxcbiAgICBhdHRyaWJ1dGVzOiBhdHRyaWJ1dGVzXG4gIH07XG59XG5mdW5jdGlvbiBjYW1lbENhc2VUb0tlYmFiQ2FzZShzdHIpIHtcbiAgdmFyIHJlcGxhY2VyID0gZnVuY3Rpb24gKG1hdGNoLCBpbmRleE9mTWF0Y2gpIHtcbiAgICByZXR1cm4gKGluZGV4T2ZNYXRjaCA/IFwiLVwiIDogXCJcIikgKyBtYXRjaC50b0xvd2VyQ2FzZSgpO1xuICB9O1xuICByZXR1cm4gc3RyLnJlcGxhY2UoL1tBLVpdKyg/IVthLXpdKXxbQS1aXS9nLCByZXBsYWNlcik7XG59XG5mdW5jdGlvbiBvYmplY3RUb1F1ZXJ5U3RyaW5nKHBhcmFtcykge1xuICB2YXIgcXVlcnlTdHJpbmcgPSBcIlwiO1xuICBPYmplY3Qua2V5cyhwYXJhbXMpLmZvckVhY2goZnVuY3Rpb24gKGtleSkge1xuICAgIGlmIChxdWVyeVN0cmluZy5sZW5ndGggIT09IDApIHF1ZXJ5U3RyaW5nICs9IFwiJlwiO1xuICAgIHF1ZXJ5U3RyaW5nICs9IGtleSArIFwiPVwiICsgcGFyYW1zW2tleV07XG4gIH0pO1xuICByZXR1cm4gcXVlcnlTdHJpbmc7XG59XG5mdW5jdGlvbiBwcm9jZXNzU2RrQmFzZVVybChlbnZpcm9ubWVudCkge1xuICByZXR1cm4gZW52aXJvbm1lbnQgPT09IFwic2FuZGJveFwiID8gXCJodHRwczovL3d3dy5zYW5kYm94LnBheXBhbC5jb20vc2RrL2pzXCIgOiBcImh0dHBzOi8vd3d3LnBheXBhbC5jb20vc2RrL2pzXCI7XG59XG5mdW5jdGlvbiBjcmVhdGVTY3JpcHRFbGVtZW50KHVybCwgYXR0cmlidXRlcykge1xuICBpZiAoYXR0cmlidXRlcyA9PT0gdm9pZCAwKSB7XG4gICAgYXR0cmlidXRlcyA9IHt9O1xuICB9XG4gIHZhciBuZXdTY3JpcHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwic2NyaXB0XCIpO1xuICBuZXdTY3JpcHQuc3JjID0gdXJsO1xuICBPYmplY3Qua2V5cyhhdHRyaWJ1dGVzKS5mb3JFYWNoKGZ1bmN0aW9uIChrZXkpIHtcbiAgICBuZXdTY3JpcHQuc2V0QXR0cmlidXRlKGtleSwgYXR0cmlidXRlc1trZXldKTtcbiAgICBpZiAoa2V5ID09PSBcImRhdGEtY3NwLW5vbmNlXCIpIHtcbiAgICAgIG5ld1NjcmlwdC5zZXRBdHRyaWJ1dGUoXCJub25jZVwiLCBhdHRyaWJ1dGVzW1wiZGF0YS1jc3Atbm9uY2VcIl0pO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiBuZXdTY3JpcHQ7XG59XG5mdW5jdGlvbiBnZXRPd25Qcm9wZXJ0eShvcHRpb25zLCBrZXkpIHtcbiAgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvcHRpb25zLCBrZXkpID8gb3B0aW9uc1trZXldIDogdW5kZWZpbmVkO1xufVxuZnVuY3Rpb24gbG9hZFNjcmlwdChvcHRpb25zLCBQcm9taXNlUG9ueWZpbGwpIHtcbiAgaWYgKFByb21pc2VQb255ZmlsbCA9PT0gdm9pZCAwKSB7XG4gICAgUHJvbWlzZVBvbnlmaWxsID0gUHJvbWlzZTtcbiAgfVxuICB2YWxpZGF0ZUFyZ3VtZW50cyhvcHRpb25zLCBQcm9taXNlUG9ueWZpbGwpO1xuICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gUHJvbWlzZVBvbnlmaWxsLnJlc29sdmUobnVsbCk7XG4gIHZhciBfYSA9IHByb2Nlc3NPcHRpb25zKG9wdGlvbnMpLFxuICAgIHVybCA9IF9hLnVybCxcbiAgICBhdHRyaWJ1dGVzID0gX2EuYXR0cmlidXRlcztcbiAgdmFyIG5hbWVzcGFjZSA9IGdldE93blByb3BlcnR5KGF0dHJpYnV0ZXMsIFwiZGF0YS1uYW1lc3BhY2VcIikgfHwgXCJwYXlwYWxcIjtcbiAgdmFyIGV4aXN0aW5nV2luZG93TmFtZXNwYWNlID0gZ2V0UGF5UGFsV2luZG93TmFtZXNwYWNlKG5hbWVzcGFjZSk7XG4gIGlmICghZ2V0T3duUHJvcGVydHkoYXR0cmlidXRlcywgXCJkYXRhLWpzLXNkay1saWJyYXJ5XCIpKSB7XG4gICAgYXR0cmlidXRlc1tcImRhdGEtanMtc2RrLWxpYnJhcnlcIl0gPSBcInBheXBhbC1qc1wiO1xuICB9XG4gIGlmIChmaW5kU2NyaXB0KHVybCwgYXR0cmlidXRlcykgJiYgZXhpc3RpbmdXaW5kb3dOYW1lc3BhY2UpIHtcbiAgICByZXR1cm4gUHJvbWlzZVBvbnlmaWxsLnJlc29sdmUoZXhpc3RpbmdXaW5kb3dOYW1lc3BhY2UpO1xuICB9XG4gIHJldHVybiBsb2FkQ3VzdG9tU2NyaXB0KHtcbiAgICB1cmw6IHVybCxcbiAgICBhdHRyaWJ1dGVzOiBhdHRyaWJ1dGVzXG4gIH0sIFByb21pc2VQb255ZmlsbCkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgdmFyIG5ld1dpbmRvd05hbWVzcGFjZSA9IGdldFBheVBhbFdpbmRvd05hbWVzcGFjZShuYW1lc3BhY2UpO1xuICAgIGlmIChuZXdXaW5kb3dOYW1lc3BhY2UpIHtcbiAgICAgIHJldHVybiBuZXdXaW5kb3dOYW1lc3BhY2U7XG4gICAgfVxuICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSB3aW5kb3cuXCIuY29uY2F0KG5hbWVzcGFjZSwgXCIgZ2xvYmFsIHZhcmlhYmxlIGlzIG5vdCBhdmFpbGFibGUuXCIpKTtcbiAgfSk7XG59XG5mdW5jdGlvbiBsb2FkQ3VzdG9tU2NyaXB0KG9wdGlvbnMsIFByb21pc2VQb255ZmlsbCkge1xuICBpZiAoUHJvbWlzZVBvbnlmaWxsID09PSB2b2lkIDApIHtcbiAgICBQcm9taXNlUG9ueWZpbGwgPSBQcm9taXNlO1xuICB9XG4gIHZhbGlkYXRlQXJndW1lbnRzKG9wdGlvbnMsIFByb21pc2VQb255ZmlsbCk7XG4gIHZhciB1cmwgPSBnZXRPd25Qcm9wZXJ0eShvcHRpb25zLCBcInVybFwiKTtcbiAgdmFyIGF0dHJpYnV0ZXMgPSBnZXRPd25Qcm9wZXJ0eShvcHRpb25zLCBcImF0dHJpYnV0ZXNcIik7XG4gIGlmICh0eXBlb2YgdXJsICE9PSBcInN0cmluZ1wiIHx8IHVybC5sZW5ndGggPT09IDApIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHVybC5cIik7XG4gIH1cbiAgaWYgKHR5cGVvZiBhdHRyaWJ1dGVzICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiBhdHRyaWJ1dGVzICE9PSBcIm9iamVjdFwiKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiRXhwZWN0ZWQgYXR0cmlidXRlcyB0byBiZSBhbiBvYmplY3QuXCIpO1xuICB9XG4gIHJldHVybiBuZXcgUHJvbWlzZVBvbnlmaWxsKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSByZXR1cm4gcmVzb2x2ZSgpO1xuICAgIGluc2VydFNjcmlwdEVsZW1lbnQoe1xuICAgICAgdXJsOiB1cmwsXG4gICAgICBhdHRyaWJ1dGVzOiBhdHRyaWJ1dGVzLFxuICAgICAgb25TdWNjZXNzOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiByZXNvbHZlKCk7XG4gICAgICB9LFxuICAgICAgb25FcnJvcjogZnVuY3Rpb24gKCkge1xuICAgICAgICB2YXIgZGVmYXVsdEVycm9yID0gbmV3IEVycm9yKFwiVGhlIHNjcmlwdCBcXFwiXCIuY29uY2F0KHVybCwgXCJcXFwiIGZhaWxlZCB0byBsb2FkLiBDaGVjayB0aGUgSFRUUCBzdGF0dXMgY29kZSBhbmQgcmVzcG9uc2UgYm9keSBpbiBEZXZUb29scyB0byBsZWFybiBtb3JlLlwiKSk7XG4gICAgICAgIHJldHVybiByZWplY3QoZGVmYXVsdEVycm9yKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG59XG5mdW5jdGlvbiBnZXRQYXlQYWxXaW5kb3dOYW1lc3BhY2UobmFtZXNwYWNlKSB7XG4gIHJldHVybiB3aW5kb3dbbmFtZXNwYWNlXTtcbn1cbmZ1bmN0aW9uIHZhbGlkYXRlQXJndW1lbnRzKG9wdGlvbnMsIFByb21pc2VQb255ZmlsbCkge1xuICBpZiAodHlwZW9mIG9wdGlvbnMgIT09IFwib2JqZWN0XCIgfHwgb3B0aW9ucyA9PT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIGFuIG9wdGlvbnMgb2JqZWN0LlwiKTtcbiAgfVxuICB2YXIgZW52aXJvbm1lbnQgPSBnZXRPd25Qcm9wZXJ0eShvcHRpb25zLCBcImVudmlyb25tZW50XCIpO1xuICBpZiAoZW52aXJvbm1lbnQgJiYgZW52aXJvbm1lbnQgIT09IFwicHJvZHVjdGlvblwiICYmIGVudmlyb25tZW50ICE9PSBcInNhbmRib3hcIikge1xuICAgIHRocm93IG5ldyBFcnJvcignVGhlIGBlbnZpcm9ubWVudGAgb3B0aW9uIG11c3QgYmUgZWl0aGVyIFwicHJvZHVjdGlvblwiIG9yIFwic2FuZGJveFwiLicpO1xuICB9XG4gIGlmICh0eXBlb2YgUHJvbWlzZVBvbnlmaWxsICE9PSBcInVuZGVmaW5lZFwiICYmIHR5cGVvZiBQcm9taXNlUG9ueWZpbGwgIT09IFwiZnVuY3Rpb25cIikge1xuICAgIHRocm93IG5ldyBFcnJvcihcIkV4cGVjdGVkIFByb21pc2VQb255ZmlsbCB0byBiZSBhIGZ1bmN0aW9uLlwiKTtcbiAgfVxufVxuXG4vKipcbiAqIFNpbXBsZSBjaGVjayB0byBkZXRlcm1pbmUgaWYgdGhlIEJyYWludHJlZSBpcyBhIHZhbGlkIG5hbWVzcGFjZS5cbiAqXG4gKiBAcGFyYW0gYnJhaW50cmVlU291cmNlIHRoZSBzb3VyY2Uge0BsaW5rIEJyYWludHJlZU5hbWVzcGFjZX1cbiAqIEByZXR1cm5zIGEgYm9vbGVhbiByZXByZXNlbnRpbmcgaWYgdGhlIG5hbWVzcGFjZSBpcyB2YWxpZC5cbiAqL1xudmFyIGlzVmFsaWRCcmFpbnRyZWVOYW1lc3BhY2UgPSBmdW5jdGlvbiAoYnJhaW50cmVlU291cmNlKSB7XG4gIHZhciBfYSwgX2I7XG4gIGlmICh0eXBlb2YgKChfYSA9IGJyYWludHJlZVNvdXJjZSA9PT0gbnVsbCB8fCBicmFpbnRyZWVTb3VyY2UgPT09IHZvaWQgMCA/IHZvaWQgMCA6IGJyYWludHJlZVNvdXJjZS5jbGllbnQpID09PSBudWxsIHx8IF9hID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYS5jcmVhdGUpICE9PSBcImZ1bmN0aW9uXCIgJiYgdHlwZW9mICgoX2IgPSBicmFpbnRyZWVTb3VyY2UgPT09IG51bGwgfHwgYnJhaW50cmVlU291cmNlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBicmFpbnRyZWVTb3VyY2UucGF5cGFsQ2hlY2tvdXQpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jcmVhdGUpICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGUgYnJhaW50cmVlTmFtZXNwYWNlIHByb3BlcnR5IGlzIG5vdCBhIHZhbGlkIEJyYWludHJlZU5hbWVzcGFjZSB0eXBlLlwiKTtcbiAgfVxuICByZXR1cm4gdHJ1ZTtcbn07XG4vKipcbiAqIFVzZSBgYWN0aW9ucy5icmFpbnRyZWVgIHRvIHByb3ZpZGUgYW4gaW50ZXJmYWNlIGZvciB0aGUgcGF5cGFsQ2hlY2tvdXRJbnN0YW5jZVxuICogdGhyb3VnaCB0aGUgY3JlYXRlT3JkZXIsIGNyZWF0ZUJpbGxpbmdBZ3JlZW1lbnQgYW5kIG9uQXBwcm92ZSBjYWxsYmFja3NcbiAqXG4gKiBAcGFyYW0gYnJhaW50cmVlQnV0dG9uUHJvcHMgdGhlIGNvbXBvbmVudCBidXR0b24gb3B0aW9uc1xuICogQHJldHVybnMgYSBuZXcgY29weSBvZiB0aGUgY29tcG9uZW50IGJ1dHRvbiBvcHRpb25zIGNhc3RlZCBhcyB7QGxpbmsgUGF5UGFsQnV0dG9uc0NvbXBvbmVudFByb3BzfVxuICovXG52YXIgZGVjb3JhdGVBY3Rpb25zID0gZnVuY3Rpb24gKGJ1dHRvblByb3BzLCBwYXlQYWxDaGVja291dEluc3RhbmNlKSB7XG4gIHZhciBjcmVhdGVPcmRlclJlZiA9IGJ1dHRvblByb3BzLmNyZWF0ZU9yZGVyO1xuICB2YXIgY3JlYXRlQmlsbGluZ0FncmVlbWVudFJlZiA9IGJ1dHRvblByb3BzLmNyZWF0ZUJpbGxpbmdBZ3JlZW1lbnQ7XG4gIHZhciBvbkFwcHJvdmVSZWYgPSBidXR0b25Qcm9wcy5vbkFwcHJvdmU7XG4gIGlmICh0eXBlb2YgY3JlYXRlT3JkZXJSZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGJ1dHRvblByb3BzLmNyZWF0ZU9yZGVyID0gZnVuY3Rpb24gKGRhdGEsIGFjdGlvbnMpIHtcbiAgICAgIHJldHVybiBjcmVhdGVPcmRlclJlZihkYXRhLCBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgYWN0aW9ucyksIHtcbiAgICAgICAgYnJhaW50cmVlOiBwYXlQYWxDaGVja291dEluc3RhbmNlXG4gICAgICB9KSk7XG4gICAgfTtcbiAgfVxuICBpZiAodHlwZW9mIGNyZWF0ZUJpbGxpbmdBZ3JlZW1lbnRSZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGJ1dHRvblByb3BzLmNyZWF0ZUJpbGxpbmdBZ3JlZW1lbnQgPSBmdW5jdGlvbiAoZGF0YSwgYWN0aW9ucykge1xuICAgICAgcmV0dXJuIGNyZWF0ZUJpbGxpbmdBZ3JlZW1lbnRSZWYoZGF0YSwgX19hc3NpZ24oX19hc3NpZ24oe30sIGFjdGlvbnMpLCB7XG4gICAgICAgIGJyYWludHJlZTogcGF5UGFsQ2hlY2tvdXRJbnN0YW5jZVxuICAgICAgfSkpO1xuICAgIH07XG4gIH1cbiAgaWYgKHR5cGVvZiBvbkFwcHJvdmVSZWYgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGJ1dHRvblByb3BzLm9uQXBwcm92ZSA9IGZ1bmN0aW9uIChkYXRhLCBhY3Rpb25zKSB7XG4gICAgICByZXR1cm4gb25BcHByb3ZlUmVmKGRhdGEsIF9fYXNzaWduKF9fYXNzaWduKHt9LCBhY3Rpb25zKSwge1xuICAgICAgICBicmFpbnRyZWU6IHBheVBhbENoZWNrb3V0SW5zdGFuY2VcbiAgICAgIH0pKTtcbiAgICB9O1xuICB9XG4gIHJldHVybiBfX2Fzc2lnbih7fSwgYnV0dG9uUHJvcHMpO1xufTtcbi8qKlxuICogR2V0IHRoZSBCcmFpbnRyZWUgbmFtZXNwYWNlIGZyb20gdGhlIGNvbXBvbmVudCBwcm9wcy5cbiAqIElmIHRoZSBwcm9wIGBicmFpbnRyZWVOYW1lc3BhY2VgIGlzIHVuZGVmaW5lZCB3aWxsIHRyeSB0byBsb2FkIGl0IGZyb20gdGhlIENETi5cbiAqIFRoaXMgZnVuY3Rpb24gYWxsb3dzIHVzZXJzIHRvIHNldCB0aGUgYnJhaW50cmVlIG1hbnVhbGx5IG9uIHRoZSBgQnJhaW50cmVlUGF5UGFsQnV0dG9uc2AgY29tcG9uZW50LlxuICpcbiAqIFVzZSBjYXNlIGNhbiBiZSBmb3IgZXhhbXBsZSBsZWdhY3kgc2l0ZXMgdXNpbmcgQU1EL1VNRCBtb2R1bGVzLFxuICogdHJ5aW5nIHRvIGludGVncmF0ZSB0aGUgYEJyYWludHJlZVBheVBhbEJ1dHRvbnNgIGNvbXBvbmVudC5cbiAqIElmIHdlIGF0dGVtcHQgdG8gbG9hZCB0aGUgQnJhaW50cmVlIGZyb20gdGhlIENETiB3b24ndCBkZWZpbmUgdGhlIGJyYWludHJlZSBuYW1lc3BhY2UuXG4gKiBUaGlzIGhhcHBlbnMgYmVjYXVzZSB0aGUgYnJhaW50cmVlIHNjcmlwdCBpcyBhbiBVTUQgbW9kdWxlLlxuICogQWZ0ZXIgZGV0ZWN0aW5nIHRoZSBBTUQgb24gdGhlIGdsb2JhbCBzY29wZSB3aWxsIGNyZWF0ZSBhbiBhbm9ueW1vdXMgbW9kdWxlIHVzaW5nIGBkZWZpbmVgXG4gKiBhbmQgdGhlIGBCcmFpbnRyZWVQYXlQYWxCdXR0b25zYCB3b24ndCBiZSBhYmxlIHRvIGdldCBhY2Nlc3MgdG8gdGhlIGB3aW5kb3cuYnJhaW50cmVlYCBuYW1lc3BhY2VcbiAqIGZyb20gdGhlIGdsb2JhbCBjb250ZXh0LlxuICpcbiAqIEBwYXJhbSBicmFpbnRyZWVTb3VyY2UgdGhlIHNvdXJjZSB7QGxpbmsgQnJhaW50cmVlTmFtZXNwYWNlfVxuICogQHJldHVybnMgdGhlIHtAbGluayBCcmFpbnRyZWVOYW1lc3BhY2V9XG4gKi9cbnZhciBnZXRCcmFpbnRyZWVOYW1lc3BhY2UgPSBmdW5jdGlvbiAoYnJhaW50cmVlU291cmNlKSB7XG4gIGlmIChicmFpbnRyZWVTb3VyY2UgJiYgaXNWYWxpZEJyYWludHJlZU5hbWVzcGFjZShicmFpbnRyZWVTb3VyY2UpKSB7XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShicmFpbnRyZWVTb3VyY2UpO1xuICB9XG4gIHJldHVybiBQcm9taXNlLmFsbChbbG9hZEN1c3RvbVNjcmlwdCh7XG4gICAgdXJsOiBCUkFJTlRSRUVfU09VUkNFXG4gIH0pLCBsb2FkQ3VzdG9tU2NyaXB0KHtcbiAgICB1cmw6IEJSQUlOVFJFRV9QQVlQQUxfQ0hFQ0tPVVRfU09VUkNFXG4gIH0pXSkudGhlbihmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIGdldEJyYWludHJlZVdpbmRvd05hbWVzcGFjZSgpO1xuICB9KTtcbn07XG5cbi8qKlxuVGhpcyBgPEJyYWludHJlZVBheVBhbEJ1dHRvbnMgLz5gIGNvbXBvbmVudCByZW5kZXJzIHRoZSBbQnJhaW50cmVlIFBheVBhbCBCdXR0b25zXShodHRwczovL2RldmVsb3Blci5wYXlwYWwuY29tL2JyYWludHJlZS9kb2NzL2d1aWRlcy9wYXlwYWwvb3ZlcnZpZXcpIGZvciBCcmFpbnRyZWUgTWVyY2hhbnRzLlxuSXQgcmVsaWVzIG9uIHRoZSBgPFBheVBhbFNjcmlwdFByb3ZpZGVyIC8+YCBwYXJlbnQgY29tcG9uZW50IGZvciBtYW5hZ2luZyBzdGF0ZSByZWxhdGVkIHRvIGxvYWRpbmcgdGhlIEpTIFNESyBzY3JpcHQuXG5cbk5vdGU6IFlvdSBhcmUgYWJsZSB0byBtYWtlIHlvdXIgaW50ZWdyYXRpb24gdXNpbmcgdGhlIGNsaWVudCB0b2tlbiBvciB1c2luZyB0aGUgdG9rZW5pemF0aW9uIGtleS5cblxuLSBUbyB1c2UgdGhlIGNsaWVudCB0b2tlbiBpbnRlZ3JhdGlvbiBzZXQgdGhlIGtleSBgZGF0YUNsaWVudFRva2VuYCBpbiB0aGUgYFBheVBheVNjcmlwdFByb3ZpZGVyYCBjb21wb25lbnQncyBvcHRpb25zLlxuLSBUbyB1c2UgdGhlIHRva2VuaXphdGlvbiBrZXkgaW50ZWdyYXRpb24gc2V0IHRoZSBrZXkgYGRhdGFVc2VySWRUb2tlbmAgaW4gdGhlIGBQYXlQYXlTY3JpcHRQcm92aWRlcmAgY29tcG9uZW50J3Mgb3B0aW9ucy5cbiovXG52YXIgQnJhaW50cmVlUGF5UGFsQnV0dG9ucyA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgX2IgPSBfYS5jbGFzc05hbWUsXG4gICAgY2xhc3NOYW1lID0gX2IgPT09IHZvaWQgMCA/IFwiXCIgOiBfYixcbiAgICBfYyA9IF9hLmRpc2FibGVkLFxuICAgIGRpc2FibGVkID0gX2MgPT09IHZvaWQgMCA/IGZhbHNlIDogX2MsXG4gICAgY2hpbGRyZW4gPSBfYS5jaGlsZHJlbixcbiAgICBfZCA9IF9hLmZvcmNlUmVSZW5kZXIsXG4gICAgZm9yY2VSZVJlbmRlciA9IF9kID09PSB2b2lkIDAgPyBbXSA6IF9kLFxuICAgIGJyYWludHJlZU5hbWVzcGFjZSA9IF9hLmJyYWludHJlZU5hbWVzcGFjZSxcbiAgICBtZXJjaGFudEFjY291bnRJZCA9IF9hLm1lcmNoYW50QWNjb3VudElkLFxuICAgIGJ1dHRvblByb3BzID0gX19yZXN0JDEoX2EsIFtcImNsYXNzTmFtZVwiLCBcImRpc2FibGVkXCIsIFwiY2hpbGRyZW5cIiwgXCJmb3JjZVJlUmVuZGVyXCIsIFwiYnJhaW50cmVlTmFtZXNwYWNlXCIsIFwibWVyY2hhbnRBY2NvdW50SWRcIl0pO1xuICB2YXIgX2UgPSB1c2VTdGF0ZShudWxsKSxcbiAgICBzZXRFcnJvclN0YXRlID0gX2VbMV07XG4gIHZhciBfZiA9IHVzZVNjcmlwdFByb3ZpZGVyQ29udGV4dCgpLFxuICAgIHByb3ZpZGVyQ29udGV4dCA9IF9mWzBdLFxuICAgIGRpc3BhdGNoID0gX2ZbMV07XG4gIHVzZUVmZmVjdChmdW5jdGlvbiAoKSB7XG4gICAgZ2V0QnJhaW50cmVlTmFtZXNwYWNlKGJyYWludHJlZU5hbWVzcGFjZSkudGhlbihmdW5jdGlvbiAoYnJhaW50cmVlKSB7XG4gICAgICB2YXIgY2xpZW50VG9rZW5pemF0aW9uS2V5ID0gcHJvdmlkZXJDb250ZXh0Lm9wdGlvbnNbU0RLX1NFVFRJTkdTLkRBVEFfVVNFUl9JRF9UT0tFTl07XG4gICAgICB2YXIgY2xpZW50VG9rZW4gPSBwcm92aWRlckNvbnRleHQub3B0aW9uc1tTREtfU0VUVElOR1MuREFUQV9DTElFTlRfVE9LRU5dO1xuICAgICAgcmV0dXJuIGJyYWludHJlZS5jbGllbnQuY3JlYXRlKHtcbiAgICAgICAgYXV0aG9yaXphdGlvbjogY2xpZW50VG9rZW5pemF0aW9uS2V5IHx8IGNsaWVudFRva2VuXG4gICAgICB9KS50aGVuKGZ1bmN0aW9uIChjbGllbnRJbnN0YW5jZSkge1xuICAgICAgICB2YXIgbWVyY2hhbnRQcm9wID0gbWVyY2hhbnRBY2NvdW50SWQgPyB7XG4gICAgICAgICAgbWVyY2hhbnRBY2NvdW50SWQ6IG1lcmNoYW50QWNjb3VudElkXG4gICAgICAgIH0gOiB7fTtcbiAgICAgICAgcmV0dXJuIGJyYWludHJlZS5wYXlwYWxDaGVja291dC5jcmVhdGUoX19hc3NpZ24oX19hc3NpZ24oe30sIG1lcmNoYW50UHJvcCksIHtcbiAgICAgICAgICBjbGllbnQ6IGNsaWVudEluc3RhbmNlXG4gICAgICAgIH0pKTtcbiAgICAgIH0pLnRoZW4oZnVuY3Rpb24gKHBheXBhbENoZWNrb3V0SW5zdGFuY2UpIHtcbiAgICAgICAgZGlzcGF0Y2goe1xuICAgICAgICAgIHR5cGU6IERJU1BBVENIX0FDVElPTi5TRVRfQlJBSU5UUkVFX0lOU1RBTkNFLFxuICAgICAgICAgIHZhbHVlOiBwYXlwYWxDaGVja291dEluc3RhbmNlXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gICAgfSkuY2F0Y2goZnVuY3Rpb24gKGVycikge1xuICAgICAgc2V0RXJyb3JTdGF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIlwiLmNvbmNhdChMT0FEX1NDUklQVF9FUlJPUiwgXCIgXCIpLmNvbmNhdChlcnIpKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW3Byb3ZpZGVyQ29udGV4dC5vcHRpb25zXSk7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsLCBwcm92aWRlckNvbnRleHQuYnJhaW50cmVlUGF5UGFsQ2hlY2tvdXRJbnN0YW5jZSAmJiBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbEJ1dHRvbnMsIF9fYXNzaWduKHtcbiAgICBjbGFzc05hbWU6IGNsYXNzTmFtZSxcbiAgICBkaXNhYmxlZDogZGlzYWJsZWQsXG4gICAgZm9yY2VSZVJlbmRlcjogZm9yY2VSZVJlbmRlclxuICB9LCBkZWNvcmF0ZUFjdGlvbnMoYnV0dG9uUHJvcHMsIHByb3ZpZGVyQ29udGV4dC5icmFpbnRyZWVQYXlQYWxDaGVja291dEluc3RhbmNlKSksIGNoaWxkcmVuKSk7XG59O1xuXG4vKipcblRoZSBgPFBheVBhbE1hcmtzIC8+YCBjb21wb25lbnQgaXMgdXNlZCBmb3IgY29uZGl0aW9uYWxseSByZW5kZXJpbmcgZGlmZmVyZW50IHBheW1lbnQgb3B0aW9ucyB1c2luZyByYWRpbyBidXR0b25zLlxuVGhlIFtEaXNwbGF5IFBheVBhbCBCdXR0b25zIHdpdGggb3RoZXIgUGF5bWVudCBNZXRob2RzIGd1aWRlXShodHRwczovL2RldmVsb3Blci5wYXlwYWwuY29tL2RvY3MvYnVzaW5lc3MvY2hlY2tvdXQvYWRkLWNhcGFiaWxpdGllcy9idXllci1leHBlcmllbmNlLyNkaXNwbGF5LXBheXBhbC1idXR0b25zLXdpdGgtb3RoZXItcGF5bWVudC1tZXRob2RzKSBkZXNjcmliZXMgdGhpcyBzdHlsZSBvZiBpbnRlZ3JhdGlvbiBpbiBkZXRhaWwuXG5JdCByZWxpZXMgb24gdGhlIGA8UGF5UGFsU2NyaXB0UHJvdmlkZXIgLz5gIHBhcmVudCBjb21wb25lbnQgZm9yIG1hbmFnaW5nIHN0YXRlIHJlbGF0ZWQgdG8gbG9hZGluZyB0aGUgSlMgU0RLIHNjcmlwdC5cblxuVGhpcyBjb21wb25lbnQgY2FuIGFsc28gYmUgY29uZmlndXJlZCB0byB1c2UgYSBzaW5nbGUgZnVuZGluZyBzb3VyY2Ugc2ltaWxhciB0byB0aGUgW3N0YW5kYWxvbmUgYnV0dG9uc10oaHR0cHM6Ly9kZXZlbG9wZXIucGF5cGFsLmNvbS9kb2NzL2J1c2luZXNzL2NoZWNrb3V0L2NvbmZpZ3VyZS1wYXltZW50cy9zdGFuZGFsb25lLWJ1dHRvbnMvKSBhcHByb2FjaC5cbkEgYEZVTkRJTkdgIG9iamVjdCBpcyBleHBvcnRlZCBieSB0aGlzIGxpYnJhcnkgd2hpY2ggaGFzIGEga2V5IGZvciBldmVyeSBhdmFpbGFibGUgZnVuZGluZyBzb3VyY2Ugb3B0aW9uLlxuKi9cbnZhciBQYXlQYWxNYXJrcyA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgX2IgPSBfYS5jbGFzc05hbWUsXG4gICAgY2xhc3NOYW1lID0gX2IgPT09IHZvaWQgMCA/IFwiXCIgOiBfYixcbiAgICBjaGlsZHJlbiA9IF9hLmNoaWxkcmVuLFxuICAgIG1hcmtQcm9wcyA9IF9fcmVzdCQxKF9hLCBbXCJjbGFzc05hbWVcIiwgXCJjaGlsZHJlblwiXSk7XG4gIHZhciBfYyA9IHVzZVBheVBhbFNjcmlwdFJlZHVjZXIoKVswXSxcbiAgICBpc1Jlc29sdmVkID0gX2MuaXNSZXNvbHZlZCxcbiAgICBvcHRpb25zID0gX2Mub3B0aW9ucztcbiAgdmFyIG1hcmtDb250YWluZXJSZWYgPSB1c2VSZWYobnVsbCk7XG4gIHZhciBfZCA9IHVzZVN0YXRlKHRydWUpLFxuICAgIGlzRWxpZ2libGUgPSBfZFswXSxcbiAgICBzZXRJc0VsaWdpYmxlID0gX2RbMV07XG4gIHZhciBfZSA9IHVzZVN0YXRlKG51bGwpLFxuICAgIHNldEVycm9yU3RhdGUgPSBfZVsxXTtcbiAgLyoqXG4gICAqIFJlbmRlciBQYXlQYWwgTWFyayBpbnRvIHRoZSBET01cbiAgICovXG4gIHZhciByZW5kZXJQYXlQYWxNYXJrID0gZnVuY3Rpb24gKG1hcmspIHtcbiAgICB2YXIgY3VycmVudCA9IG1hcmtDb250YWluZXJSZWYuY3VycmVudDtcbiAgICAvLyBvbmx5IHJlbmRlciB0aGUgbWFyayB3aGVuIGVsaWdpYmxlXG4gICAgaWYgKCFjdXJyZW50IHx8ICFtYXJrLmlzRWxpZ2libGUoKSkge1xuICAgICAgcmV0dXJuIHNldElzRWxpZ2libGUoZmFsc2UpO1xuICAgIH1cbiAgICAvLyBSZW1vdmUgYW55IGNoaWxkcmVuIGJlZm9yZSByZW5kZXIgaXQgYWdhaW5cbiAgICBpZiAoY3VycmVudC5maXJzdENoaWxkKSB7XG4gICAgICBjdXJyZW50LnJlbW92ZUNoaWxkKGN1cnJlbnQuZmlyc3RDaGlsZCk7XG4gICAgfVxuICAgIG1hcmsucmVuZGVyKGN1cnJlbnQpLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIC8vIGNvbXBvbmVudCBmYWlsZWQgdG8gcmVuZGVyLCBwb3NzaWJseSBiZWNhdXNlIGl0IHdhcyBjbG9zZWQgb3IgZGVzdHJveWVkLlxuICAgICAgaWYgKGN1cnJlbnQgPT09IG51bGwgfHwgY3VycmVudC5jaGlsZHJlbi5sZW5ndGggPT09IDApIHtcbiAgICAgICAgLy8gcGF5cGFsIG1hcmtzIGNvbnRhaW5lciBpcyBubyBsb25nZXIgaW4gdGhlIERPTSwgd2UgY2FuIHNhZmVseSBpZ25vcmUgdGhlIGVycm9yXG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIC8vIHBheXBhbCBtYXJrcyBjb250YWluZXIgaXMgc3RpbGwgaW4gdGhlIERPTVxuICAgICAgc2V0RXJyb3JTdGF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byByZW5kZXIgPFBheVBhbE1hcmtzIC8+IGNvbXBvbmVudC4gXCIuY29uY2F0KGVycikpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH07XG4gIHVzZUVmZmVjdChmdW5jdGlvbiAoKSB7XG4gICAgLy8gdmVyaWZ5IHRoZSBzZGsgc2NyaXB0IGhhcyBzdWNjZXNzZnVsbHkgbG9hZGVkXG4gICAgaWYgKGlzUmVzb2x2ZWQgPT09IGZhbHNlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciBwYXlwYWxXaW5kb3dOYW1lc3BhY2UgPSBnZXRQYXlQYWxXaW5kb3dOYW1lc3BhY2UkMShnZXRPd25Qcm9wZXJ0eSQxKG9wdGlvbnMsIFwiZGF0YU5hbWVzcGFjZVwiKSk7XG4gICAgLy8gdmVyaWZ5IGRlcGVuZGVuY3kgb24gd2luZG93IG9iamVjdFxuICAgIGlmIChwYXlwYWxXaW5kb3dOYW1lc3BhY2UgPT09IHVuZGVmaW5lZCB8fCBwYXlwYWxXaW5kb3dOYW1lc3BhY2UuTWFya3MgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHNldEVycm9yU3RhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZ2VuZXJhdGVFcnJvck1lc3NhZ2Uoe1xuICAgICAgICAgIHJlYWN0Q29tcG9uZW50TmFtZTogUGF5UGFsTWFya3MuZGlzcGxheU5hbWUsXG4gICAgICAgICAgc2RrQ29tcG9uZW50S2V5OiBcIm1hcmtzXCIsXG4gICAgICAgICAgc2RrUmVxdWVzdGVkQ29tcG9uZW50czogb3B0aW9ucy5jb21wb25lbnRzLFxuICAgICAgICAgIHNka0RhdGFOYW1lc3BhY2U6IGdldE93blByb3BlcnR5JDEob3B0aW9ucywgXCJkYXRhTmFtZXNwYWNlXCIpXG4gICAgICAgIH0pKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZW5kZXJQYXlQYWxNYXJrKHBheXBhbFdpbmRvd05hbWVzcGFjZS5NYXJrcyhfX2Fzc2lnbih7fSwgbWFya1Byb3BzKSkpO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgW2lzUmVzb2x2ZWQsIG1hcmtQcm9wcy5mdW5kaW5nU291cmNlXSk7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFJlYWN0LkZyYWdtZW50LCBudWxsLCBpc0VsaWdpYmxlID8gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgcmVmOiBtYXJrQ29udGFpbmVyUmVmLFxuICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lXG4gIH0pIDogY2hpbGRyZW4pO1xufTtcblBheVBhbE1hcmtzLmRpc3BsYXlOYW1lID0gXCJQYXlQYWxNYXJrc1wiO1xuXG4vKipcblRoaXMgYDxQYXlQYWxNZXNzYWdlcyAvPmAgbWVzc2FnZXMgY29tcG9uZW50IHJlbmRlcnMgYSBjcmVkaXQgbWVzc2FnaW5nIG9uIHVwc3RyZWFtIG1lcmNoYW50IHNpdGVzLlxuSXQgcmVsaWVzIG9uIHRoZSBgPFBheVBhbFNjcmlwdFByb3ZpZGVyIC8+YCBwYXJlbnQgY29tcG9uZW50IGZvciBtYW5hZ2luZyBzdGF0ZSByZWxhdGVkIHRvIGxvYWRpbmcgdGhlIEpTIFNESyBzY3JpcHQuXG4qL1xudmFyIFBheVBhbE1lc3NhZ2VzID0gZnVuY3Rpb24gKF9hKSB7XG4gIHZhciBfYiA9IF9hLmNsYXNzTmFtZSxcbiAgICBjbGFzc05hbWUgPSBfYiA9PT0gdm9pZCAwID8gXCJcIiA6IF9iLFxuICAgIF9jID0gX2EuZm9yY2VSZVJlbmRlcixcbiAgICBmb3JjZVJlUmVuZGVyID0gX2MgPT09IHZvaWQgMCA/IFtdIDogX2MsXG4gICAgbWVzc2FnZVByb3BzID0gX19yZXN0JDEoX2EsIFtcImNsYXNzTmFtZVwiLCBcImZvcmNlUmVSZW5kZXJcIl0pO1xuICB2YXIgX2QgPSB1c2VQYXlQYWxTY3JpcHRSZWR1Y2VyKClbMF0sXG4gICAgaXNSZXNvbHZlZCA9IF9kLmlzUmVzb2x2ZWQsXG4gICAgb3B0aW9ucyA9IF9kLm9wdGlvbnM7XG4gIHZhciBtZXNzYWdlc0NvbnRhaW5lclJlZiA9IHVzZVJlZihudWxsKTtcbiAgdmFyIG1lc3NhZ2VzID0gdXNlUmVmKG51bGwpO1xuICB2YXIgX2UgPSB1c2VTdGF0ZShudWxsKSxcbiAgICBzZXRFcnJvclN0YXRlID0gX2VbMV07XG4gIHVzZUVmZmVjdChmdW5jdGlvbiAoKSB7XG4gICAgLy8gdmVyaWZ5IHRoZSBzZGsgc2NyaXB0IGhhcyBzdWNjZXNzZnVsbHkgbG9hZGVkXG4gICAgaWYgKGlzUmVzb2x2ZWQgPT09IGZhbHNlKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHZhciBwYXlwYWxXaW5kb3dOYW1lc3BhY2UgPSBnZXRQYXlQYWxXaW5kb3dOYW1lc3BhY2UkMShnZXRPd25Qcm9wZXJ0eSQxKG9wdGlvbnMsIFwiZGF0YU5hbWVzcGFjZVwiKSk7XG4gICAgLy8gdmVyaWZ5IGRlcGVuZGVuY3kgb24gd2luZG93IG9iamVjdFxuICAgIGlmIChwYXlwYWxXaW5kb3dOYW1lc3BhY2UgPT09IHVuZGVmaW5lZCB8fCBwYXlwYWxXaW5kb3dOYW1lc3BhY2UuTWVzc2FnZXMgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHNldEVycm9yU3RhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZ2VuZXJhdGVFcnJvck1lc3NhZ2Uoe1xuICAgICAgICAgIHJlYWN0Q29tcG9uZW50TmFtZTogUGF5UGFsTWVzc2FnZXMuZGlzcGxheU5hbWUsXG4gICAgICAgICAgc2RrQ29tcG9uZW50S2V5OiBcIm1lc3NhZ2VzXCIsXG4gICAgICAgICAgc2RrUmVxdWVzdGVkQ29tcG9uZW50czogb3B0aW9ucy5jb21wb25lbnRzLFxuICAgICAgICAgIHNka0RhdGFOYW1lc3BhY2U6IGdldE93blByb3BlcnR5JDEob3B0aW9ucywgXCJkYXRhTmFtZXNwYWNlXCIpXG4gICAgICAgIH0pKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBtZXNzYWdlcy5jdXJyZW50ID0gcGF5cGFsV2luZG93TmFtZXNwYWNlLk1lc3NhZ2VzKF9fYXNzaWduKHt9LCBtZXNzYWdlUHJvcHMpKTtcbiAgICBtZXNzYWdlcy5jdXJyZW50LnJlbmRlcihtZXNzYWdlc0NvbnRhaW5lclJlZi5jdXJyZW50KS5jYXRjaChmdW5jdGlvbiAoZXJyKSB7XG4gICAgICAvLyBjb21wb25lbnQgZmFpbGVkIHRvIHJlbmRlciwgcG9zc2libHkgYmVjYXVzZSBpdCB3YXMgY2xvc2VkIG9yIGRlc3Ryb3llZC5cbiAgICAgIGlmIChtZXNzYWdlc0NvbnRhaW5lclJlZi5jdXJyZW50ID09PSBudWxsIHx8IG1lc3NhZ2VzQ29udGFpbmVyUmVmLmN1cnJlbnQuY2hpbGRyZW4ubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIC8vIHBheXBhbCBtZXNzYWdlcyBjb250YWluZXIgaXMgbm8gbG9uZ2VyIGluIHRoZSBET00sIHdlIGNhbiBzYWZlbHkgaWdub3JlIHRoZSBlcnJvclxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICAvLyBwYXlwYWwgbWVzc2FnZXMgY29udGFpbmVyIGlzIHN0aWxsIGluIHRoZSBET01cbiAgICAgIHNldEVycm9yU3RhdGUoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gcmVuZGVyIDxQYXlQYWxNZXNzYWdlcyAvPiBjb21wb25lbnQuIFwiLmNvbmNhdChlcnIpKTtcbiAgICAgIH0pO1xuICAgIH0pO1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgfSwgX19zcHJlYWRBcnJheShbaXNSZXNvbHZlZF0sIGZvcmNlUmVSZW5kZXIsIHRydWUpKTtcbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIHJlZjogbWVzc2FnZXNDb250YWluZXJSZWYsXG4gICAgY2xhc3NOYW1lOiBjbGFzc05hbWVcbiAgfSk7XG59O1xuUGF5UGFsTWVzc2FnZXMuZGlzcGxheU5hbWUgPSBcIlBheVBhbE1lc3NhZ2VzXCI7XG5cbi8qKlxuVGhpcyBgPFBheVBhbFNjcmlwdFByb3ZpZGVyIC8+YCBjb21wb25lbnQgdGFrZXMgY2FyZSBvZiBsb2FkaW5nIHRoZSBKUyBTREsgYDxzY3JpcHQ+YC5cbkl0IG1hbmFnZXMgc3RhdGUgZm9yIHNjcmlwdCBsb2FkaW5nIHNvIGNoaWxkcmVuIGNvbXBvbmVudHMgbGlrZSBgPFBheVBhbEJ1dHRvbnMgLz5gIGtub3cgd2hlbiBpdCdzIHNhZmUgdG8gdXNlIHRoZSBgd2luZG93LnBheXBhbGAgZ2xvYmFsIG5hbWVzcGFjZS5cblxuTm90ZTogWW91IGFsd2F5cyBzaG91bGQgdXNlIHRoaXMgY29tcG9uZW50IGFzIGEgd3JhcHBlciBmb3IgIGBQYXlQYWxCdXR0b25zYCwgYFBheVBhbE1hcmtzYCwgYFBheVBhbE1lc3NhZ2VzYCBhbmQgYEJyYWludHJlZVBheVBhbEJ1dHRvbnNgIGNvbXBvbmVudHMuXG4gKi9cbnZhciBQYXlQYWxTY3JpcHRQcm92aWRlciA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgX2I7XG4gIHZhciBfYyA9IF9hLm9wdGlvbnMsXG4gICAgb3B0aW9ucyA9IF9jID09PSB2b2lkIDAgPyB7XG4gICAgICBjbGllbnRJZDogXCJ0ZXN0XCJcbiAgICB9IDogX2MsXG4gICAgY2hpbGRyZW4gPSBfYS5jaGlsZHJlbixcbiAgICBfZCA9IF9hLmRlZmVyTG9hZGluZyxcbiAgICBkZWZlckxvYWRpbmcgPSBfZCA9PT0gdm9pZCAwID8gZmFsc2UgOiBfZDtcbiAgdmFyIF9lID0gdXNlUmVkdWNlcihzY3JpcHRSZWR1Y2VyLCB7XG4gICAgICBvcHRpb25zOiBfX2Fzc2lnbihfX2Fzc2lnbih7fSwgb3B0aW9ucyksIChfYiA9IHt9LCBfYltTREtfU0VUVElOR1MuREFUQV9KU19TREtfTElCUkFSWV0gPSBTREtfU0VUVElOR1MuREFUQV9MSUJSQVJZX1ZBTFVFLCBfYltTREtfU0VUVElOR1MuREFUQV9TREtfSU5URUdSQVRJT05fU09VUkNFXSA9IFNES19TRVRUSU5HUy5EQVRBX0xJQlJBUllfVkFMVUUsIF9iW1NDUklQVF9JRF0gPSBcIlwiLmNvbmNhdChnZXRTY3JpcHRJRChvcHRpb25zKSksIF9iKSksXG4gICAgICBsb2FkaW5nU3RhdHVzOiBkZWZlckxvYWRpbmcgPyBTQ1JJUFRfTE9BRElOR19TVEFURS5JTklUSUFMIDogU0NSSVBUX0xPQURJTkdfU1RBVEUuUEVORElOR1xuICAgIH0pLFxuICAgIHN0YXRlID0gX2VbMF0sXG4gICAgZGlzcGF0Y2ggPSBfZVsxXTtcbiAgdXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoZGVmZXJMb2FkaW5nID09PSBmYWxzZSAmJiBzdGF0ZS5sb2FkaW5nU3RhdHVzID09PSBTQ1JJUFRfTE9BRElOR19TVEFURS5JTklUSUFMKSB7XG4gICAgICByZXR1cm4gZGlzcGF0Y2goe1xuICAgICAgICB0eXBlOiBESVNQQVRDSF9BQ1RJT04uTE9BRElOR19TVEFUVVMsXG4gICAgICAgIHZhbHVlOiBTQ1JJUFRfTE9BRElOR19TVEFURS5QRU5ESU5HXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKHN0YXRlLmxvYWRpbmdTdGF0dXMgIT09IFNDUklQVF9MT0FESU5HX1NUQVRFLlBFTkRJTkcpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIGlzU3Vic2NyaWJlZCA9IHRydWU7XG4gICAgbG9hZFNjcmlwdChzdGF0ZS5vcHRpb25zKS50aGVuKGZ1bmN0aW9uICgpIHtcbiAgICAgIGlmIChpc1N1YnNjcmliZWQpIHtcbiAgICAgICAgZGlzcGF0Y2goe1xuICAgICAgICAgIHR5cGU6IERJU1BBVENIX0FDVElPTi5MT0FESU5HX1NUQVRVUyxcbiAgICAgICAgICB2YWx1ZTogU0NSSVBUX0xPQURJTkdfU1RBVEUuUkVTT0xWRURcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfSkuY2F0Y2goZnVuY3Rpb24gKGVycikge1xuICAgICAgY29uc29sZS5lcnJvcihcIlwiLmNvbmNhdChMT0FEX1NDUklQVF9FUlJPUiwgXCIgXCIpLmNvbmNhdChlcnIpKTtcbiAgICAgIGlmIChpc1N1YnNjcmliZWQpIHtcbiAgICAgICAgZGlzcGF0Y2goe1xuICAgICAgICAgIHR5cGU6IERJU1BBVENIX0FDVElPTi5MT0FESU5HX1NUQVRVUyxcbiAgICAgICAgICB2YWx1ZToge1xuICAgICAgICAgICAgc3RhdGU6IFNDUklQVF9MT0FESU5HX1NUQVRFLlJFSkVDVEVELFxuICAgICAgICAgICAgbWVzc2FnZTogU3RyaW5nKGVycilcbiAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICBpc1N1YnNjcmliZWQgPSBmYWxzZTtcbiAgICB9O1xuICB9LCBbc3RhdGUub3B0aW9ucywgZGVmZXJMb2FkaW5nLCBzdGF0ZS5sb2FkaW5nU3RhdHVzXSk7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFNjcmlwdENvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZTogX19hc3NpZ24oX19hc3NpZ24oe30sIHN0YXRlKSwge1xuICAgICAgZGlzcGF0Y2g6IGRpc3BhdGNoXG4gICAgfSlcbiAgfSwgY2hpbGRyZW4pO1xufTtcblxuLyoqXG4gKiBDdXN0b20gaG9vayB0byBzdG9yZSByZWdpc3RlcmVkIGhvc3RlZCBmaWVsZHMgY2hpbGRyZW5cbiAqIEVhY2ggYFBheVBhbEhvc3RlZEZpZWxkYCBjb21wb25lbnQgc2hvdWxkIGJlIHJlZ2lzdGVyZWQgb24gdGhlIHBhcmVudCBwcm92aWRlclxuICpcbiAqIEBwYXJhbSBpbml0aWFsVmFsdWUgdGhlIGluaXRpYWxseSByZWdpc3RlcmVkIGNvbXBvbmVudHNcbiAqIEByZXR1cm5zIGF0IGZpcnN0LCBhbiB7QGxpbmsgT2JqZWN0fSBjb250YWluaW5nIHRoZSByZWdpc3RlcmVkIGhvc3RlZCBmaWVsZHMsXG4gKiBhbmQgYXQgdGhlIHNlY29uZCBhIGZ1bmN0aW9uIGhhbmRsZXIgdG8gcmVnaXN0ZXIgdGhlIGhvc3RlZCBmaWVsZHMgY29tcG9uZW50c1xuICovXG52YXIgdXNlSG9zdGVkRmllbGRzUmVnaXN0ZXIgPSBmdW5jdGlvbiAoaW5pdGlhbFZhbHVlKSB7XG4gIGlmIChpbml0aWFsVmFsdWUgPT09IHZvaWQgMCkge1xuICAgIGluaXRpYWxWYWx1ZSA9IHt9O1xuICB9XG4gIHZhciByZWdpc3RlcmVkRmllbGRzID0gdXNlUmVmKGluaXRpYWxWYWx1ZSk7XG4gIHZhciByZWdpc3Rlckhvc3RlZEZpZWxkID0gZnVuY3Rpb24gKGNvbXBvbmVudCkge1xuICAgIHJlZ2lzdGVyZWRGaWVsZHMuY3VycmVudCA9IF9fYXNzaWduKF9fYXNzaWduKHt9LCByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnQpLCBjb21wb25lbnQpO1xuICB9O1xuICByZXR1cm4gW3JlZ2lzdGVyZWRGaWVsZHMsIHJlZ2lzdGVySG9zdGVkRmllbGRdO1xufTtcblxuLyoqXG4gKiBUaHJvdyBhbiBleGNlcHRpb24gaWYgdGhlIEhvc3RlZEZpZWxkcyBpcyBub3QgZm91bmQgaW4gdGhlIHBheXBhbCBuYW1lc3BhY2VcbiAqIFByb2JhYmx5IGNhdXNlIGZvciB0aGlzIHByb2JsZW0gaXMgbm90IHNlbmRpbmcgdGhlIGhvc3RlZC1maWVsZHMgc3RyaW5nXG4gKiBhcyBwYXJ0IG9mIHRoZSBjb21wb25lbnRzIHByb3BzIGluIG9wdGlvbnNcbiAqIHtAY29kZSA8UGF5UGFsU2NyaXB0UHJvdmlkZXIgb3B0aW9ucz17eyBjb21wb25lbnRzOiAnaG9zdGVkLWZpZWxkcyd9fT59XG4gKlxuICogQHBhcmFtIHBhcmFtMCBhbmQgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGNvbXBvbmVudHMgYW5kIG5hbWVzcGFjZSBkZWZpbmVkIGluIG9wdGlvbnNcbiAqIEB0aHJvd3Mge0Bjb2RlIEVycm9yfVxuICpcbiAqL1xudmFyIGdlbmVyYXRlTWlzc2luZ0hvc3RlZEZpZWxkc0Vycm9yID0gZnVuY3Rpb24gKF9hKSB7XG4gIHZhciBfYiA9IF9hLmNvbXBvbmVudHMsXG4gICAgY29tcG9uZW50cyA9IF9iID09PSB2b2lkIDAgPyBcIlwiIDogX2IsXG4gICAgX2MgPSBTREtfU0VUVElOR1MuREFUQV9OQU1FU1BBQ0UsXG4gICAgX2QgPSBfYVtfY10sXG4gICAgZGF0YU5hbWVzcGFjZSA9IF9kID09PSB2b2lkIDAgPyBERUZBVUxUX1BBWVBBTF9OQU1FU1BBQ0UgOiBfZDtcbiAgdmFyIGV4cGVjdGVkQ29tcG9uZW50cyA9IGNvbXBvbmVudHMgPyBcIlwiLmNvbmNhdChjb21wb25lbnRzLCBcIixob3N0ZWQtZmllbGRzXCIpIDogXCJob3N0ZWQtZmllbGRzXCI7XG4gIHZhciBlcnJvck1lc3NhZ2UgPSBcIlVuYWJsZSB0byByZW5kZXIgPFBheVBhbEhvc3RlZEZpZWxkc1Byb3ZpZGVyIC8+IGJlY2F1c2Ugd2luZG93LlwiLmNvbmNhdChkYXRhTmFtZXNwYWNlLCBcIi5Ib3N0ZWRGaWVsZHMgaXMgdW5kZWZpbmVkLlwiKTtcbiAgaWYgKCFjb21wb25lbnRzLmluY2x1ZGVzKFwiaG9zdGVkLWZpZWxkc1wiKSkge1xuICAgIGVycm9yTWVzc2FnZSArPSBcIlxcblRvIGZpeCB0aGUgaXNzdWUsIGFkZCAnaG9zdGVkLWZpZWxkcycgdG8gdGhlIGxpc3Qgb2YgY29tcG9uZW50cyBwYXNzZWQgdG8gdGhlIHBhcmVudCBQYXlQYWxTY3JpcHRQcm92aWRlcjogPFBheVBhbFNjcmlwdFByb3ZpZGVyIG9wdGlvbnM9e3sgY29tcG9uZW50czogJ1wiLmNvbmNhdChleHBlY3RlZENvbXBvbmVudHMsIFwiJ319PlwiKTtcbiAgfVxuICByZXR1cm4gZXJyb3JNZXNzYWdlO1xufTtcbi8qKlxuICogVmFsaWRhdGUgdGhlIGV4cGlyYXRpb24gZGF0ZSBjb21wb25lbnQuIFZhbGlkIGNvbWJpbmF0aW9ucyBhcmU6XG4gKiAxLSBPbmx5IHRoZSBgZXhwaXJhdGlvbkRhdGVgIGZpZWxkIGV4aXN0cy5cbiAqIDItIE9ubHkgdGhlIGBleHBpcmF0aW9uTW9udGhgIGFuZCBgZXhwaXJhdGlvblllYXJgIGZpZWxkcyBleGlzdC4gQ2Fubm90IGJlIHVzZWQgd2l0aCB0aGUgYGV4cGlyYXRpb25EYXRlYCBmaWVsZC5cbiAqXG4gKiBAcGFyYW0gcmVnaXN0ZXJUeXBlc1xuICogQHJldHVybnMgQHR5cGUge3RydWV9IHdoZW4gdGhlIGNoaWxkcmVuIGFyZSB2YWxpZFxuICovXG52YXIgdmFsaWRhdGVFeHBpcmF0aW9uRGF0ZSA9IGZ1bmN0aW9uIChyZWdpc3RlclR5cGVzKSB7XG4gIHJldHVybiAhcmVnaXN0ZXJUeXBlcy5pbmNsdWRlcyhQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFUy5FWFBJUkFUSU9OX0RBVEUpICYmICFyZWdpc3RlclR5cGVzLmluY2x1ZGVzKFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTLkVYUElSQVRJT05fTU9OVEgpICYmICFyZWdpc3RlclR5cGVzLmluY2x1ZGVzKFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTLkVYUElSQVRJT05fWUVBUik7XG59O1xuLyoqXG4gKiBDaGVjayBpZiB3ZSBmaW5kIHRoZSBbbnVtYmVyLCBleHBpcmF0aW9uLCBjdnZdIGluIGNoaWxkcmVuXG4gKlxuICogQHBhcmFtIHJlcXVpcmVkQ2hpbGRyZW4gdGhlIGxpc3Qgd2l0aCByZXF1aXJlZCBjaGlsZHJlbiBbbnVtYmVyLCBleHBpcmF0aW9uLCBjdnZdXG4gKiBAcGFyYW0gcmVnaXN0ZXJUeXBlcyAgICB0aGUgbGlzdCBvZiBhbGwgdGhlIGNoaWxkcmVuIHR5cGVzIHBhc3MgdG8gdGhlIHBhcmVudFxuICogQHRocm93IGFuIEB0eXBlIHtFcnJvcn0gd2hlbiBub3QgZmluZCB0aGUgZGVmYXVsdCBjaGlsZHJlblxuICovXG52YXIgaGFzRGVmYXVsdENoaWxkcmVuID0gZnVuY3Rpb24gKHJlZ2lzdGVyVHlwZXMpIHtcbiAgaWYgKCFyZWdpc3RlclR5cGVzLmluY2x1ZGVzKFBBWVBBTF9IT1NURURfRklFTERTX1RZUEVTLk5VTUJFUikgfHwgIXJlZ2lzdGVyVHlwZXMuaW5jbHVkZXMoUEFZUEFMX0hPU1RFRF9GSUVMRFNfVFlQRVMuQ1ZWKSB8fCB2YWxpZGF0ZUV4cGlyYXRpb25EYXRlKHJlZ2lzdGVyVHlwZXMpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKEhPU1RFRF9GSUVMRFNfQ0hJTERSRU5fRVJST1IpO1xuICB9XG59O1xuLyoqXG4gKiBDaGVjayBpZiB3ZSBkb24ndCBoYXZlIGR1cGxpY2F0ZSBjaGlsZHJlbiB0eXBlc1xuICpcbiAqIEBwYXJhbSByZWdpc3RlclR5cGVzIHRoZSBsaXN0IG9mIGFsbCB0aGUgY2hpbGRyZW4gdHlwZXMgcGFzcyB0byB0aGUgcGFyZW50XG4gKiBAdGhyb3cgYW4gQHR5cGUge0Vycm9yfSB3aGVuIGR1cGxpY2F0ZSB0eXBlcyB3YXMgZm91bmRcbiAqL1xudmFyIG5vRHVwbGljYXRlQ2hpbGRyZW4gPSBmdW5jdGlvbiAocmVnaXN0ZXJUeXBlcykge1xuICBpZiAocmVnaXN0ZXJUeXBlcy5sZW5ndGggIT09IG5ldyBTZXQocmVnaXN0ZXJUeXBlcykuc2l6ZSkge1xuICAgIHRocm93IG5ldyBFcnJvcihIT1NURURfRklFTERTX0RVUExJQ0FURV9DSElMRFJFTl9FUlJPUik7XG4gIH1cbn07XG4vKipcbiAqIFZhbGlkYXRlIHRoZSBob3N0ZWQgZmllbGQgY2hpbGRyZW4gaW4gdGhlIFBheVBhbEhvc3RlZEZpZWxkc1Byb3ZpZGVyIGNvbXBvbmVudC5cbiAqIFRoZXNlIGFyZSB0aGUgcnVsZXM6XG4gKiAxLSBXZSBuZWVkIHRvIGZpbmQgMyBkZWZhdWx0IGNoaWxkcmVuIGZvciBudW1iZXIsIGV4cGlyYXRpb24sIGN2dlxuICogMi0gTm8gZHVwbGljYXRlIGNoaWxkcmVuIGFyZSBhbGxvd2VkXG4gKiAzLSBObyBpbnZhbGlkIGNvbWJpbmF0aW9ucyBvZiBgZXhwaXJhdGlvbkRhdGVgLCBgZXhwaXJhdGlvbk1vbnRoYCwgYW5kIGBleHBpcmF0aW9uWWVhcmBcbiAqXG4gKiBAcGFyYW0gY2hpbGRyZW5MaXN0ICAgICB0aGUgbGlzdCBvZiBjaGlsZHJlblxuICogQHBhcmFtIHJlcXVpcmVkQ2hpbGRyZW4gdGhlIGxpc3Qgd2l0aCByZXF1aXJlZCBjaGlsZHJlbiBbbnVtYmVyLCBleHBpcmF0aW9uLCBjdnZdXG4gKi9cbnZhciB2YWxpZGF0ZUhvc3RlZEZpZWxkQ2hpbGRyZW4gPSBmdW5jdGlvbiAocmVnaXN0ZXJlZEZpZWxkcykge1xuICBoYXNEZWZhdWx0Q2hpbGRyZW4ocmVnaXN0ZXJlZEZpZWxkcyk7XG4gIG5vRHVwbGljYXRlQ2hpbGRyZW4ocmVnaXN0ZXJlZEZpZWxkcyk7XG59O1xuXG4vKipcblRoaXMgYDxQYXlQYWxIb3N0ZWRGaWVsZHNQcm92aWRlciAvPmAgcHJvdmlkZXIgY29tcG9uZW50IHdyYXBzIHRoZSBmb3JtIGZpZWxkIGVsZW1lbnRzIGFuZCBhY2NlcHRzIHByb3BzIGxpa2UgYGNyZWF0ZU9yZGVyKClgLlxuXG5UaGlzIHByb3ZpZGVyIGNvbXBvbmVudCBpcyBkZXNpZ25lZCB0byBiZSB1c2VkIHdpdGggdGhlIGA8UGF5UGFsSG9zdGVkRmllbGQgLz5gIGNvbXBvbmVudC5cblxuV2FybmluZzogSWYgeW91IGRvbid0IHNlZSBhbnl0aGluZyBpbiB0aGUgc2NyZWVuIHByb2JhYmx5IHlvdXIgY2xpZW50IGlzIGluZWxpZ2libGUuXG5UbyBoYW5kbGUgdGhpcyBwcm9ibGVtIG1ha2Ugc3VyZSB0byB1c2UgdGhlIHByb3AgYG5vdEVsaWdpYmxlRXJyb3JgIGFuZCBwYXNzIGEgY29tcG9uZW50IHdpdGggYSBjdXN0b20gbWVzc2FnZS5cblRha2UgYSBsb29rIHRvIHRoaXMgbGluayBpZiB0aGF0IGlzIHRoZSBjYXNlOiBodHRwczovL2RldmVsb3Blci5wYXlwYWwuY29tL2RvY3MvY2hlY2tvdXQvYWR2YW5jZWQvaW50ZWdyYXRlL1xuKi9cbnZhciBQYXlQYWxIb3N0ZWRGaWVsZHNQcm92aWRlciA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgc3R5bGVzID0gX2Euc3R5bGVzLFxuICAgIGNyZWF0ZU9yZGVyID0gX2EuY3JlYXRlT3JkZXIsXG4gICAgbm90RWxpZ2libGVFcnJvciA9IF9hLm5vdEVsaWdpYmxlRXJyb3IsXG4gICAgY2hpbGRyZW4gPSBfYS5jaGlsZHJlbixcbiAgICBpbnN0YWxsbWVudHMgPSBfYS5pbnN0YWxsbWVudHM7XG4gIHZhciBfYiA9IHVzZVNjcmlwdFByb3ZpZGVyQ29udGV4dCgpWzBdLFxuICAgIG9wdGlvbnMgPSBfYi5vcHRpb25zLFxuICAgIGxvYWRpbmdTdGF0dXMgPSBfYi5sb2FkaW5nU3RhdHVzO1xuICB2YXIgX2MgPSB1c2VTdGF0ZSh0cnVlKSxcbiAgICBpc0VsaWdpYmxlID0gX2NbMF0sXG4gICAgc2V0SXNFbGlnaWJsZSA9IF9jWzFdO1xuICB2YXIgX2QgPSB1c2VTdGF0ZSgpLFxuICAgIGNhcmRGaWVsZHMgPSBfZFswXSxcbiAgICBzZXRDYXJkRmllbGRzID0gX2RbMV07XG4gIHZhciBfZSA9IHVzZVN0YXRlKG51bGwpLFxuICAgIHNldEVycm9yU3RhdGUgPSBfZVsxXTtcbiAgdmFyIGhvc3RlZEZpZWxkc0NvbnRhaW5lclJlZiA9IHVzZVJlZihudWxsKTtcbiAgdmFyIGhvc3RlZEZpZWxkcyA9IHVzZVJlZigpO1xuICB2YXIgX2YgPSB1c2VIb3N0ZWRGaWVsZHNSZWdpc3RlcigpLFxuICAgIHJlZ2lzdGVyZWRGaWVsZHMgPSBfZlswXSxcbiAgICByZWdpc3Rlckhvc3RlZEZpZWxkID0gX2ZbMV07XG4gIHVzZUVmZmVjdChmdW5jdGlvbiAoKSB7XG4gICAgdmFsaWRhdGVIb3N0ZWRGaWVsZENoaWxkcmVuKE9iamVjdC5rZXlzKHJlZ2lzdGVyZWRGaWVsZHMuY3VycmVudCkpO1xuICAgIC8vIE9ubHkgcmVuZGVyIHRoZSBob3N0ZWQgZmllbGRzIHdoZW4gc2NyaXB0IGlzIGxvYWRlZCBhbmQgaG9zdGVkRmllbGRzIGlzIGVsaWdpYmxlXG4gICAgaWYgKCEobG9hZGluZ1N0YXR1cyA9PT0gU0NSSVBUX0xPQURJTkdfU1RBVEUuUkVTT0xWRUQpKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIC8vIEdldCB0aGUgaG9zdGVkIGZpZWxkcyBmcm9tIHRoZSBbd2luZG93LnBheXBhbC5Ib3N0ZWRGaWVsZHNdIFNES1xuICAgIGhvc3RlZEZpZWxkcy5jdXJyZW50ID0gZ2V0UGF5UGFsV2luZG93TmFtZXNwYWNlJDEoZ2V0T3duUHJvcGVydHkkMShvcHRpb25zLCBcImRhdGFOYW1lc3BhY2VcIikpLkhvc3RlZEZpZWxkcztcbiAgICBpZiAoIWhvc3RlZEZpZWxkcy5jdXJyZW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoZ2VuZXJhdGVNaXNzaW5nSG9zdGVkRmllbGRzRXJyb3Ioe1xuICAgICAgICBjb21wb25lbnRzOiBvcHRpb25zLmNvbXBvbmVudHMsXG4gICAgICAgIGRhdGFOYW1lc3BhY2U6IGdldE93blByb3BlcnR5JDEob3B0aW9ucywgXCJkYXRhTmFtZXNwYWNlXCIpXG4gICAgICB9KSk7XG4gICAgfVxuICAgIGlmICghaG9zdGVkRmllbGRzLmN1cnJlbnQuaXNFbGlnaWJsZSgpKSB7XG4gICAgICByZXR1cm4gc2V0SXNFbGlnaWJsZShmYWxzZSk7XG4gICAgfVxuICAgIC8vIENsZWFuIGFsbCB0aGUgZmllbGRzIGJlZm9yZSB0aGUgcmVyZW5kZXJcbiAgICBpZiAoY2FyZEZpZWxkcykge1xuICAgICAgY2FyZEZpZWxkcy50ZWFyZG93bigpO1xuICAgIH1cbiAgICBob3N0ZWRGaWVsZHMuY3VycmVudC5yZW5kZXIoe1xuICAgICAgLy8gQ2FsbCB5b3VyIHNlcnZlciB0byBzZXQgdXAgdGhlIHRyYW5zYWN0aW9uXG4gICAgICBjcmVhdGVPcmRlcjogY3JlYXRlT3JkZXIsXG4gICAgICBmaWVsZHM6IHJlZ2lzdGVyZWRGaWVsZHMuY3VycmVudCxcbiAgICAgIGluc3RhbGxtZW50czogaW5zdGFsbG1lbnRzLFxuICAgICAgc3R5bGVzOiBzdHlsZXNcbiAgICB9KS50aGVuKGZ1bmN0aW9uIChjYXJkRmllbGRzSW5zdGFuY2UpIHtcbiAgICAgIGlmIChob3N0ZWRGaWVsZHNDb250YWluZXJSZWYuY3VycmVudCkge1xuICAgICAgICBzZXRDYXJkRmllbGRzKGNhcmRGaWVsZHNJbnN0YW5jZSk7XG4gICAgICB9XG4gICAgfSkuY2F0Y2goZnVuY3Rpb24gKGVycikge1xuICAgICAgc2V0RXJyb3JTdGF0ZShmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byByZW5kZXIgPFBheVBhbEhvc3RlZEZpZWxkc1Byb3ZpZGVyIC8+IGNvbXBvbmVudC4gXCIuY29uY2F0KGVycikpO1xuICAgICAgfSk7XG4gICAgfSk7XG4gIH0sIFtsb2FkaW5nU3RhdHVzLCBzdHlsZXNdKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIHJlZjogaG9zdGVkRmllbGRzQ29udGFpbmVyUmVmXG4gIH0sIGlzRWxpZ2libGUgPyBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbEhvc3RlZEZpZWxkc0NvbnRleHQuUHJvdmlkZXIsIHtcbiAgICB2YWx1ZToge1xuICAgICAgY2FyZEZpZWxkczogY2FyZEZpZWxkcyxcbiAgICAgIHJlZ2lzdGVySG9zdGVkRmllbGQ6IHJlZ2lzdGVySG9zdGVkRmllbGRcbiAgICB9XG4gIH0sIGNoaWxkcmVuKSA6IG5vdEVsaWdpYmxlRXJyb3IpO1xufTtcblxuLyoqXG5UaGlzIGA8UGF5UGFsSG9zdGVkRmllbGQgLz5gIGNvbXBvbmVudCByZW5kZXJzIGluZGl2aWR1YWwgZmllbGRzIGZvciBbSG9zdGVkIEZpZWxkc10oaHR0cHM6Ly9kZXZlbG9wZXIucGF5cGFsLmNvbS9kb2NzL2J1c2luZXNzL2NoZWNrb3V0L2FkdmFuY2VkLWNhcmQtcGF5bWVudHMvaW50ZWdyYXRlIzMtYWRkLWphdmFzY3JpcHQtc2RrLWFuZC1jYXJkLWZvcm0pIGludGVncmF0aW9ucy5cbkl0IHJlbGllcyBvbiB0aGUgYDxQYXlQYWxIb3N0ZWRGaWVsZHNQcm92aWRlciAvPmAgcGFyZW50IGNvbXBvbmVudCBmb3IgbWFuYWdpbmcgc3RhdGUgcmVsYXRlZCB0byBsb2FkaW5nIHRoZSBKUyBTREsgc2NyaXB0XG5hbmQgZXhlY3V0ZSBzb21lIHZhbGlkYXRpb25zIGJlZm9yZSB0aGUgcmVuZGVyaW5nIHRoZSBmaWVsZHMuXG5cblRvIHVzZSB0aGUgUGF5UGFsIGhvc3RlZCBmaWVsZHMgeW91IG5lZWQgdG8gZGVmaW5lIGF0IGxlYXN0IHRocmVlIGZpZWxkczpcblxuLSBBIGNhcmQgbnVtYmVyIGZpZWxkXG4tIFRoZSBDVlYgY29kZSBmcm9tIHRoZSBjbGllbnQgY2FyZFxuLSBUaGUgZXhwaXJhdGlvbiBkYXRlXG5cbllvdSBjYW4gZGVmaW5lIHRoZSBleHBpcmF0aW9uIGRhdGUgYXMgYSBzaW5nbGUgZmllbGQgc2ltaWxhciB0byB0aGUgZXhhbXBsZSBiZWxvdyxcbm9yIHlvdSBhcmUgYWJsZSB0byBkZWZpbmUgaXQgaW4gW3R3byBzZXBhcmF0ZSBmaWVsZHNdKGh0dHBzOi8vcGF5cGFsLmdpdGh1Yi5pby9wYXlwYWwtanMvd2ViLXNkay12NS1yZWFjdC1zdG9yeWJvb2svP3BhdGg9L2RvY3MvcGF5cGFsLXBheXBhbGhvc3RlZGZpZWxkcy0tZXhwaXJhdGlvbi1kYXRlKS4gT25lIGZvciB0aGUgbW9udGggYW5kIHNlY29uZCBmb3IgeWVhci5cblxuTm90ZTogVGFrZSBjYXJlIHdoZW4gdXNpbmcgbXVsdGlwbGUgaW5zdGFuY2VzIG9mIHRoZSBQYXlQYWwgSG9zdGVkIEZpZWxkcyBvbiB0aGUgc2FtZSBwYWdlLlxuVGhlIGNvbXBvbmVudCB3aWxsIGZhaWwgdG8gcmVuZGVyIHdoZW4gYW55IG9mIHRoZSBzZWxlY3RvcnMgcmV0dXJuIG1vcmUgdGhhbiBvbmUgZWxlbWVudC5cbiovXG52YXIgUGF5UGFsSG9zdGVkRmllbGQgPSBmdW5jdGlvbiAoX2EpIHtcbiAgdmFyIGhvc3RlZEZpZWxkVHlwZSA9IF9hLmhvc3RlZEZpZWxkVHlwZSxcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bnVzZWQtdmFyc1xuICAgIG9wdGlvbnMgPSBfYS5vcHRpb25zLFxuICAgIC8vIGVzbGludC1kaXNhYmxlLWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVudXNlZC12YXJzXG4gICAgcHJvcHMgPSBfX3Jlc3QkMShfYSwgW1wiaG9zdGVkRmllbGRUeXBlXCIsIFwib3B0aW9uc1wiXSk7XG4gIHZhciBob3N0ZWRGaWVsZENvbnRleHQgPSB1c2VDb250ZXh0KFBheVBhbEhvc3RlZEZpZWxkc0NvbnRleHQpO1xuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYTtcbiAgICBpZiAoIShob3N0ZWRGaWVsZENvbnRleHQgPT09IG51bGwgfHwgaG9zdGVkRmllbGRDb250ZXh0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBob3N0ZWRGaWVsZENvbnRleHQucmVnaXN0ZXJIb3N0ZWRGaWVsZCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoZSBIb3N0ZWRGaWVsZCBjYW5ub3QgYmUgcmVnaXN0ZXIgaW4gdGhlIFBheVBhbEhvc3RlZEZpZWxkc1Byb3ZpZGVyIHBhcmVudCBjb21wb25lbnRcIik7XG4gICAgfVxuICAgIC8vIFJlZ2lzdGVyIGluIHRoZSBwYXJlbnQgcHJvdmlkZXJcbiAgICBob3N0ZWRGaWVsZENvbnRleHQucmVnaXN0ZXJIb3N0ZWRGaWVsZCgoX2EgPSB7fSwgX2FbaG9zdGVkRmllbGRUeXBlXSA9IHtcbiAgICAgIHNlbGVjdG9yOiBvcHRpb25zLnNlbGVjdG9yLFxuICAgICAgcGxhY2Vob2xkZXI6IG9wdGlvbnMucGxhY2Vob2xkZXIsXG4gICAgICB0eXBlOiBvcHRpb25zLnR5cGUsXG4gICAgICBmb3JtYXRJbnB1dDogb3B0aW9ucy5mb3JtYXRJbnB1dCxcbiAgICAgIG1hc2tJbnB1dDogb3B0aW9ucy5tYXNrSW5wdXQsXG4gICAgICBzZWxlY3Q6IG9wdGlvbnMuc2VsZWN0LFxuICAgICAgbWF4bGVuZ3RoOiBvcHRpb25zLm1heGxlbmd0aCxcbiAgICAgIG1pbmxlbmd0aDogb3B0aW9ucy5taW5sZW5ndGgsXG4gICAgICBwcmVmaWxsOiBvcHRpb25zLnByZWZpbGwsXG4gICAgICByZWplY3RVbnN1cHBvcnRlZENhcmRzOiBvcHRpb25zLnJlamVjdFVuc3VwcG9ydGVkQ2FyZHNcbiAgICB9LCBfYSkpO1xuICB9LCBbXSk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIF9fYXNzaWduKHt9LCBwcm9wcykpO1xufTtcblxuLyoqXG4gKiBUaHJvdyBhbiBleGNlcHRpb24gaWYgdGhlIENhcmRGaWVsZHMgaXMgbm90IGZvdW5kIGluIHRoZSBwYXlwYWwgbmFtZXNwYWNlXG4gKiBQcm9iYWJseSBjYXVzZSBmb3IgdGhpcyBwcm9ibGVtIGlzIG5vdCBzZW5kaW5nIHRoZSBjYXJkLWZpZWxkcyBzdHJpbmdcbiAqIGFzIHBhcnQgb2YgdGhlIGNvbXBvbmVudHMgcHJvcHMgaW4gb3B0aW9uc1xuICoge0Bjb2RlIDxQYXlQYWxTY3JpcHRQcm92aWRlciBvcHRpb25zPXt7IGNvbXBvbmVudHM6ICdjYXJkLWZpZWxkcyd9fT59XG4gKlxuICogQHBhcmFtIHBhcmFtMCBhbmQgb2JqZWN0IGNvbnRhaW5pbmcgdGhlIGNvbXBvbmVudHMgYW5kIG5hbWVzcGFjZSBkZWZpbmVkIGluIG9wdGlvbnNcbiAqIEB0aHJvd3Mge0Bjb2RlIEVycm9yfVxuICpcbiAqL1xudmFyIGdlbmVyYXRlTWlzc2luZ0NhcmRGaWVsZHNFcnJvciA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgX2IgPSBfYS5jb21wb25lbnRzLFxuICAgIGNvbXBvbmVudHMgPSBfYiA9PT0gdm9pZCAwID8gXCJcIiA6IF9iLFxuICAgIF9jID0gU0RLX1NFVFRJTkdTLkRBVEFfTkFNRVNQQUNFLFxuICAgIF9kID0gX2FbX2NdLFxuICAgIGRhdGFOYW1lc3BhY2UgPSBfZCA9PT0gdm9pZCAwID8gREVGQVVMVF9QQVlQQUxfTkFNRVNQQUNFIDogX2Q7XG4gIHZhciBleHBlY3RlZENvbXBvbmVudHMgPSBjb21wb25lbnRzID8gXCJcIi5jb25jYXQoY29tcG9uZW50cywgXCIsY2FyZC1maWVsZHNcIikgOiBcImNhcmQtZmllbGRzXCI7XG4gIHZhciBlcnJvck1lc3NhZ2UgPSBcIlVuYWJsZSB0byByZW5kZXIgPFBheVBhbENhcmRGaWVsZHNQcm92aWRlciAvPiBiZWNhdXNlIHdpbmRvdy5cIi5jb25jYXQoZGF0YU5hbWVzcGFjZSwgXCIuQ2FyZEZpZWxkcyBpcyB1bmRlZmluZWQuXCIpO1xuICBpZiAoIWNvbXBvbmVudHMuaW5jbHVkZXMoXCJjYXJkLWZpZWxkc1wiKSkge1xuICAgIGVycm9yTWVzc2FnZSArPSBcIlxcblRvIGZpeCB0aGUgaXNzdWUsIGFkZCAnY2FyZC1maWVsZHMnIHRvIHRoZSBsaXN0IG9mIGNvbXBvbmVudHMgcGFzc2VkIHRvIHRoZSBwYXJlbnQgUGF5UGFsU2NyaXB0UHJvdmlkZXI6IDxQYXlQYWxTY3JpcHRQcm92aWRlciBvcHRpb25zPXt7IGNvbXBvbmVudHM6ICdcIi5jb25jYXQoZXhwZWN0ZWRDb21wb25lbnRzLCBcIid9fT5cIik7XG4gIH1cbiAgcmV0dXJuIGVycm9yTWVzc2FnZTtcbn07XG5mdW5jdGlvbiBpZ25vcmUoKSB7XG4gIHJldHVybjtcbn1cbmZ1bmN0aW9uIGhhc0NoaWxkcmVuKGNvbnRhaW5lcikge1xuICB2YXIgX2E7XG4gIHJldHVybiAhISgoX2EgPSBjb250YWluZXIuY3VycmVudCkgPT09IG51bGwgfHwgX2EgPT09IHZvaWQgMCA/IHZvaWQgMCA6IF9hLmNoaWxkcmVuLmxlbmd0aCk7XG59XG52YXIgUGF5UGFsQ2FyZEZpZWxkc0NvbnRleHQgPSBjcmVhdGVDb250ZXh0KHtcbiAgY2FyZEZpZWxkc0Zvcm06IG51bGwsXG4gIGZpZWxkczoge30sXG4gIHJlZ2lzdGVyRmllbGQ6IGlnbm9yZSxcbiAgLy8gaW1wbGVtZW50YXRpb24gaXMgaW5zaWRlIGhvb2sgYW5kIHBhc3NlZCB0aHJvdWdoIHRoZSBwcm92aWRlclxuICB1bnJlZ2lzdGVyRmllbGQ6IGlnbm9yZSAvLyBpbXBsZW1lbnRhdGlvbiBpcyBpbnNpZGUgaG9vayBhbmQgcGFzc2VkIHRocm91Z2ggdGhlIHByb3ZpZGVyXG59KTtcbnZhciB1c2VQYXlQYWxDYXJkRmllbGRzID0gZnVuY3Rpb24gKCkge1xuICByZXR1cm4gdXNlQ29udGV4dChQYXlQYWxDYXJkRmllbGRzQ29udGV4dCk7XG59O1xudmFyIHVzZVBheVBhbENhcmRGaWVsZHNSZWdpc3RyeSA9IGZ1bmN0aW9uICgpIHtcbiAgdmFyIF9hID0gdXNlU3RhdGUobnVsbCksXG4gICAgc2V0RXJyb3IgPSBfYVsxXTtcbiAgdmFyIHJlZ2lzdGVyZWRGaWVsZHMgPSB1c2VSZWYoe30pO1xuICB2YXIgcmVnaXN0ZXJGaWVsZCA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgcHJvcHMgPSBbXTtcbiAgICBmb3IgKHZhciBfaSA9IDA7IF9pIDwgYXJndW1lbnRzLmxlbmd0aDsgX2krKykge1xuICAgICAgcHJvcHNbX2ldID0gYXJndW1lbnRzW19pXTtcbiAgICB9XG4gICAgdmFyIGZpZWxkTmFtZSA9IHByb3BzWzBdLFxuICAgICAgb3B0aW9ucyA9IHByb3BzWzFdLFxuICAgICAgY2FyZEZpZWxkcyA9IHByb3BzWzJdO1xuICAgIGlmIChyZWdpc3RlcmVkRmllbGRzLmN1cnJlbnRbZmllbGROYW1lXSkge1xuICAgICAgc2V0RXJyb3IoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoQ0FSRF9GSUVMRFNfRFVQTElDQVRFX0NISUxEUkVOX0VSUk9SKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnRbZmllbGROYW1lXSA9IGNhcmRGaWVsZHMgPT09IG51bGwgfHwgY2FyZEZpZWxkcyA9PT0gdm9pZCAwID8gdm9pZCAwIDogY2FyZEZpZWxkc1tmaWVsZE5hbWVdKG9wdGlvbnMpO1xuICAgIHJldHVybiByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnRbZmllbGROYW1lXTtcbiAgfTtcbiAgdmFyIHVucmVnaXN0ZXJGaWVsZCA9IGZ1bmN0aW9uIChmaWVsZE5hbWUpIHtcbiAgICB2YXIgZmllbGQgPSByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnRbZmllbGROYW1lXTtcbiAgICBpZiAoZmllbGQpIHtcbiAgICAgIGZpZWxkLmNsb3NlKCkuY2F0Y2goaWdub3JlKTtcbiAgICAgIGRlbGV0ZSByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnRbZmllbGROYW1lXTtcbiAgICB9XG4gIH07XG4gIHJldHVybiB7XG4gICAgZmllbGRzOiByZWdpc3RlcmVkRmllbGRzLmN1cnJlbnQsXG4gICAgcmVnaXN0ZXJGaWVsZDogcmVnaXN0ZXJGaWVsZCxcbiAgICB1bnJlZ2lzdGVyRmllbGQ6IHVucmVnaXN0ZXJGaWVsZFxuICB9O1xufTtcbnZhciBGdWxsV2lkdGhDb250YWluZXIgPSBmdW5jdGlvbiAoX2EpIHtcbiAgdmFyIGNoaWxkcmVuID0gX2EuY2hpbGRyZW47XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFwiZGl2XCIsIHtcbiAgICBzdHlsZToge1xuICAgICAgd2lkdGg6IFwiMTAwJVwiXG4gICAgfVxuICB9LCBjaGlsZHJlbik7XG59O1xuXG4vKipcblRoZSBgPFBheVBhbENhcmRGaWVsZHNQcm92aWRlciAvPmAgaXMgYSBjb250ZXh0IHByb3ZpZGVyIHRoYXQgaXMgZGVzaWduZWQgdG8gc3VwcG9ydCB0aGUgcmVuZGVyaW5nIGFuZCBzdGF0ZSBtYW5hZ2VtZW50IG9mIFBheVBhbCBDYXJkRmllbGRzIGluIHlvdXIgYXBwbGljYXRpb24uXG5cblRoZSBjb250ZXh0IHByb3ZpZGVyIHdpbGwgaW5pdGlhbGl6ZSB0aGUgYENhcmRGaWVsZHNgIGluc3RhbmNlIGZyb20gdGhlIEpTIFNESyBhbmQgZGV0ZXJtaW5lIGVsaWdpYmlsaXR5IHRvIHJlbmRlciB0aGUgQ2FyZEZpZWxkIGNvbXBvbmVudHMuIE9uY2UgdGhlIGBDYXJkRmllbGRzYCBhcmUgaW5pdGlhbGl6ZWQsIHRoZSBjb250ZXh0IHByb3ZpZGVyIHdpbGwgbWFuYWdlIHRoZSBzdGF0ZSBvZiB0aGUgYENhcmRGaWVsZHNgIGluc3RhbmNlIGFzIHdlbGwgYXMgdGhlIHJlZmVyZW5jZSB0byBlYWNoIGluZGl2aWR1YWwgY2FyZCBmaWVsZC5cblxuUGFzc2luZyB0aGUgYGlucHV0RXZlbnRzYCBhbmQgYHN0eWxlYCBwcm9wcyB0byB0aGUgY29udGV4dCBwcm92aWRlciB3aWxsIGFwcGx5IHRoZW0gdG8gZWFjaCBvZiB0aGUgaW5kaXZpZHVhbCBmaWVsZCBjb21wb25lbnRzLlxuXG5UaGUgc3RhdGUgbWFuYWdlZCBieSB0aGUgcHJvdmlkZXIgaXMgYWNjZXNzaWJsZSB0aHJvdWdoIG91ciBjdXN0b20gaG9vayBgdXNlUGF5UGFsQ2FyZEZpZWxkc2AuXG5cbiovXG52YXIgUGF5UGFsQ2FyZEZpZWxkc1Byb3ZpZGVyID0gZnVuY3Rpb24gKF9hKSB7XG4gIHZhciBjaGlsZHJlbiA9IF9hLmNoaWxkcmVuLFxuICAgIHByb3BzID0gX19yZXN0JDEoX2EsIFtcImNoaWxkcmVuXCJdKTtcbiAgdmFyIHByb3h5SW5wdXRFdmVudHMgPSB1c2VQcm94eVByb3BzKHByb3BzLmlucHV0RXZlbnRzKTtcbiAgdmFyIHByb3h5UHJvcHMgPSB1c2VQcm94eVByb3BzKHByb3BzKTtcbiAgdmFyIF9iID0gdXNlUGF5UGFsU2NyaXB0UmVkdWNlcigpWzBdLFxuICAgIGlzUmVzb2x2ZWQgPSBfYi5pc1Jlc29sdmVkLFxuICAgIG9wdGlvbnMgPSBfYi5vcHRpb25zO1xuICB2YXIgX2MgPSB1c2VQYXlQYWxDYXJkRmllbGRzUmVnaXN0cnkoKSxcbiAgICBmaWVsZHMgPSBfYy5maWVsZHMsXG4gICAgcmVnaXN0ZXJGaWVsZCA9IF9jLnJlZ2lzdGVyRmllbGQsXG4gICAgdW5yZWdpc3RlckZpZWxkID0gX2MudW5yZWdpc3RlckZpZWxkO1xuICB2YXIgX2QgPSB1c2VTdGF0ZShudWxsKSxcbiAgICBjYXJkRmllbGRzRm9ybSA9IF9kWzBdLFxuICAgIHNldENhcmRGaWVsZHNGb3JtID0gX2RbMV07XG4gIHZhciBjYXJkRmllbGRzSW5zdGFuY2UgPSB1c2VSZWYobnVsbCk7XG4gIHZhciBfZSA9IHVzZVN0YXRlKGZhbHNlKSxcbiAgICBpc0VsaWdpYmxlID0gX2VbMF0sXG4gICAgc2V0SXNFbGlnaWJsZSA9IF9lWzFdO1xuICAvLyBXZSBzZXQgdGhlIGVycm9yIGluc2lkZSBzdGF0ZSBzbyB0aGF0IGl0IGNhbiBiZSBjYXVnaHQgYnkgUmVhY3QncyBlcnJvciBib3VuZGFyeVxuICB2YXIgX2YgPSB1c2VTdGF0ZShudWxsKSxcbiAgICBzZXRFcnJvciA9IF9mWzFdO1xuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIHZhciBfYSwgX2IsIF9jO1xuICAgIGlmICghaXNSZXNvbHZlZCkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAocHJvcHMuaW5wdXRFdmVudHMpIHtcbiAgICAgIHByb3h5UHJvcHMuaW5wdXRFdmVudHMgPSBwcm94eUlucHV0RXZlbnRzO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgY2FyZEZpZWxkc0luc3RhbmNlLmN1cnJlbnQgPSAoX2MgPSAoX2IgPSAoX2EgPSBnZXRQYXlQYWxXaW5kb3dOYW1lc3BhY2UkMShnZXRPd25Qcm9wZXJ0eSQxKG9wdGlvbnMsIFwiZGF0YU5hbWVzcGFjZVwiKSkpLkNhcmRGaWVsZHMpID09PSBudWxsIHx8IF9iID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfYi5jYWxsKF9hLCBfX2Fzc2lnbih7fSwgcHJveHlQcm9wcykpKSAhPT0gbnVsbCAmJiBfYyAhPT0gdm9pZCAwID8gX2MgOiBudWxsO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBzZXRFcnJvcihmdW5jdGlvbiAoKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkZhaWxlZCB0byByZW5kZXIgPFBheVBhbENhcmRGaWVsZHNQcm92aWRlciAvPiBjb21wb25lbnQuIEZhaWxlZCB0byBpbml0aWFsaXplOiAgXCIuY29uY2F0KGVycm9yKSk7XG4gICAgICB9KTtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKCFjYXJkRmllbGRzSW5zdGFuY2UuY3VycmVudCkge1xuICAgICAgc2V0RXJyb3IoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoZ2VuZXJhdGVNaXNzaW5nQ2FyZEZpZWxkc0Vycm9yKHtcbiAgICAgICAgICBjb21wb25lbnRzOiBvcHRpb25zLmNvbXBvbmVudHMsXG4gICAgICAgICAgZGF0YU5hbWVzcGFjZTogZ2V0T3duUHJvcGVydHkkMShvcHRpb25zLCBcImRhdGFOYW1lc3BhY2VcIilcbiAgICAgICAgfSkpO1xuICAgICAgfSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHNldElzRWxpZ2libGUoY2FyZEZpZWxkc0luc3RhbmNlLmN1cnJlbnQuaXNFbGlnaWJsZSgpKTtcbiAgICBzZXRDYXJkRmllbGRzRm9ybShjYXJkRmllbGRzSW5zdGFuY2UuY3VycmVudCk7XG4gICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgIHNldENhcmRGaWVsZHNGb3JtKG51bGwpO1xuICAgICAgY2FyZEZpZWxkc0luc3RhbmNlLmN1cnJlbnQgPSBudWxsO1xuICAgIH07XG4gIH0sIFtpc1Jlc29sdmVkXSk7IC8vIGVzbGludC1kaXNhYmxlLWxpbmUgcmVhY3QtaG9va3MvZXhoYXVzdGl2ZS1kZXBzXG4gIGlmICghaXNFbGlnaWJsZSkge1xuICAgIC8vIFRPRE86IFdoYXQgc2hvdWxkIGJlIHJldHVybmVkIGhlcmU/XG4gICAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwgbnVsbCk7XG4gIH1cbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRnVsbFdpZHRoQ29udGFpbmVyLCBudWxsLCBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbENhcmRGaWVsZHNDb250ZXh0LlByb3ZpZGVyLCB7XG4gICAgdmFsdWU6IHtcbiAgICAgIGNhcmRGaWVsZHNGb3JtOiBjYXJkRmllbGRzRm9ybSxcbiAgICAgIGZpZWxkczogZmllbGRzLFxuICAgICAgcmVnaXN0ZXJGaWVsZDogcmVnaXN0ZXJGaWVsZCxcbiAgICAgIHVucmVnaXN0ZXJGaWVsZDogdW5yZWdpc3RlckZpZWxkXG4gICAgfVxuICB9LCBjaGlsZHJlbikpO1xufTtcbnZhciBQYXlQYWxDYXJkRmllbGQgPSBmdW5jdGlvbiAoX2EpIHtcbiAgdmFyIGNsYXNzTmFtZSA9IF9hLmNsYXNzTmFtZSxcbiAgICBmaWVsZE5hbWUgPSBfYS5maWVsZE5hbWUsXG4gICAgb3B0aW9ucyA9IF9fcmVzdCQxKF9hLCBbXCJjbGFzc05hbWVcIiwgXCJmaWVsZE5hbWVcIl0pO1xuICB2YXIgX2IgPSB1c2VQYXlQYWxDYXJkRmllbGRzKCksXG4gICAgY2FyZEZpZWxkc0Zvcm0gPSBfYi5jYXJkRmllbGRzRm9ybSxcbiAgICByZWdpc3RlckZpZWxkID0gX2IucmVnaXN0ZXJGaWVsZCxcbiAgICB1bnJlZ2lzdGVyRmllbGQgPSBfYi51bnJlZ2lzdGVyRmllbGQ7XG4gIHZhciBjb250YWluZXJSZWYgPSB1c2VSZWYobnVsbCk7XG4gIHZhciBwcm94eUlucHV0RXZlbnRzID0gdXNlUHJveHlQcm9wcyhvcHRpb25zLmlucHV0RXZlbnRzKTtcbiAgLy8gU2V0IGVycm9ycyBpcyBzdGF0ZSBzbyB0aGF0IHRoZXkgY2FuIGJlIGNhdWdodCBieSBSZWFjdCdzIGVycm9yIGJvdW5kYXJ5XG4gIHZhciBfYyA9IHVzZVN0YXRlKG51bGwpLFxuICAgIHNldEVycm9yID0gX2NbMV07XG4gIGZ1bmN0aW9uIGNsb3NlQ29tcG9uZW50KCkge1xuICAgIHVucmVnaXN0ZXJGaWVsZChmaWVsZE5hbWUpO1xuICB9XG4gIHVzZUVmZmVjdChmdW5jdGlvbiAoKSB7XG4gICAgaWYgKCFjYXJkRmllbGRzRm9ybSkge1xuICAgICAgc2V0RXJyb3IoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoQ0FSRF9GSUVMRFNfQ09OVEVYVF9FUlJPUik7XG4gICAgICB9KTtcbiAgICAgIHJldHVybiBjbG9zZUNvbXBvbmVudDtcbiAgICB9XG4gICAgaWYgKCFjb250YWluZXJSZWYuY3VycmVudCkge1xuICAgICAgcmV0dXJuIGNsb3NlQ29tcG9uZW50O1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5pbnB1dEV2ZW50cykge1xuICAgICAgb3B0aW9ucy5pbnB1dEV2ZW50cyA9IHByb3h5SW5wdXRFdmVudHM7XG4gICAgfVxuICAgIHZhciByZWdpc3RlcmVkRmllbGQgPSByZWdpc3RlckZpZWxkKGZpZWxkTmFtZSwgb3B0aW9ucywgY2FyZEZpZWxkc0Zvcm0pO1xuICAgIHJlZ2lzdGVyZWRGaWVsZCA9PT0gbnVsbCB8fCByZWdpc3RlcmVkRmllbGQgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHJlZ2lzdGVyZWRGaWVsZC5yZW5kZXIoY29udGFpbmVyUmVmLmN1cnJlbnQpLmNhdGNoKGZ1bmN0aW9uIChlcnIpIHtcbiAgICAgIGlmICghaGFzQ2hpbGRyZW4oY29udGFpbmVyUmVmKSkge1xuICAgICAgICAvLyBDb21wb25lbnQgbm8gbG9uZ2VyIGluIHRoZSBET00sIHdlIGNhbiBzYWZlbHkgaWdub3JlIHRoZSBlcnJvclxuICAgICAgICByZXR1cm47XG4gICAgICB9XG4gICAgICAvLyBDb21wb25lbnQgaXMgc3RpbGwgaW4gdGhlIERPTVxuICAgICAgc2V0RXJyb3IoZnVuY3Rpb24gKCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJGYWlsZWQgdG8gcmVuZGVyIDxQYXlQYWxcIi5jb25jYXQoZmllbGROYW1lLCBcIiAvPiBjb21wb25lbnQuIFwiKS5jb25jYXQoZXJyKSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4gY2xvc2VDb21wb25lbnQ7XG4gIH0sIFtdKTsgLy8gZXNsaW50LWRpc2FibGUtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIiwge1xuICAgIHJlZjogY29udGFpbmVyUmVmLFxuICAgIGNsYXNzTmFtZTogY2xhc3NOYW1lXG4gIH0pO1xufTtcbnZhciBQYXlQYWxOYW1lRmllbGQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChQYXlQYWxDYXJkRmllbGQsIF9fYXNzaWduKHtcbiAgICBmaWVsZE5hbWU6IFwiTmFtZUZpZWxkXCJcbiAgfSwgb3B0aW9ucykpO1xufTtcbnZhciBQYXlQYWxOdW1iZXJGaWVsZCA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gIHJldHVybiBSZWFjdC5jcmVhdGVFbGVtZW50KFBheVBhbENhcmRGaWVsZCwgX19hc3NpZ24oe1xuICAgIGZpZWxkTmFtZTogXCJOdW1iZXJGaWVsZFwiXG4gIH0sIG9wdGlvbnMpKTtcbn07XG52YXIgUGF5UGFsRXhwaXJ5RmllbGQgPSBmdW5jdGlvbiAob3B0aW9ucykge1xuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChQYXlQYWxDYXJkRmllbGQsIF9fYXNzaWduKHtcbiAgICBmaWVsZE5hbWU6IFwiRXhwaXJ5RmllbGRcIlxuICB9LCBvcHRpb25zKSk7XG59O1xudmFyIFBheVBhbENWVkZpZWxkID0gZnVuY3Rpb24gKG9wdGlvbnMpIHtcbiAgcmV0dXJuIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGF5UGFsQ2FyZEZpZWxkLCBfX2Fzc2lnbih7XG4gICAgZmllbGROYW1lOiBcIkNWVkZpZWxkXCJcbiAgfSwgb3B0aW9ucykpO1xufTtcbnZhciBGbGV4Q29udGFpbmVyID0gZnVuY3Rpb24gKF9hKSB7XG4gIHZhciBjaGlsZHJlbiA9IF9hLmNoaWxkcmVuO1xuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgc3R5bGU6IHtcbiAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgd2lkdGg6IFwiMTAwJVwiXG4gICAgfVxuICB9LCBjaGlsZHJlbik7XG59O1xuXG4vKipcblRoaXMgYDxQYXlQYWxDYXJkRmllbGRzRm9ybSAvPmAgY29tcG9uZW50IHJlbmRlcnMgdGhlIDQgaW5kaXZpZHVhbCBmaWVsZHMgZm9yIFtDYXJkIEZpZWxkc10oaHR0cHM6Ly9kZXZlbG9wZXIucGF5cGFsLmNvbS9kb2NzL2J1c2luZXNzL2NoZWNrb3V0L2FkdmFuY2VkLWNhcmQtcGF5bWVudHMvaW50ZWdyYXRlIzMtYWRkLWphdmFzY3JpcHQtc2RrLWFuZC1jYXJkLWZvcm0pIGludGVncmF0aW9ucy5cblRoaXMgc2V0dXAgcmVsaWVzIG9uIHRoZSBgPFBheVBhbENhcmRGaWVsZHNQcm92aWRlciAvPmAgcGFyZW50IGNvbXBvbmVudCwgd2hpY2ggbWFuYWdlcyB0aGUgc3RhdGUgcmVsYXRlZCB0byBsb2FkaW5nIHRoZSBKUyBTREsgc2NyaXB0IGFuZCBwZXJmb3JtcyBjZXJ0YWluIHZhbGlkYXRpb25zIGJlZm9yZSByZW5kZXJpbmcgdGhlIGZpZWxkcy5cblxuXG5cbk5vdGU6IElmIHlvdSB3YW50IHRvIGhhdmUgbW9yZSBncmFudWxhciBjb250cm9sIG92ZXIgdGhlIGxheW91dCBvZiBob3cgdGhlIGZpZWxkcyBhcmUgcmVuZGVyZWQsIHlvdSBjYW4gYWx0ZXJuYXRpdmVseSB1c2Ugb3VyIEluZGl2aWR1YWwgRmllbGRzLlxuKi9cbnZhciBQYXlQYWxDYXJkRmllbGRzRm9ybSA9IGZ1bmN0aW9uIChfYSkge1xuICB2YXIgY2xhc3NOYW1lID0gX2EuY2xhc3NOYW1lO1xuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChcImRpdlwiLCB7XG4gICAgY2xhc3NOYW1lOiBjbGFzc05hbWVcbiAgfSwgUmVhY3QuY3JlYXRlRWxlbWVudChQYXlQYWxDYXJkRmllbGQsIHtcbiAgICBmaWVsZE5hbWU6IFwiTmFtZUZpZWxkXCJcbiAgfSksIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGF5UGFsQ2FyZEZpZWxkLCB7XG4gICAgZmllbGROYW1lOiBcIk51bWJlckZpZWxkXCJcbiAgfSksIFJlYWN0LmNyZWF0ZUVsZW1lbnQoRmxleENvbnRhaW5lciwgbnVsbCwgUmVhY3QuY3JlYXRlRWxlbWVudChGdWxsV2lkdGhDb250YWluZXIsIG51bGwsIFJlYWN0LmNyZWF0ZUVsZW1lbnQoUGF5UGFsQ2FyZEZpZWxkLCB7XG4gICAgZmllbGROYW1lOiBcIkV4cGlyeUZpZWxkXCJcbiAgfSkpLCBSZWFjdC5jcmVhdGVFbGVtZW50KEZ1bGxXaWR0aENvbnRhaW5lciwgbnVsbCwgUmVhY3QuY3JlYXRlRWxlbWVudChQYXlQYWxDYXJkRmllbGQsIHtcbiAgICBmaWVsZE5hbWU6IFwiQ1ZWRmllbGRcIlxuICB9KSkpKTtcbn07XG52YXIgRlVORElORyQxID0ge1xuICBQQVlQQUw6IFwicGF5cGFsXCIsXG4gIFZFTk1POiBcInZlbm1vXCIsXG4gIEFQUExFUEFZOiBcImFwcGxlcGF5XCIsXG4gIElUQVU6IFwiaXRhdVwiLFxuICBDUkVESVQ6IFwiY3JlZGl0XCIsXG4gIFBBWUxBVEVSOiBcInBheWxhdGVyXCIsXG4gIENBUkQ6IFwiY2FyZFwiLFxuICBJREVBTDogXCJpZGVhbFwiLFxuICBTRVBBOiBcInNlcGFcIixcbiAgQkFOQ09OVEFDVDogXCJiYW5jb250YWN0XCIsXG4gIEdJUk9QQVk6IFwiZ2lyb3BheVwiLFxuICBTT0ZPUlQ6IFwic29mb3J0XCIsXG4gIEVQUzogXCJlcHNcIixcbiAgTVlCQU5LOiBcIm15YmFua1wiLFxuICBQMjQ6IFwicDI0XCIsXG4gIFBBWVU6IFwicGF5dVwiLFxuICBCTElLOiBcImJsaWtcIixcbiAgVFJVU1RMWTogXCJ0cnVzdGx5XCIsXG4gIE9YWE86IFwib3h4b1wiLFxuICBCT0xFVE86IFwiYm9sZXRvXCIsXG4gIEJPTEVUT0JBTkNBUklPOiBcImJvbGV0b2JhbmNhcmlvXCIsXG4gIFdFQ0hBVFBBWTogXCJ3ZWNoYXRwYXlcIixcbiAgTUVSQ0FET1BBR086IFwibWVyY2Fkb3BhZ29cIixcbiAgTVVMVElCQU5DTzogXCJtdWx0aWJhbmNvXCIsXG4gIFNBVElTUEFZOiBcInNhdGlzcGF5XCIsXG4gIFBBSURZOiBcInBhaWR5XCIsXG4gIFpJTVBMRVI6IFwiemltcGxlclwiLFxuICBNQVhJTUE6IFwibWF4aW1hXCJcbn07XG5bRlVORElORyQxLklERUFMLCBGVU5ESU5HJDEuQkFOQ09OVEFDVCwgRlVORElORyQxLkdJUk9QQVksIEZVTkRJTkckMS5TT0ZPUlQsIEZVTkRJTkckMS5FUFMsIEZVTkRJTkckMS5NWUJBTkssIEZVTkRJTkckMS5QMjQsIEZVTkRJTkckMS5QQVlVLCBGVU5ESU5HJDEuQkxJSywgRlVORElORyQxLlRSVVNUTFksIEZVTkRJTkckMS5PWFhPLCBGVU5ESU5HJDEuQk9MRVRPLCBGVU5ESU5HJDEuQk9MRVRPQkFOQ0FSSU8sIEZVTkRJTkckMS5XRUNIQVRQQVksIEZVTkRJTkckMS5NRVJDQURPUEFHTywgRlVORElORyQxLk1VTFRJQkFOQ08sIEZVTkRJTkckMS5TQVRJU1BBWSwgRlVORElORyQxLlBBSURZLCBGVU5ESU5HJDEuTUFYSU1BLCBGVU5ESU5HJDEuWklNUExFUl07XG5cbi8vIFdlIGRvIG5vdCByZS1leHBvcnQgYEZVTkRJTkdgIGZyb20gdGhlIGBzZGstY29uc3RhbnRzYCBtb2R1bGVcbi8vIGRpcmVjdGx5IGJlY2F1c2UgaXQgaGFzIG5vIHR5cGUgZGVmaW5pdGlvbnMuXG4vL1xuLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9wYXlwYWwvcmVhY3QtcGF5cGFsLWpzL2lzc3Vlcy8xMjVcbnZhciBGVU5ESU5HID0gRlVORElORyQxO1xuZXhwb3J0IHsgQnJhaW50cmVlUGF5UGFsQnV0dG9ucywgRElTUEFUQ0hfQUNUSU9OLCBGVU5ESU5HLCBQQVlQQUxfSE9TVEVEX0ZJRUxEU19UWVBFUywgUGF5UGFsQnV0dG9ucywgUGF5UGFsQ1ZWRmllbGQsIFBheVBhbENhcmRGaWVsZHNDb250ZXh0LCBQYXlQYWxDYXJkRmllbGRzRm9ybSwgUGF5UGFsQ2FyZEZpZWxkc1Byb3ZpZGVyLCBQYXlQYWxFeHBpcnlGaWVsZCwgUGF5UGFsSG9zdGVkRmllbGQsIFBheVBhbEhvc3RlZEZpZWxkc1Byb3ZpZGVyLCBQYXlQYWxNYXJrcywgUGF5UGFsTWVzc2FnZXMsIFBheVBhbE5hbWVGaWVsZCwgUGF5UGFsTnVtYmVyRmllbGQsIFBheVBhbFNjcmlwdFByb3ZpZGVyLCBTQ1JJUFRfTE9BRElOR19TVEFURSwgU2NyaXB0Q29udGV4dCwgZGVzdHJveVNES1NjcmlwdCwgZ2V0U2NyaXB0SUQsIHNjcmlwdFJlZHVjZXIsIHVzZVBheVBhbENhcmRGaWVsZHMsIHVzZVBheVBhbEhvc3RlZEZpZWxkcywgdXNlUGF5UGFsU2NyaXB0UmVkdWNlciwgdXNlU2NyaXB0UHJvdmlkZXJDb250ZXh0IH07XG4iXSwiaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBdUJBLElBQUk7Q0FDSCxTQUFVLHNCQUFzQjtDQUMvQixxQkFBcUIsYUFBYTtDQUNsQyxxQkFBcUIsYUFBYTtDQUNsQyxxQkFBcUIsY0FBYztDQUNuQyxxQkFBcUIsY0FBYztBQUNyQyxFQUFBLENBQUcseUJBQXlCLHVCQUF1QixDQUFDLEVBQUU7Ozs7OztBQU10RCxJQUFJO0NBQ0gsU0FBVSxpQkFBaUI7Q0FDMUIsZ0JBQWdCLG9CQUFvQjtDQUNwQyxnQkFBZ0IsbUJBQW1CO0NBQ25DLGdCQUFnQiw0QkFBNEI7QUFDOUMsRUFBQSxDQUFHLG9CQUFvQixrQkFBa0IsQ0FBQyxFQUFFOzs7Ozs7QUFNNUMsSUFBSTtDQUNILFNBQVUsNEJBQTRCO0NBQ3JDLDJCQUEyQixZQUFZO0NBQ3ZDLDJCQUEyQixTQUFTO0NBQ3BDLDJCQUEyQixxQkFBcUI7Q0FDaEQsMkJBQTJCLHNCQUFzQjtDQUNqRCwyQkFBMkIscUJBQXFCO0NBQ2hELDJCQUEyQixpQkFBaUI7QUFDOUMsRUFBQSxDQUFHLCtCQUErQiw2QkFBNkIsQ0FBQyxFQUFFO0FBQ2xFLElBQUksZ0JBQWdCLFNBQVUsR0FBRyxHQUFHO0NBQ2xDLGdCQUFnQixPQUFPLGtCQUFrQixFQUN2QyxXQUFXLENBQUMsRUFDZCxhQUFhLFNBQVMsU0FBVSxHQUFHLEdBQUc7RUFDcEMsRUFBRSxZQUFZO0NBQ2hCLEtBQUssU0FBVSxHQUFHLEdBQUc7RUFDbkIsS0FBSyxJQUFJLEtBQUssR0FBRyxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssR0FBRyxDQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUU7Q0FDNUU7Q0FDQSxPQUFPLGNBQWMsR0FBRyxDQUFDO0FBQzNCO0FBQ0EsU0FBUyxVQUFVLEdBQUcsR0FBRztDQUN2QixJQUFJLE9BQU8sTUFBTSxjQUFjLE1BQU0sTUFBTSxNQUFNLElBQUksVUFBVSx5QkFBeUIsT0FBTyxDQUFDLElBQUksK0JBQStCO0NBQ25JLGNBQWMsR0FBRyxDQUFDO0NBQ2xCLFNBQVMsS0FBSztFQUNaLEtBQUssY0FBYztDQUNyQjtDQUNBLEVBQUUsWUFBWSxNQUFNLE9BQU8sT0FBTyxPQUFPLENBQUMsS0FBSyxHQUFHLFlBQVksRUFBRSxXQUFXLElBQUksR0FBRztBQUNwRjtBQUNBLElBQUksV0FBVyxXQUFZO0NBQ3pCLFdBQVcsT0FBTyxVQUFVLFNBQVMsU0FBUyxHQUFHO0VBQy9DLEtBQUssSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLFVBQVUsUUFBUSxJQUFJLEdBQUcsS0FBSztHQUNuRCxJQUFJLFVBQVU7R0FDZCxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLENBQUMsR0FBRyxFQUFFLEtBQUssRUFBRTtFQUM1RTtFQUNBLE9BQU87Q0FDVDtDQUNBLE9BQU8sU0FBUyxNQUFNLE1BQU0sU0FBUztBQUN2QztBQUNBLFNBQVMsU0FBUyxHQUFHLEdBQUc7Q0FDdEIsSUFBSSxJQUFJLENBQUM7Q0FDVCxLQUFLLElBQUksS0FBSyxHQUFHLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLEdBQUcsRUFBRSxLQUFLLEVBQUU7Q0FDOUYsSUFBSSxLQUFLLFFBQVEsT0FBTyxPQUFPLDBCQUEwQixZQUFpQjtPQUFBLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxzQkFBc0IsQ0FBQyxHQUFHLElBQUksRUFBRSxRQUFRLEtBQ3RJLElBQUksRUFBRSxRQUFRLEVBQUUsRUFBRSxJQUFJLEtBQUssT0FBTyxVQUFVLHFCQUFxQixLQUFLLEdBQUcsRUFBRSxFQUFFLEdBQUcsRUFBRSxFQUFFLE1BQU0sRUFBRSxFQUFFO0NBQUE7Q0FFaEcsT0FBTztBQUNUO0FBQ0EsU0FBUyxjQUFjLElBQUksTUFBTSxNQUFNO0NBQ3JDLElBQUksUUFBUSxVQUFVLFdBQVcsR0FBUTtPQUFBLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLElBQUksSUFBSSxHQUFHLEtBQzlFLElBQUksTUFBTSxFQUFFLEtBQUssT0FBTztHQUN0QixJQUFJLENBQUMsSUFBSSxLQUFLLE1BQU0sVUFBVSxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUM7R0FDbkQsR0FBRyxLQUFLLEtBQUs7RUFDZjs7Q0FFRixPQUFPLEdBQUcsT0FBTyxNQUFNLE1BQU0sVUFBVSxNQUFNLEtBQUssSUFBSSxDQUFDO0FBQ3pEOzs7O0FBVUEsSUFBSSxZQUFZO0FBQ2hCLElBQUksZUFBZTtDQUNqQixtQkFBbUI7Q0FDbkIscUJBQXFCO0NBQ3JCLG9CQUFvQjtDQUNwQixnQkFBZ0I7Q0FDaEIsNkJBQTZCO0NBQzdCLG9CQUFvQjtBQUN0QjtBQUNBLElBQUksb0JBQW9COzs7O0FBSXhCLElBQUksOENBQThDO0FBQ2xELElBQUksbUJBQW1CO0FBQ3ZCLElBQUksbUJBQW1CLHVDQUF1QyxPQUFPLGtCQUFrQixtQkFBbUI7QUFDMUcsSUFBSSxtQ0FBbUMsdUNBQXVDLE9BQU8sa0JBQWtCLDRCQUE0Qjs7OztBQUluSSxJQUFJLDJCQUEyQjtBQUMvQixJQUFJLDhCQUE4Qjs7OztBQUlsQyxJQUFJLCtCQUErQjtBQUNuQyxJQUFJLHlDQUF5Qzs7OztBQUk3QyxJQUFJLGdDQUFnQztBQUNwQyxJQUFJLHVDQUF1QztBQUMzQyxJQUFJLDRCQUE0Qjs7Ozs7Ozs7O0FBVWhDLFNBQVMsMkJBQTJCLFdBQVc7Q0FDN0MsSUFBSSxjQUFjLEtBQUssR0FDckIsWUFBWTtDQUdkLE9BQU8sT0FBTztBQUNoQjs7Ozs7Ozs7O0FBU0EsU0FBUyw0QkFBNEIsV0FBVztDQUM5QyxJQUFJLGNBQWMsS0FBSyxHQUNyQixZQUFZO0NBR2QsT0FBTyxPQUFPO0FBQ2hCOzs7Ozs7O0FBT0EsU0FBUyxRQUFRLEtBQUs7Q0FDcEIsSUFBSSxPQUFPO0NBQ1gsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0VBQ25DLElBQUksUUFBUSxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsSUFBSTtFQUNuQyxJQUFJLElBQUksSUFBSSxJQUNWLFNBQVMsSUFBSSxJQUFJLEVBQUUsQ0FBQyxXQUFXLENBQUMsS0FBSyxJQUFJO0VBRTNDLFFBQVEsT0FBTyxhQUFhLEtBQUssS0FBSyxJQUFJLEtBQUssSUFBSSxFQUFFO0NBQ3ZEO0NBQ0EsT0FBTztBQUNUOzs7Ozs7OztBQVFBLFNBQVMsaUJBQWlCLFNBQVMsS0FBSztDQUN0QyxPQUFPLE9BQU8sVUFBVSxlQUFlLEtBQUssU0FBUyxHQUFHLElBQUksUUFBUSxPQUFPLEtBQUE7QUFDN0U7QUFDQSxTQUFTLHFCQUFxQixJQUFJO0NBQ2hDLElBQUkscUJBQXFCLEdBQUcsb0JBQzFCLGtCQUFrQixHQUFHLGlCQUNyQixLQUFLLEdBQUcsd0JBQ1IseUJBQXlCLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFDOUMsS0FBSyxHQUFHLGtCQUNSLG1CQUFtQixPQUFPLEtBQUssSUFBSSwyQkFBMkI7Q0FDaEUsSUFBSSw0QkFBNEIsZ0JBQWdCLE9BQU8sQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsT0FBTyxnQkFBZ0IsVUFBVSxDQUFDLENBQUM7Q0FDM0csSUFBSSxlQUFlLHFCQUFxQixPQUFPLG9CQUFvQixxQkFBcUIsQ0FBQyxDQUFDLE9BQU8sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDLE9BQU8sMkJBQTJCLGdCQUFnQjtDQUcxSyxJQUFJLHNCQUFzQixPQUFPLDJCQUEyQixXQUFXLHlCQUF5Qix1QkFBdUIsS0FBSyxHQUFHO0NBQy9ILElBQUksQ0FBQyxvQkFBb0IsU0FBUyxlQUFlLEdBQUc7RUFDbEQsSUFBSSxxQkFBcUIsQ0FBQyxxQkFBcUIsZUFBZSxDQUFDLENBQUMsT0FBTyxPQUFPLENBQUMsQ0FBQyxLQUFLO0VBQ3JGLGdCQUFnQiw0QkFBNEIsT0FBTyxpQkFBaUIsd0VBQXdFLElBQUksb0RBQW9ELE9BQU8sb0JBQW9CLFFBQVE7Q0FDek87Q0FDQSxPQUFPO0FBQ1Q7Ozs7OztBQU9BLFNBQVMsWUFBWSxTQUFTO0NBRzVCLElBQUksS0FBSyxTQUNQLEtBQUs7Q0FDUCxHQUFHO0NBQ0gsSUFBSSxzQkFBc0IsU0FBUyxJQUFJLENBQUMsS0FBSyxFQUFFLENBQUM7Q0FDaEQsT0FBTyxtQkFBbUIsT0FBTyxRQUFRLEtBQUssVUFBVSxtQkFBbUIsQ0FBQyxDQUFDO0FBQy9FOzs7Ozs7QUFNQSxTQUFTLGlCQUFpQixxQkFBcUI7Q0FDN0MsSUFBSSxhQUFhLEtBQUssU0FBUyxjQUFjLFVBQVUsT0FBTyxXQUFXLEtBQUssQ0FBQyxDQUFDLE9BQU8scUJBQXFCLEtBQUssQ0FBQztDQUNsSCxJQUFJLGVBQWUsUUFBUSxlQUFlLEtBQUssSUFBSSxLQUFLLElBQUksV0FBVyxZQUNyRSxXQUFXLFdBQVcsWUFBWSxVQUFVO0FBRWhEOzs7Ozs7OztBQVFBLFNBQVMsY0FBYyxPQUFPLFFBQVE7Q0FDcEMsSUFBSSxJQUFJO0NBQ1IsUUFBUSxPQUFPLE1BQWY7RUFDRSxLQUFLLGdCQUFnQjtHQUNuQixJQUFJLE9BQU8sT0FBTyxVQUFVLFVBQzFCLE9BQU8sU0FBUyxTQUFTLENBQUMsR0FBRyxLQUFLLEdBQUc7SUFDbkMsZUFBZSxPQUFPLE1BQU07SUFDNUIsMkJBQTJCLE9BQU8sTUFBTTtHQUMxQyxDQUFDO0dBRUgsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUNuQyxlQUFlLE9BQU8sTUFDeEIsQ0FBQztFQUNILEtBQUssZ0JBQWdCO0dBRW5CLGlCQUFpQixNQUFNLFFBQVEsVUFBVTtHQUN6QyxPQUFPLFNBQVMsU0FBUyxDQUFDLEdBQUcsS0FBSyxHQUFHO0lBQ25DLGVBQWUscUJBQXFCO0lBQ3BDLFNBQVMsU0FBUyxVQUFVLEtBQUssQ0FBQyxHQUFHLEdBQUcsYUFBYSwrQkFBK0IsYUFBYSxvQkFBb0IsS0FBSyxPQUFPLEtBQUssSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFHLGFBQWEsR0FBRyxPQUFPLFlBQVksT0FBTyxLQUFLLENBQUMsR0FBRyxHQUFHO0dBQzlNLENBQUM7RUFDSCxLQUFLLGdCQUFnQix3QkFDbkIsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUNuQyxpQ0FBaUMsT0FBTyxNQUMxQyxDQUFDO0VBQ0gsU0FFSSxPQUFPO0NBRWI7QUFDRjtBQUVBLElBQUksaUJBQUEsR0FBZ0JBLGFBQUFBLGNBQUFBLENBQWMsSUFBSTs7Ozs7OztBQVF0QyxTQUFTLGdCQUFnQixlQUFlO0NBQ3RDLElBQUksUUFBUSxrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLGNBQWMsY0FBYyxjQUFjLFNBQVMsV0FBVyxHQUNwSixPQUFPO0NBRVQsTUFBTSxJQUFJLE1BQU0sNkJBQTZCO0FBQy9DOzs7Ozs7Ozs7OztBQVdBLElBQUkscUNBQXFDLFNBQVUsZUFBZTtDQUNoRSxJQUFJLElBQUk7Q0FDUixJQUFJLEdBQUcsS0FBSyxrQkFBa0IsUUFBUSxrQkFBa0IsS0FBSyxJQUFJLEtBQUssSUFBSSxjQUFjLGFBQWEsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxhQUFhLHVCQUF1QixHQUFHLEtBQUssa0JBQWtCLFFBQVEsa0JBQWtCLEtBQUssSUFBSSxLQUFLLElBQUksY0FBYyxhQUFhLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsYUFBYSxzQkFDN1QsTUFBTSxJQUFJLE1BQU0sMkNBQTJDO0NBRTdELE9BQU87QUFDVDs7Ozs7Ozs7QUFTQSxTQUFTLHlCQUF5QjtDQUNoQyxJQUFJLGdCQUFnQixpQkFBQSxHQUFnQkMsYUFBQUEsV0FBQUEsQ0FBVyxhQUFhLENBQUM7Q0FPN0QsT0FBTyxDQU5vQixTQUFTLFNBQVMsQ0FBQyxHQUFHLGFBQWEsR0FBRztFQUMvRCxXQUFXLGNBQWMsa0JBQWtCLHFCQUFxQjtFQUNoRSxXQUFXLGNBQWMsa0JBQWtCLHFCQUFxQjtFQUNoRSxZQUFZLGNBQWMsa0JBQWtCLHFCQUFxQjtFQUNqRSxZQUFZLGNBQWMsa0JBQWtCLHFCQUFxQjtDQUNuRSxDQUMyQixHQUFHLGNBQWMsUUFBUTtBQUN0RDs7Ozs7O0FBTUEsU0FBUywyQkFBMkI7Q0FDbEMsSUFBSSxnQkFBZ0IsbUNBQW1DLGlCQUFBLEdBQWdCQSxhQUFBQSxXQUFBQSxDQUFXLGFBQWEsQ0FBQyxDQUFDO0NBQ2pHLE9BQU8sQ0FBQyxlQUFlLGNBQWMsUUFBUTtBQUMvQztBQUdBLElBQUksNkJBQUEsR0FBNEJELGFBQUFBLGNBQUFBLENBQWMsQ0FBQyxDQUFDOzs7Ozs7OztBQVNoRCxTQUFTLHdCQUF3QjtDQUMvQixRQUFBLEdBQU9DLGFBQUFBLFdBQUFBLENBQVcseUJBQXlCO0FBQzdDOzs7Ozs7O0FBUUEsU0FBUyxjQUFjLE9BQU87Q0FDNUIsSUFBSSxZQUFBLEdBQVdDLGFBQUFBLE9BQUFBLENBQU8sSUFBSSxNQUFNLENBQUMsR0FBRyxFQUNsQyxLQUFLLFNBQVUsUUFBUSxNQUFNLFVBQVU7Ozs7Ozs7OztFQVNyQyxJQUFJLE9BQU8sT0FBTyxVQUFVLFlBQzFCLE9BQU8sV0FBWTtHQUNqQixJQUFJLE9BQU8sQ0FBQztHQUNaLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxVQUFVLFFBQVEsTUFDdEMsS0FBSyxNQUFNLFVBQVU7R0FFdkIsT0FBTyxPQUFPLEtBQUssQ0FBQyxNQUFNLFFBQVEsSUFBSTtFQUN4QztFQUVGLE9BQU8sUUFBUSxJQUFJLFFBQVEsTUFBTSxRQUFRO0NBQzNDLEVBQ0YsQ0FBQyxDQUFDO0NBQ0YsU0FBUyxVQUFVLE9BQU8sT0FBTyxTQUFTLFNBQVMsS0FBSztDQUN4RCxPQUFPLFNBQVM7QUFDbEI7QUFDQSxJQUFJLDZCQUEwQyxTQUFVLFFBQVE7Q0FDOUQsVUFBVSw0QkFBNEIsTUFBTTtDQUM1QyxTQUFTLDJCQUEyQixPQUFPO0VBQ3pDLElBQUksUUFBUSxPQUFPLEtBQUssTUFBTSxLQUFLLEtBQUs7RUFDeEMsTUFBTSxRQUFRLEVBQ1osVUFBVSxNQUNaO0VBQ0EsT0FBTztDQUNUO0NBQ0EsMkJBQTJCLDJCQUEyQixXQUFZO0VBQ2hFLE9BQU8sRUFDTCxVQUFVLEtBQ1o7Q0FDRjtDQUNBLDJCQUEyQixVQUFVLG9CQUFvQixTQUFVLE9BQU8sV0FBVztFQUNuRixRQUFRLE1BQU0scUNBQXFDLE9BQU8sU0FBUztFQUduRSxJQUFJLE9BQU8sS0FBSyxNQUFNLFlBQVksWUFDaEMsS0FBSyxNQUFNLFFBQVE7R0FDakIsU0FBUyxNQUFNO0dBQ2YsTUFBTSxNQUFNO0dBQ1osT0FBTyxNQUFNO0dBQ2IsZ0JBQWdCLFVBQVU7RUFDNUIsQ0FBQztDQUVMO0NBQ0EsMkJBQTJCLFVBQVUsU0FBUyxXQUFZO0VBQ3hELElBQUksS0FBSyxNQUFNLFVBQ2IsT0FBTztFQUVULE9BQU8sS0FBSyxNQUFNO0NBQ3BCO0NBQ0EsT0FBTztBQUNULEVBQUVDLGFBQUFBLFNBQVM7Ozs7QUFLWCxJQUFJLHFCQUFxQixTQUFVLElBQUk7Q0FDckMsSUFBSTtDQUNKLElBQUksS0FBSyxHQUFHLFdBQ1YsWUFBWSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQ2pDLEtBQUssR0FBRyxVQUNSLFdBQVcsT0FBTyxLQUFLLElBQUksUUFBUSxJQUNuQyxXQUFXLEdBQUcsVUFDZCxLQUFLLEdBQUcsZUFDUixnQkFBZ0IsT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQ3JDLGNBQWMsU0FBUyxJQUFJO0VBQUM7RUFBYTtFQUFZO0VBQVk7Q0FBZSxDQUFDO0NBQ25GLElBQUksa0JBQWtCLFdBQVcsRUFDL0IsU0FBUyxJQUNYLElBQUksQ0FBQztDQUNMLElBQUksYUFBYSxHQUFHLE9BQU8sV0FBVyxHQUFHLENBQUMsQ0FBQyxPQUFPLFdBQVcsNEJBQTRCLEVBQUUsQ0FBQyxDQUFDLEtBQUs7Q0FDbEcsSUFBSSx1QkFBQSxHQUFzQkQsYUFBQUEsT0FBQUEsQ0FBTyxJQUFJO0NBQ3JDLElBQUksV0FBQSxHQUFVQSxhQUFBQSxPQUFBQSxDQUFPLElBQUk7Q0FDekIsSUFBSSxhQUFhLGNBQWMsV0FBVztDQUMxQyxJQUFJLEtBQUssdUJBQXVCLENBQUMsQ0FBQyxJQUNoQyxhQUFhLEdBQUcsWUFDaEIsVUFBVSxHQUFHO0NBQ2YsSUFBSSxNQUFBLEdBQUtFLGFBQUFBLFNBQUFBLENBQVMsSUFBSSxHQUNwQixjQUFjLEdBQUcsSUFDakIsaUJBQWlCLEdBQUc7Q0FDdEIsSUFBSSxNQUFBLEdBQUtBLGFBQUFBLFNBQUFBLENBQVMsSUFBSSxHQUNwQixhQUFhLEdBQUcsSUFDaEIsZ0JBQWdCLEdBQUc7Q0FDckIsSUFDRSxpQkFBQSxHQURPQSxhQUFBQSxTQUFBQSxDQUFTLElBQ0MsQ0FBQyxDQUFDO0NBQ3JCLFNBQVMsd0JBQXdCO0VBQy9CLElBQUksUUFBUSxZQUFZLE1BQ3RCLFFBQVEsUUFBUSxNQUFNLENBQUMsQ0FBQyxNQUFNLFdBQVksQ0FFMUMsQ0FBQztDQUVMO0NBQ0EsS0FBSyxLQUFLLFFBQVEsYUFBYSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLGFBQ2pFLFFBQVEsUUFBUSxZQUFZLEVBQzFCLFNBQVMsWUFBWSxRQUN2QixDQUFDO0NBR0gsQ0FBQSxHQUFBLGFBQUEsVUFBQSxDQUFVLFdBQVk7RUFFcEIsSUFBSSxlQUFlLE9BQ2pCLE9BQU87RUFFVCxJQUFJLHdCQUF3QiwyQkFBMkIsaUJBQWlCLFNBQVMsZUFBZSxDQUFDO0VBRWpHLElBQUksMEJBQTBCLEtBQUEsS0FBYSxzQkFBc0IsWUFBWSxLQUFBLEdBQVc7R0FDdEYsY0FBYyxXQUFZO0lBQ3hCLE1BQU0sSUFBSSxNQUFNLHFCQUFxQjtLQUNuQyxvQkFBb0IsY0FBYztLQUNsQyxpQkFBaUI7S0FDakIsd0JBQXdCLFFBQVE7S0FDaEMsa0JBQWtCLGlCQUFpQixTQUFTLGVBQWU7SUFDN0QsQ0FBQyxDQUFDO0dBQ0osQ0FBQztHQUNELE9BQU87RUFDVDtFQUNBLElBQUksa0JBQWtCLFNBQVUsTUFBTSxTQUFTO0dBQzdDLGVBQWUsT0FBTztHQUN0QixJQUFJLE9BQU8sWUFBWSxXQUFXLFlBQ2hDLFlBQVksT0FBTyxNQUFNLE9BQU87RUFFcEM7RUFDQSxJQUFJO0dBQ0YsUUFBUSxVQUFVLHNCQUFzQixRQUFRLFNBQVMsU0FBUyxDQUFDLEdBQUcsVUFBVSxHQUFHLEVBQ2pGLFFBQVEsZ0JBQ1YsQ0FBQyxDQUFDO0VBQ0osU0FBUyxLQUFLO0dBQ1osT0FBTyxjQUFjLFdBQVk7SUFDL0IsTUFBTSxJQUFJLE1BQU0sd0VBQXdFLE9BQU8sR0FBRyxDQUFDO0dBQ3JHLENBQUM7RUFDSDtFQUVBLElBQUksUUFBUSxRQUFRLFdBQVcsTUFBTSxPQUFPO0dBQzFDLGNBQWMsS0FBSztHQUNuQixPQUFPO0VBQ1Q7RUFDQSxJQUFJLENBQUMsb0JBQW9CLFNBQ3ZCLE9BQU87RUFFVCxRQUFRLFFBQVEsT0FBTyxvQkFBb0IsT0FBTyxDQUFDLENBQUMsTUFBTSxTQUFVLEtBQUs7R0FFdkUsSUFBSSxvQkFBb0IsWUFBWSxRQUFRLG9CQUFvQixRQUFRLFNBQVMsV0FBVyxHQUUxRjtHQUdGLGNBQWMsV0FBWTtJQUN4QixNQUFNLElBQUksTUFBTSxpREFBaUQsT0FBTyxHQUFHLENBQUM7R0FDOUUsQ0FBQztFQUNILENBQUM7RUFDRCxPQUFPO0NBRVQsR0FBRyxjQUFjLGNBQWMsQ0FBQyxVQUFVLEdBQUcsZUFBZSxJQUFJLEdBQUcsQ0FBQyxZQUFZLGFBQWEsR0FBRyxLQUFLLENBQUM7Q0FFdEcsQ0FBQSxHQUFBLGFBQUEsVUFBQSxDQUFVLFdBQVk7RUFDcEIsSUFBSSxnQkFBZ0IsTUFDbEI7RUFFRixJQUFJLGFBQWEsTUFDZixZQUFZLFFBQVEsQ0FBQyxDQUFDLE1BQU0sV0FBWSxDQUV4QyxDQUFDO09BRUQsWUFBWSxPQUFPLENBQUMsQ0FBQyxNQUFNLFdBQVksQ0FFdkMsQ0FBQztDQUVMLEdBQUcsQ0FBQyxVQUFVLFdBQVcsQ0FBQztDQUMxQixPQUFBLGFBQWEsY0FBQSxhQUFvQixVQUFVLE1BQU0sYUFBQSxhQUFtQixjQUFjLE9BQU87RUFDdkYsS0FBSztFQUNMLE9BQU87RUFDUCxXQUFXO0NBQ2IsQ0FBQyxJQUFJLFFBQVE7QUFDZjtBQUNBLG1CQUFtQixjQUFjOzs7OztBQUtqQyxJQUFJLGdCQUFnQixTQUFVLE9BQU87Q0FDbkMsT0FBQSxhQUFhLGNBQWMsNEJBQTRCLEVBQ3JELFNBQVMsTUFBTSxRQUNqQixHQUFBLGFBQVMsY0FBYyxvQkFBb0IsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUM7QUFDakU7QUFDQSxjQUFjLGNBQWM7QUFDNUIsU0FBUyxPQUFPLEdBQUcsR0FBRztDQUNwQixJQUFJLElBQUksQ0FBQztDQUNULEtBQUssSUFBSSxLQUFLLEdBQUcsSUFBSSxPQUFPLFVBQVUsZUFBZSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEVBQUUsUUFBUSxDQUFDLElBQUksR0FBRyxFQUFFLEtBQUssRUFBRTtDQUM5RixJQUFJLEtBQUssUUFBUSxPQUFPLE9BQU8sMEJBQTBCLFlBQWlCO09BQUEsSUFBSSxJQUFJLEdBQUcsSUFBSSxPQUFPLHNCQUFzQixDQUFDLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FDdEksSUFBSSxFQUFFLFFBQVEsRUFBRSxFQUFFLElBQUksS0FBSyxPQUFPLFVBQVUscUJBQXFCLEtBQUssR0FBRyxFQUFFLEVBQUUsR0FBRyxFQUFFLEVBQUUsTUFBTSxFQUFFLEVBQUU7Q0FBQTtDQUVoRyxPQUFPO0FBQ1Q7QUFLQSxTQUFTLFdBQVcsS0FBSyxZQUFZO0NBQ25DLElBQUksZ0JBQWdCLFNBQVMsY0FBYyxnQkFBZ0IsT0FBTyxLQUFLLEtBQUssQ0FBQztDQUM3RSxJQUFJLGtCQUFrQixNQUFNLE9BQU87Q0FDbkMsSUFBSSxhQUFhLG9CQUFvQixLQUFLLFVBQVU7Q0FDcEQsSUFBSSxxQkFBcUIsY0FBYyxVQUFVO0NBQ2pELE9BQU8sbUJBQW1CLFFBQVE7Q0FDbEMsSUFBSSxPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLFdBQVcsT0FBTyxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsUUFDckYsT0FBTztDQUVULElBQUksZUFBZTtDQUNuQixPQUFPLEtBQUssbUJBQW1CLE9BQU8sQ0FBQyxDQUFDLFFBQVEsU0FBVSxLQUFLO0VBQzdELElBQUksbUJBQW1CLFFBQVEsU0FBUyxXQUFXLFFBQVEsTUFDekQsZUFBZTtDQUVuQixDQUFDO0NBQ0QsT0FBTyxlQUFlLGdCQUFnQjtBQUN4QztBQUNBLFNBQVMsb0JBQW9CLElBQUk7Q0FDL0IsSUFBSSxNQUFNLEdBQUcsS0FDWCxhQUFhLEdBQUcsWUFDaEIsWUFBWSxHQUFHLFdBQ2YsVUFBVSxHQUFHO0NBQ2YsSUFBSSxZQUFZLG9CQUFvQixLQUFLLFVBQVU7Q0FDbkQsVUFBVSxVQUFVO0NBQ3BCLFVBQVUsU0FBUztDQUNuQixTQUFTLEtBQUssYUFBYSxXQUFXLFNBQVMsS0FBSyxpQkFBaUI7QUFDdkU7QUFDQSxTQUFTLGVBQWUsU0FBUztDQUMvQixJQUFJLG1CQUFtQixlQUFlLFNBQVMsWUFBWTtDQUMzRCxJQUFJLGNBQWMsZUFBZSxTQUFTLGFBQWE7Q0FDdkQsUUFBUTtDQUNSLFFBQVE7Q0FDUixJQUFJLE9BQU8sT0FBTyxTQUFTLENBQUMsZUFBZSxZQUFZLENBQUM7Q0FDeEQsSUFBSSxhQUFhLG9CQUFvQixrQkFBa0IsV0FBVztDQUNsRSxJQUFJLHlCQUF5QjtDQUM3QixJQUFJLEtBQUssT0FBTyxLQUFLLHNCQUFzQixDQUFDLENBQUMsT0FBTyxTQUFVLEtBQUs7RUFDL0QsT0FBTyxPQUFPLHVCQUF1QixTQUFTLGVBQWUsdUJBQXVCLFNBQVMsUUFBUSx1QkFBdUIsU0FBUztDQUN2SSxDQUFDLENBQUMsQ0FBQyxPQUFPLFNBQVUsYUFBYSxLQUFLO0VBQ3BDLElBQUksUUFBUSx1QkFBdUIsSUFBSSxDQUFDLFNBQVM7RUFDakQsTUFBTSxxQkFBcUIsR0FBRztFQUM5QixJQUFJLElBQUksVUFBVSxHQUFHLENBQUMsTUFBTSxVQUFVLFFBQVEsZUFDNUMsWUFBWSxXQUFXLE9BQU87T0FFOUIsWUFBWSxZQUFZLE9BQU87RUFFakMsT0FBTztDQUNULEdBQUc7RUFDRCxhQUFhLENBQUM7RUFDZCxZQUFZLENBQUM7Q0FDZixDQUFDLEdBQ0QsY0FBYyxHQUFHLGFBQ2pCLGFBQWEsR0FBRztDQUNsQixJQUFJLGFBQWEsZUFBZSxhQUFhLGFBQWE7Q0FDMUQsSUFBSSxjQUFjLFdBQVcsUUFBUSxHQUFHLE1BQU0sSUFBSTtFQUNoRCxXQUFXLHNCQUFzQjtFQUNqQyxZQUFZLGlCQUFpQjtDQUMvQjtDQUNBLE9BQU87RUFDTCxLQUFLLEdBQUcsT0FBTyxZQUFZLEdBQUcsQ0FBQyxDQUFDLE9BQU8sb0JBQW9CLFdBQVcsQ0FBQztFQUMzRDtDQUNkO0FBQ0Y7QUFDQSxTQUFTLHFCQUFxQixLQUFLO0NBQ2pDLElBQUksV0FBVyxTQUFVLE9BQU8sY0FBYztFQUM1QyxRQUFRLGVBQWUsTUFBTSxNQUFNLE1BQU0sWUFBWTtDQUN2RDtDQUNBLE9BQU8sSUFBSSxRQUFRLDBCQUEwQixRQUFRO0FBQ3ZEO0FBQ0EsU0FBUyxvQkFBb0IsUUFBUTtDQUNuQyxJQUFJLGNBQWM7Q0FDbEIsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFFBQVEsU0FBVSxLQUFLO0VBQ3pDLElBQUksWUFBWSxXQUFXLEdBQUcsZUFBZTtFQUM3QyxlQUFlLE1BQU0sTUFBTSxPQUFPO0NBQ3BDLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGtCQUFrQixhQUFhO0NBQ3RDLE9BQU8sZ0JBQWdCLFlBQVksMENBQTBDO0FBQy9FO0FBQ0EsU0FBUyxvQkFBb0IsS0FBSyxZQUFZO0NBQzVDLElBQUksZUFBZSxLQUFLLEdBQ3RCLGFBQWEsQ0FBQztDQUVoQixJQUFJLFlBQVksU0FBUyxjQUFjLFFBQVE7Q0FDL0MsVUFBVSxNQUFNO0NBQ2hCLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLFNBQVUsS0FBSztFQUM3QyxVQUFVLGFBQWEsS0FBSyxXQUFXLElBQUk7RUFDM0MsSUFBSSxRQUFRLGtCQUNWLFVBQVUsYUFBYSxTQUFTLFdBQVcsaUJBQWlCO0NBRWhFLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFDQSxTQUFTLGVBQWUsU0FBUyxLQUFLO0NBQ3BDLE9BQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxTQUFTLEdBQUcsSUFBSSxRQUFRLE9BQU8sS0FBQTtBQUM3RTtBQUNBLFNBQVMsV0FBVyxTQUFTLGlCQUFpQjtDQUM1QyxJQUFJLG9CQUFvQixLQUFLLEdBQzNCLGtCQUFrQjtDQUVwQixrQkFBa0IsU0FBUyxlQUFlO0NBQzFDLElBQUksT0FBTyxhQUFhLGFBQWEsT0FBTyxnQkFBZ0IsUUFBUSxJQUFJO0NBQ3hFLElBQUksS0FBSyxlQUFlLE9BQU8sR0FDN0IsTUFBTSxHQUFHLEtBQ1QsYUFBYSxHQUFHO0NBQ2xCLElBQUksWUFBWSxlQUFlLFlBQVksZ0JBQWdCLEtBQUs7Q0FDaEUsSUFBSSwwQkFBMEIseUJBQXlCLFNBQVM7Q0FDaEUsSUFBSSxDQUFDLGVBQWUsWUFBWSxxQkFBcUIsR0FDbkQsV0FBVyx5QkFBeUI7Q0FFdEMsSUFBSSxXQUFXLEtBQUssVUFBVSxLQUFLLHlCQUNqQyxPQUFPLGdCQUFnQixRQUFRLHVCQUF1QjtDQUV4RCxPQUFPLGlCQUFpQjtFQUNqQjtFQUNPO0NBQ2QsR0FBRyxlQUFlLENBQUMsQ0FBQyxLQUFLLFdBQVk7RUFDbkMsSUFBSSxxQkFBcUIseUJBQXlCLFNBQVM7RUFDM0QsSUFBSSxvQkFDRixPQUFPO0VBRVQsTUFBTSxJQUFJLE1BQU0sY0FBYyxPQUFPLFdBQVcsb0NBQW9DLENBQUM7Q0FDdkYsQ0FBQztBQUNIO0FBQ0EsU0FBUyxpQkFBaUIsU0FBUyxpQkFBaUI7Q0FDbEQsSUFBSSxvQkFBb0IsS0FBSyxHQUMzQixrQkFBa0I7Q0FFcEIsa0JBQWtCLFNBQVMsZUFBZTtDQUMxQyxJQUFJLE1BQU0sZUFBZSxTQUFTLEtBQUs7Q0FDdkMsSUFBSSxhQUFhLGVBQWUsU0FBUyxZQUFZO0NBQ3JELElBQUksT0FBTyxRQUFRLFlBQVksSUFBSSxXQUFXLEdBQzVDLE1BQU0sSUFBSSxNQUFNLGNBQWM7Q0FFaEMsSUFBSSxPQUFPLGVBQWUsZUFBZSxPQUFPLGVBQWUsVUFDN0QsTUFBTSxJQUFJLE1BQU0sc0NBQXNDO0NBRXhELE9BQU8sSUFBSSxnQkFBZ0IsU0FBVSxTQUFTLFFBQVE7RUFDcEQsSUFBSSxPQUFPLGFBQWEsYUFBYSxPQUFPLFFBQVE7RUFDcEQsb0JBQW9CO0dBQ2I7R0FDTztHQUNaLFdBQVcsV0FBWTtJQUNyQixPQUFPLFFBQVE7R0FDakI7R0FDQSxTQUFTLFdBQVk7SUFFbkIsT0FBTyxPQUFPLElBRFMsTUFBTSxnQkFBZ0IsT0FBTyxLQUFLLDRGQUE0RixDQUM1SCxDQUFDO0dBQzVCO0VBQ0YsQ0FBQztDQUNILENBQUM7QUFDSDtBQUNBLFNBQVMseUJBQXlCLFdBQVc7Q0FDM0MsT0FBTyxPQUFPO0FBQ2hCO0FBQ0EsU0FBUyxrQkFBa0IsU0FBUyxpQkFBaUI7Q0FDbkQsSUFBSSxPQUFPLFlBQVksWUFBWSxZQUFZLE1BQzdDLE1BQU0sSUFBSSxNQUFNLDZCQUE2QjtDQUUvQyxJQUFJLGNBQWMsZUFBZSxTQUFTLGFBQWE7Q0FDdkQsSUFBSSxlQUFlLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLFdBQ2pFLE1BQU0sSUFBSSxNQUFNLHdFQUFvRTtDQUV0RixJQUFJLE9BQU8sb0JBQW9CLGVBQWUsT0FBTyxvQkFBb0IsWUFDdkUsTUFBTSxJQUFJLE1BQU0sNENBQTRDO0FBRWhFOzs7Ozs7O0FBUUEsSUFBSSw0QkFBNEIsU0FBVSxpQkFBaUI7Q0FDekQsSUFBSSxJQUFJO0NBQ1IsSUFBSSxTQUFTLEtBQUssb0JBQW9CLFFBQVEsb0JBQW9CLEtBQUssSUFBSSxLQUFLLElBQUksZ0JBQWdCLFlBQVksUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxZQUFZLGNBQWMsU0FBUyxLQUFLLG9CQUFvQixRQUFRLG9CQUFvQixLQUFLLElBQUksS0FBSyxJQUFJLGdCQUFnQixvQkFBb0IsUUFBUSxPQUFPLEtBQUssSUFBSSxLQUFLLElBQUksR0FBRyxZQUFZLFlBQ2hWLE1BQU0sSUFBSSxNQUFNLHlFQUF5RTtDQUUzRixPQUFPO0FBQ1Q7Ozs7Ozs7O0FBUUEsSUFBSSxrQkFBa0IsU0FBVSxhQUFhLHdCQUF3QjtDQUNuRSxJQUFJLGlCQUFpQixZQUFZO0NBQ2pDLElBQUksNEJBQTRCLFlBQVk7Q0FDNUMsSUFBSSxlQUFlLFlBQVk7Q0FDL0IsSUFBSSxPQUFPLG1CQUFtQixZQUM1QixZQUFZLGNBQWMsU0FBVSxNQUFNLFNBQVM7RUFDakQsT0FBTyxlQUFlLE1BQU0sU0FBUyxTQUFTLENBQUMsR0FBRyxPQUFPLEdBQUcsRUFDMUQsV0FBVyx1QkFDYixDQUFDLENBQUM7Q0FDSjtDQUVGLElBQUksT0FBTyw4QkFBOEIsWUFDdkMsWUFBWSx5QkFBeUIsU0FBVSxNQUFNLFNBQVM7RUFDNUQsT0FBTywwQkFBMEIsTUFBTSxTQUFTLFNBQVMsQ0FBQyxHQUFHLE9BQU8sR0FBRyxFQUNyRSxXQUFXLHVCQUNiLENBQUMsQ0FBQztDQUNKO0NBRUYsSUFBSSxPQUFPLGlCQUFpQixZQUMxQixZQUFZLFlBQVksU0FBVSxNQUFNLFNBQVM7RUFDL0MsT0FBTyxhQUFhLE1BQU0sU0FBUyxTQUFTLENBQUMsR0FBRyxPQUFPLEdBQUcsRUFDeEQsV0FBVyx1QkFDYixDQUFDLENBQUM7Q0FDSjtDQUVGLE9BQU8sU0FBUyxDQUFDLEdBQUcsV0FBVztBQUNqQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFpQkEsSUFBSSx3QkFBd0IsU0FBVSxpQkFBaUI7Q0FDckQsSUFBSSxtQkFBbUIsMEJBQTBCLGVBQWUsR0FDOUQsT0FBTyxRQUFRLFFBQVEsZUFBZTtDQUV4QyxPQUFPLFFBQVEsSUFBSSxDQUFDLGlCQUFpQixFQUNuQyxLQUFLLGlCQUNQLENBQUMsR0FBRyxpQkFBaUIsRUFDbkIsS0FBSyxpQ0FDUCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFZO0VBQ3BCLE9BQU8sNEJBQTRCO0NBQ3JDLENBQUM7QUFDSDs7Ozs7Ozs7OztBQVdBLElBQUkseUJBQXlCLFNBQVUsSUFBSTtDQUN6QyxJQUFJLEtBQUssR0FBRyxXQUNWLFlBQVksT0FBTyxLQUFLLElBQUksS0FBSyxJQUNqQyxLQUFLLEdBQUcsVUFDUixXQUFXLE9BQU8sS0FBSyxJQUFJLFFBQVEsSUFDbkMsV0FBVyxHQUFHLFVBQ2QsS0FBSyxHQUFHLGVBQ1IsZ0JBQWdCLE9BQU8sS0FBSyxJQUFJLENBQUMsSUFBSSxJQUNyQyxxQkFBcUIsR0FBRyxvQkFDeEIsb0JBQW9CLEdBQUcsbUJBQ3ZCLGNBQWMsU0FBUyxJQUFJO0VBQUM7RUFBYTtFQUFZO0VBQVk7RUFBaUI7RUFBc0I7Q0FBbUIsQ0FBQztDQUM5SCxJQUNFLGlCQUFBLEdBRE9BLGFBQUFBLFNBQUFBLENBQVMsSUFDQyxDQUFDLENBQUM7Q0FDckIsSUFBSSxLQUFLLHlCQUF5QixHQUNoQyxrQkFBa0IsR0FBRyxJQUNyQixXQUFXLEdBQUc7Q0FDaEIsQ0FBQSxHQUFBLGFBQUEsVUFBQSxDQUFVLFdBQVk7RUFDcEIsc0JBQXNCLGtCQUFrQixDQUFDLENBQUMsS0FBSyxTQUFVLFdBQVc7R0FDbEUsSUFBSSx3QkFBd0IsZ0JBQWdCLFFBQVEsYUFBYTtHQUNqRSxJQUFJLGNBQWMsZ0JBQWdCLFFBQVEsYUFBYTtHQUN2RCxPQUFPLFVBQVUsT0FBTyxPQUFPLEVBQzdCLGVBQWUseUJBQXlCLFlBQzFDLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBVSxnQkFBZ0I7SUFDaEMsSUFBSSxlQUFlLG9CQUFvQixFQUNsQixrQkFDckIsSUFBSSxDQUFDO0lBQ0wsT0FBTyxVQUFVLGVBQWUsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLFlBQVksR0FBRyxFQUMxRSxRQUFRLGVBQ1YsQ0FBQyxDQUFDO0dBQ0osQ0FBQyxDQUFDLENBQUMsS0FBSyxTQUFVLHdCQUF3QjtJQUN4QyxTQUFTO0tBQ1AsTUFBTSxnQkFBZ0I7S0FDdEIsT0FBTztJQUNULENBQUM7R0FDSCxDQUFDO0VBQ0gsQ0FBQyxDQUFDLENBQUMsTUFBTSxTQUFVLEtBQUs7R0FDdEIsY0FBYyxXQUFZO0lBQ3hCLE1BQU0sSUFBSSxNQUFNLEdBQUcsT0FBTyxtQkFBbUIsR0FBRyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7R0FDL0QsQ0FBQztFQUNILENBQUM7Q0FFSCxHQUFHLENBQUMsZ0JBQWdCLE9BQU8sQ0FBQztDQUM1QixPQUFBLGFBQWEsY0FBQSxhQUFvQixVQUFVLE1BQU0sZ0JBQWdCLG1DQUFBLGFBQXlDLGNBQWMsZUFBZSxTQUFTO0VBQ25JO0VBQ0Q7RUFDSztDQUNqQixHQUFHLGdCQUFnQixhQUFhLGdCQUFnQiwrQkFBK0IsQ0FBQyxHQUFHLFFBQVEsQ0FBQztBQUM5Rjs7Ozs7Ozs7O0FBVUEsSUFBSSxjQUFjLFNBQVUsSUFBSTtDQUM5QixJQUFJLEtBQUssR0FBRyxXQUNWLFlBQVksT0FBTyxLQUFLLElBQUksS0FBSyxJQUNqQyxXQUFXLEdBQUcsVUFDZCxZQUFZLFNBQVMsSUFBSSxDQUFDLGFBQWEsVUFBVSxDQUFDO0NBQ3BELElBQUksS0FBSyx1QkFBdUIsQ0FBQyxDQUFDLElBQ2hDLGFBQWEsR0FBRyxZQUNoQixVQUFVLEdBQUc7Q0FDZixJQUFJLG9CQUFBLEdBQW1CRixhQUFBQSxPQUFBQSxDQUFPLElBQUk7Q0FDbEMsSUFBSSxNQUFBLEdBQUtFLGFBQUFBLFNBQUFBLENBQVMsSUFBSSxHQUNwQixhQUFhLEdBQUcsSUFDaEIsZ0JBQWdCLEdBQUc7Q0FDckIsSUFDRSxpQkFBQSxHQURPQSxhQUFBQSxTQUFBQSxDQUFTLElBQ0MsQ0FBQyxDQUFDOzs7O0NBSXJCLElBQUksbUJBQW1CLFNBQVUsTUFBTTtFQUNyQyxJQUFJLFVBQVUsaUJBQWlCO0VBRS9CLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxXQUFXLEdBQy9CLE9BQU8sY0FBYyxLQUFLO0VBRzVCLElBQUksUUFBUSxZQUNWLFFBQVEsWUFBWSxRQUFRLFVBQVU7RUFFeEMsS0FBSyxPQUFPLE9BQU8sQ0FBQyxDQUFDLE1BQU0sU0FBVSxLQUFLO0dBRXhDLElBQUksWUFBWSxRQUFRLFFBQVEsU0FBUyxXQUFXLEdBRWxEO0dBR0YsY0FBYyxXQUFZO0lBQ3hCLE1BQU0sSUFBSSxNQUFNLCtDQUErQyxPQUFPLEdBQUcsQ0FBQztHQUM1RSxDQUFDO0VBQ0gsQ0FBQztDQUNIO0NBQ0EsQ0FBQSxHQUFBLGFBQUEsVUFBQSxDQUFVLFdBQVk7RUFFcEIsSUFBSSxlQUFlLE9BQ2pCO0VBRUYsSUFBSSx3QkFBd0IsMkJBQTJCLGlCQUFpQixTQUFTLGVBQWUsQ0FBQztFQUVqRyxJQUFJLDBCQUEwQixLQUFBLEtBQWEsc0JBQXNCLFVBQVUsS0FBQSxHQUN6RSxPQUFPLGNBQWMsV0FBWTtHQUMvQixNQUFNLElBQUksTUFBTSxxQkFBcUI7SUFDbkMsb0JBQW9CLFlBQVk7SUFDaEMsaUJBQWlCO0lBQ2pCLHdCQUF3QixRQUFRO0lBQ2hDLGtCQUFrQixpQkFBaUIsU0FBUyxlQUFlO0dBQzdELENBQUMsQ0FBQztFQUNKLENBQUM7RUFFSCxpQkFBaUIsc0JBQXNCLE1BQU0sU0FBUyxDQUFDLEdBQUcsU0FBUyxDQUFDLENBQUM7Q0FFdkUsR0FBRyxDQUFDLFlBQVksVUFBVSxhQUFhLENBQUM7Q0FDeEMsT0FBQSxhQUFhLGNBQUEsYUFBb0IsVUFBVSxNQUFNLGFBQUEsYUFBbUIsY0FBYyxPQUFPO0VBQ3ZGLEtBQUs7RUFDTTtDQUNiLENBQUMsSUFBSSxRQUFRO0FBQ2Y7QUFDQSxZQUFZLGNBQWM7Ozs7O0FBTTFCLElBQUksaUJBQWlCLFNBQVUsSUFBSTtDQUNqQyxJQUFJLEtBQUssR0FBRyxXQUNWLFlBQVksT0FBTyxLQUFLLElBQUksS0FBSyxJQUNqQyxLQUFLLEdBQUcsZUFDUixnQkFBZ0IsT0FBTyxLQUFLLElBQUksQ0FBQyxJQUFJLElBQ3JDLGVBQWUsU0FBUyxJQUFJLENBQUMsYUFBYSxlQUFlLENBQUM7Q0FDNUQsSUFBSSxLQUFLLHVCQUF1QixDQUFDLENBQUMsSUFDaEMsYUFBYSxHQUFHLFlBQ2hCLFVBQVUsR0FBRztDQUNmLElBQUksd0JBQUEsR0FBdUJGLGFBQUFBLE9BQUFBLENBQU8sSUFBSTtDQUN0QyxJQUFJLFlBQUEsR0FBV0EsYUFBQUEsT0FBQUEsQ0FBTyxJQUFJO0NBQzFCLElBQ0UsaUJBQUEsR0FET0UsYUFBQUEsU0FBQUEsQ0FBUyxJQUNDLENBQUMsQ0FBQztDQUNyQixDQUFBLEdBQUEsYUFBQSxVQUFBLENBQVUsV0FBWTtFQUVwQixJQUFJLGVBQWUsT0FDakI7RUFFRixJQUFJLHdCQUF3QiwyQkFBMkIsaUJBQWlCLFNBQVMsZUFBZSxDQUFDO0VBRWpHLElBQUksMEJBQTBCLEtBQUEsS0FBYSxzQkFBc0IsYUFBYSxLQUFBLEdBQzVFLE9BQU8sY0FBYyxXQUFZO0dBQy9CLE1BQU0sSUFBSSxNQUFNLHFCQUFxQjtJQUNuQyxvQkFBb0IsZUFBZTtJQUNuQyxpQkFBaUI7SUFDakIsd0JBQXdCLFFBQVE7SUFDaEMsa0JBQWtCLGlCQUFpQixTQUFTLGVBQWU7R0FDN0QsQ0FBQyxDQUFDO0VBQ0osQ0FBQztFQUVILFNBQVMsVUFBVSxzQkFBc0IsU0FBUyxTQUFTLENBQUMsR0FBRyxZQUFZLENBQUM7RUFDNUUsU0FBUyxRQUFRLE9BQU8scUJBQXFCLE9BQU8sQ0FBQyxDQUFDLE1BQU0sU0FBVSxLQUFLO0dBRXpFLElBQUkscUJBQXFCLFlBQVksUUFBUSxxQkFBcUIsUUFBUSxTQUFTLFdBQVcsR0FFNUY7R0FHRixjQUFjLFdBQVk7SUFDeEIsTUFBTSxJQUFJLE1BQU0sa0RBQWtELE9BQU8sR0FBRyxDQUFDO0dBQy9FLENBQUM7RUFDSCxDQUFDO0NBRUgsR0FBRyxjQUFjLENBQUMsVUFBVSxHQUFHLGVBQWUsSUFBSSxDQUFDO0NBQ25ELE9BQUEsYUFBYSxjQUFjLE9BQU87RUFDaEMsS0FBSztFQUNNO0NBQ2IsQ0FBQztBQUNIO0FBQ0EsZUFBZSxjQUFjOzs7Ozs7O0FBUTdCLElBQUksdUJBQXVCLFNBQVUsSUFBSTtDQUN2QyxJQUFJO0NBQ0osSUFBSSxLQUFLLEdBQUcsU0FDVixVQUFVLE9BQU8sS0FBSyxJQUFJLEVBQ3hCLFVBQVUsT0FDWixJQUFJLElBQ0osV0FBVyxHQUFHLFVBQ2QsS0FBSyxHQUFHLGNBQ1IsZUFBZSxPQUFPLEtBQUssSUFBSSxRQUFRO0NBQ3pDLElBQUksTUFBQSxHQUFLQyxhQUFBQSxXQUFBQSxDQUFXLGVBQWU7RUFDL0IsU0FBUyxTQUFTLFNBQVMsQ0FBQyxHQUFHLE9BQU8sSUFBSSxLQUFLLENBQUMsR0FBRyxHQUFHLGFBQWEsdUJBQXVCLGFBQWEsb0JBQW9CLEdBQUcsYUFBYSwrQkFBK0IsYUFBYSxvQkFBb0IsR0FBRyxhQUFhLEdBQUcsT0FBTyxZQUFZLE9BQU8sQ0FBQyxHQUFHLEdBQUc7RUFDL1AsZUFBZSxlQUFlLHFCQUFxQixVQUFVLHFCQUFxQjtDQUNwRixDQUFDLEdBQ0QsUUFBUSxHQUFHLElBQ1gsV0FBVyxHQUFHO0NBQ2hCLENBQUEsR0FBQSxhQUFBLFVBQUEsQ0FBVSxXQUFZO0VBQ3BCLElBQUksaUJBQWlCLFNBQVMsTUFBTSxrQkFBa0IscUJBQXFCLFNBQ3pFLE9BQU8sU0FBUztHQUNkLE1BQU0sZ0JBQWdCO0dBQ3RCLE9BQU8scUJBQXFCO0VBQzlCLENBQUM7RUFFSCxJQUFJLE1BQU0sa0JBQWtCLHFCQUFxQixTQUMvQztFQUVGLElBQUksZUFBZTtFQUNuQixXQUFXLE1BQU0sT0FBTyxDQUFDLENBQUMsS0FBSyxXQUFZO0dBQ3pDLElBQUksY0FDRixTQUFTO0lBQ1AsTUFBTSxnQkFBZ0I7SUFDdEIsT0FBTyxxQkFBcUI7R0FDOUIsQ0FBQztFQUVMLENBQUMsQ0FBQyxDQUFDLE1BQU0sU0FBVSxLQUFLO0dBQ3RCLFFBQVEsTUFBTSxHQUFHLE9BQU8sbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLE9BQU8sR0FBRyxDQUFDO0dBQzNELElBQUksY0FDRixTQUFTO0lBQ1AsTUFBTSxnQkFBZ0I7SUFDdEIsT0FBTztLQUNMLE9BQU8scUJBQXFCO0tBQzVCLFNBQVMsT0FBTyxHQUFHO0lBQ3JCO0dBQ0YsQ0FBQztFQUVMLENBQUM7RUFDRCxPQUFPLFdBQVk7R0FDakIsZUFBZTtFQUNqQjtDQUNGLEdBQUc7RUFBQyxNQUFNO0VBQVM7RUFBYyxNQUFNO0NBQWEsQ0FBQztDQUNyRCxPQUFBLGFBQWEsY0FBYyxjQUFjLFVBQVUsRUFDakQsT0FBTyxTQUFTLFNBQVMsQ0FBQyxHQUFHLEtBQUssR0FBRyxFQUN6QixTQUNaLENBQUMsRUFDSCxHQUFHLFFBQVE7QUFDYjs7Ozs7Ozs7O0FBVUEsSUFBSSwwQkFBMEIsU0FBVSxjQUFjO0NBQ3BELElBQUksaUJBQWlCLEtBQUssR0FDeEIsZUFBZSxDQUFDO0NBRWxCLElBQUksb0JBQUEsR0FBbUJILGFBQUFBLE9BQUFBLENBQU8sWUFBWTtDQUMxQyxJQUFJLHNCQUFzQixTQUFVLFdBQVc7RUFDN0MsaUJBQWlCLFVBQVUsU0FBUyxTQUFTLENBQUMsR0FBRyxpQkFBaUIsT0FBTyxHQUFHLFNBQVM7Q0FDdkY7Q0FDQSxPQUFPLENBQUMsa0JBQWtCLG1CQUFtQjtBQUMvQzs7Ozs7Ozs7Ozs7QUFZQSxJQUFJLG1DQUFtQyxTQUFVLElBQUk7Q0FDbkQsSUFBSSxLQUFLLEdBQUcsWUFDVixhQUFhLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFFbEMsS0FBSyxHQURBLGFBQWEsaUJBRWxCLGdCQUFnQixPQUFPLEtBQUssSUFBSSwyQkFBMkI7Q0FDN0QsSUFBSSxxQkFBcUIsYUFBYSxHQUFHLE9BQU8sWUFBWSxnQkFBZ0IsSUFBSTtDQUNoRixJQUFJLGVBQWUsa0VBQWtFLE9BQU8sZUFBZSw2QkFBNkI7Q0FDeEksSUFBSSxDQUFDLFdBQVcsU0FBUyxlQUFlLEdBQ3RDLGdCQUFnQiw4SkFBOEosT0FBTyxvQkFBb0IsTUFBTTtDQUVqTixPQUFPO0FBQ1Q7Ozs7Ozs7OztBQVNBLElBQUkseUJBQXlCLFNBQVUsZUFBZTtDQUNwRCxPQUFPLENBQUMsY0FBYyxTQUFTLDJCQUEyQixlQUFlLEtBQUssQ0FBQyxjQUFjLFNBQVMsMkJBQTJCLGdCQUFnQixLQUFLLENBQUMsY0FBYyxTQUFTLDJCQUEyQixlQUFlO0FBQzFOOzs7Ozs7OztBQVFBLElBQUkscUJBQXFCLFNBQVUsZUFBZTtDQUNoRCxJQUFJLENBQUMsY0FBYyxTQUFTLDJCQUEyQixNQUFNLEtBQUssQ0FBQyxjQUFjLFNBQVMsMkJBQTJCLEdBQUcsS0FBSyx1QkFBdUIsYUFBYSxHQUMvSixNQUFNLElBQUksTUFBTSw0QkFBNEI7QUFFaEQ7Ozs7Ozs7QUFPQSxJQUFJLHNCQUFzQixTQUFVLGVBQWU7Q0FDakQsSUFBSSxjQUFjLFdBQVcsSUFBSSxJQUFJLGFBQWEsQ0FBQyxDQUFDLE1BQ2xELE1BQU0sSUFBSSxNQUFNLHNDQUFzQztBQUUxRDs7Ozs7Ozs7Ozs7QUFXQSxJQUFJLDhCQUE4QixTQUFVLGtCQUFrQjtDQUM1RCxtQkFBbUIsZ0JBQWdCO0NBQ25DLG9CQUFvQixnQkFBZ0I7QUFDdEM7Ozs7Ozs7Ozs7QUFXQSxJQUFJLDZCQUE2QixTQUFVLElBQUk7Q0FDN0MsSUFBSSxTQUFTLEdBQUcsUUFDZCxjQUFjLEdBQUcsYUFDakIsbUJBQW1CLEdBQUcsa0JBQ3RCLFdBQVcsR0FBRyxVQUNkLGVBQWUsR0FBRztDQUNwQixJQUFJLEtBQUsseUJBQXlCLENBQUMsQ0FBQyxJQUNsQyxVQUFVLEdBQUcsU0FDYixnQkFBZ0IsR0FBRztDQUNyQixJQUFJLE1BQUEsR0FBS0UsYUFBQUEsU0FBQUEsQ0FBUyxJQUFJLEdBQ3BCLGFBQWEsR0FBRyxJQUNoQixnQkFBZ0IsR0FBRztDQUNyQixJQUFJLE1BQUEsR0FBS0EsYUFBQUEsU0FBQUEsQ0FBUyxHQUNoQixhQUFhLEdBQUcsSUFDaEIsZ0JBQWdCLEdBQUc7Q0FDckIsSUFDRSxpQkFBQSxHQURPQSxhQUFBQSxTQUFBQSxDQUFTLElBQ0MsQ0FBQyxDQUFDO0NBQ3JCLElBQUksNEJBQUEsR0FBMkJGLGFBQUFBLE9BQUFBLENBQU8sSUFBSTtDQUMxQyxJQUFJLGdCQUFBLEdBQWVBLGFBQUFBLE9BQUFBLENBQU87Q0FDMUIsSUFBSSxLQUFLLHdCQUF3QixHQUMvQixtQkFBbUIsR0FBRyxJQUN0QixzQkFBc0IsR0FBRztDQUMzQixDQUFBLEdBQUEsYUFBQSxVQUFBLENBQVUsV0FBWTtFQUNwQiw0QkFBNEIsT0FBTyxLQUFLLGlCQUFpQixPQUFPLENBQUM7RUFFakUsSUFBSSxFQUFFLGtCQUFrQixxQkFBcUIsV0FDM0M7RUFHRixhQUFhLFVBQVUsMkJBQTJCLGlCQUFpQixTQUFTLGVBQWUsQ0FBQyxDQUFDLENBQUM7RUFDOUYsSUFBSSxDQUFDLGFBQWEsU0FDaEIsTUFBTSxJQUFJLE1BQU0saUNBQWlDO0dBQy9DLFlBQVksUUFBUTtHQUNwQixlQUFlLGlCQUFpQixTQUFTLGVBQWU7RUFDMUQsQ0FBQyxDQUFDO0VBRUosSUFBSSxDQUFDLGFBQWEsUUFBUSxXQUFXLEdBQ25DLE9BQU8sY0FBYyxLQUFLO0VBRzVCLElBQUksWUFDRixXQUFXLFNBQVM7RUFFdEIsYUFBYSxRQUFRLE9BQU87R0FFYjtHQUNiLFFBQVEsaUJBQWlCO0dBQ1g7R0FDTjtFQUNWLENBQUMsQ0FBQyxDQUFDLEtBQUssU0FBVSxvQkFBb0I7R0FDcEMsSUFBSSx5QkFBeUIsU0FDM0IsY0FBYyxrQkFBa0I7RUFFcEMsQ0FBQyxDQUFDLENBQUMsTUFBTSxTQUFVLEtBQUs7R0FDdEIsY0FBYyxXQUFZO0lBQ3hCLE1BQU0sSUFBSSxNQUFNLDhEQUE4RCxPQUFPLEdBQUcsQ0FBQztHQUMzRixDQUFDO0VBQ0gsQ0FBQztDQUNILEdBQUcsQ0FBQyxlQUFlLE1BQU0sQ0FBQztDQUMxQixPQUFBLGFBQWEsY0FBYyxPQUFPLEVBQ2hDLEtBQUsseUJBQ1AsR0FBRyxhQUFBLGFBQW1CLGNBQWMsMEJBQTBCLFVBQVUsRUFDdEUsT0FBTztFQUNPO0VBQ1M7Q0FDdkIsRUFDRixHQUFHLFFBQVEsSUFBSSxnQkFBZ0I7QUFDakM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQW1CQSxJQUFJLG9CQUFvQixTQUFVLElBQUk7Q0FDcEMsSUFBSSxrQkFBa0IsR0FBRyxpQkFFdkIsVUFBVSxHQUFHLFNBRWIsUUFBUSxTQUFTLElBQUksQ0FBQyxtQkFBbUIsU0FBUyxDQUFDO0NBQ3JELElBQUksc0JBQUEsR0FBcUJELGFBQUFBLFdBQUFBLENBQVcseUJBQXlCO0NBQzdELENBQUEsR0FBQSxhQUFBLFVBQUEsQ0FBVSxXQUFZO0VBQ3BCLElBQUk7RUFDSixJQUFJLEVBQUUsdUJBQXVCLFFBQVEsdUJBQXVCLEtBQUssSUFBSSxLQUFLLElBQUksbUJBQW1CLHNCQUMvRixNQUFNLElBQUksTUFBTSx1RkFBdUY7RUFHekcsbUJBQW1CLHFCQUFxQixLQUFLLENBQUMsR0FBRyxHQUFHLG1CQUFtQjtHQUNyRSxVQUFVLFFBQVE7R0FDbEIsYUFBYSxRQUFRO0dBQ3JCLE1BQU0sUUFBUTtHQUNkLGFBQWEsUUFBUTtHQUNyQixXQUFXLFFBQVE7R0FDbkIsUUFBUSxRQUFRO0dBQ2hCLFdBQVcsUUFBUTtHQUNuQixXQUFXLFFBQVE7R0FDbkIsU0FBUyxRQUFRO0dBQ2pCLHdCQUF3QixRQUFRO0VBQ2xDLEdBQUcsR0FBRztDQUNSLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsT0FBQSxhQUFhLGNBQWMsT0FBTyxTQUFTLENBQUMsR0FBRyxLQUFLLENBQUM7QUFDdkQ7Ozs7Ozs7Ozs7O0FBWUEsSUFBSSxpQ0FBaUMsU0FBVSxJQUFJO0NBQ2pELElBQUksS0FBSyxHQUFHLFlBQ1YsYUFBYSxPQUFPLEtBQUssSUFBSSxLQUFLLElBRWxDLEtBQUssR0FEQSxhQUFhLGlCQUVsQixnQkFBZ0IsT0FBTyxLQUFLLElBQUksMkJBQTJCO0NBQzdELElBQUkscUJBQXFCLGFBQWEsR0FBRyxPQUFPLFlBQVksY0FBYyxJQUFJO0NBQzlFLElBQUksZUFBZSxnRUFBZ0UsT0FBTyxlQUFlLDJCQUEyQjtDQUNwSSxJQUFJLENBQUMsV0FBVyxTQUFTLGFBQWEsR0FDcEMsZ0JBQWdCLDRKQUE0SixPQUFPLG9CQUFvQixNQUFNO0NBRS9NLE9BQU87QUFDVDtBQUNBLFNBQVMsU0FBUyxDQUVsQjtBQUNBLFNBQVMsWUFBWSxXQUFXO0NBQzlCLElBQUk7Q0FDSixPQUFPLENBQUMsR0FBRyxLQUFLLFVBQVUsYUFBYSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssSUFBSSxHQUFHLFNBQVM7QUFDdEY7QUFDQSxJQUFJLDJCQUFBLEdBQTBCRCxhQUFBQSxjQUFBQSxDQUFjO0NBQzFDLGdCQUFnQjtDQUNoQixRQUFRLENBQUM7Q0FDVCxlQUFlO0NBRWYsaUJBQWlCO0FBQ25CLENBQUM7QUFDRCxJQUFJLHNCQUFzQixXQUFZO0NBQ3BDLFFBQUEsR0FBT0MsYUFBQUEsV0FBQUEsQ0FBVyx1QkFBdUI7QUFDM0M7QUFDQSxJQUFJLDhCQUE4QixXQUFZO0NBQzVDLElBQ0UsWUFBQSxHQURPRyxhQUFBQSxTQUFBQSxDQUFTLElBQ0osQ0FBQyxDQUFDO0NBQ2hCLElBQUksb0JBQUEsR0FBbUJGLGFBQUFBLE9BQUFBLENBQU8sQ0FBQyxDQUFDO0NBQ2hDLElBQUksZ0JBQWdCLFdBQVk7RUFDOUIsSUFBSSxRQUFRLENBQUM7RUFDYixLQUFLLElBQUksS0FBSyxHQUFHLEtBQUssVUFBVSxRQUFRLE1BQ3RDLE1BQU0sTUFBTSxVQUFVO0VBRXhCLElBQUksWUFBWSxNQUFNLElBQ3BCLFVBQVUsTUFBTSxJQUNoQixhQUFhLE1BQU07RUFDckIsSUFBSSxpQkFBaUIsUUFBUSxZQUMzQixTQUFTLFdBQVk7R0FDbkIsTUFBTSxJQUFJLE1BQU0sb0NBQW9DO0VBQ3RELENBQUM7RUFFSCxpQkFBaUIsUUFBUSxhQUFhLGVBQWUsUUFBUSxlQUFlLEtBQUssSUFBSSxLQUFLLElBQUksV0FBVyxVQUFVLENBQUMsT0FBTztFQUMzSCxPQUFPLGlCQUFpQixRQUFRO0NBQ2xDO0NBQ0EsSUFBSSxrQkFBa0IsU0FBVSxXQUFXO0VBQ3pDLElBQUksUUFBUSxpQkFBaUIsUUFBUTtFQUNyQyxJQUFJLE9BQU87R0FDVCxNQUFNLE1BQU0sQ0FBQyxDQUFDLE1BQU0sTUFBTTtHQUMxQixPQUFPLGlCQUFpQixRQUFRO0VBQ2xDO0NBQ0Y7Q0FDQSxPQUFPO0VBQ0wsUUFBUSxpQkFBaUI7RUFDVjtFQUNFO0NBQ25CO0FBQ0Y7QUFDQSxJQUFJLHFCQUFxQixTQUFVLElBQUk7Q0FDckMsSUFBSSxXQUFXLEdBQUc7Q0FDbEIsT0FBQSxhQUFhLGNBQWMsT0FBTyxFQUNoQyxPQUFPLEVBQ0wsT0FBTyxPQUNULEVBQ0YsR0FBRyxRQUFRO0FBQ2I7Ozs7Ozs7Ozs7O0FBWUEsSUFBSSwyQkFBMkIsU0FBVSxJQUFJO0NBQzNDLElBQUksV0FBVyxHQUFHLFVBQ2hCLFFBQVEsU0FBUyxJQUFJLENBQUMsVUFBVSxDQUFDO0NBQ25DLElBQUksbUJBQW1CLGNBQWMsTUFBTSxXQUFXO0NBQ3RELElBQUksYUFBYSxjQUFjLEtBQUs7Q0FDcEMsSUFBSSxLQUFLLHVCQUF1QixDQUFDLENBQUMsSUFDaEMsYUFBYSxHQUFHLFlBQ2hCLFVBQVUsR0FBRztDQUNmLElBQUksS0FBSyw0QkFBNEIsR0FDbkMsU0FBUyxHQUFHLFFBQ1osZ0JBQWdCLEdBQUcsZUFDbkIsa0JBQWtCLEdBQUc7Q0FDdkIsSUFBSSxNQUFBLEdBQUtFLGFBQUFBLFNBQUFBLENBQVMsSUFBSSxHQUNwQixpQkFBaUIsR0FBRyxJQUNwQixvQkFBb0IsR0FBRztDQUN6QixJQUFJLHNCQUFBLEdBQXFCRixhQUFBQSxPQUFBQSxDQUFPLElBQUk7Q0FDcEMsSUFBSSxNQUFBLEdBQUtFLGFBQUFBLFNBQUFBLENBQVMsS0FBSyxHQUNyQixhQUFhLEdBQUcsSUFDaEIsZ0JBQWdCLEdBQUc7Q0FFckIsSUFDRSxZQUFBLEdBRE9BLGFBQUFBLFNBQUFBLENBQVMsSUFDSixDQUFDLENBQUM7Q0FDaEIsQ0FBQSxHQUFBLGFBQUEsVUFBQSxDQUFVLFdBQVk7RUFDcEIsSUFBSSxJQUFJLElBQUk7RUFDWixJQUFJLENBQUMsWUFDSDtFQUVGLElBQUksTUFBTSxhQUNSLFdBQVcsY0FBYztFQUUzQixJQUFJO0dBQ0YsbUJBQW1CLFdBQVcsTUFBTSxNQUFNLEtBQUssMkJBQTJCLGlCQUFpQixTQUFTLGVBQWUsQ0FBQyxFQUFBLENBQUcsZ0JBQWdCLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSyxJQUFJLEdBQUcsS0FBSyxJQUFJLFNBQVMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxPQUFPLFFBQVEsT0FBTyxLQUFLLElBQUksS0FBSztFQUNsUCxTQUFTLE9BQU87R0FDZCxTQUFTLFdBQVk7SUFDbkIsTUFBTSxJQUFJLE1BQU0sbUZBQW1GLE9BQU8sS0FBSyxDQUFDO0dBQ2xILENBQUM7R0FDRDtFQUNGO0VBQ0EsSUFBSSxDQUFDLG1CQUFtQixTQUFTO0dBQy9CLFNBQVMsV0FBWTtJQUNuQixNQUFNLElBQUksTUFBTSwrQkFBK0I7S0FDN0MsWUFBWSxRQUFRO0tBQ3BCLGVBQWUsaUJBQWlCLFNBQVMsZUFBZTtJQUMxRCxDQUFDLENBQUM7R0FDSixDQUFDO0dBQ0Q7RUFDRjtFQUNBLGNBQWMsbUJBQW1CLFFBQVEsV0FBVyxDQUFDO0VBQ3JELGtCQUFrQixtQkFBbUIsT0FBTztFQUM1QyxPQUFPLFdBQVk7R0FDakIsa0JBQWtCLElBQUk7R0FDdEIsbUJBQW1CLFVBQVU7RUFDL0I7Q0FDRixHQUFHLENBQUMsVUFBVSxDQUFDO0NBQ2YsSUFBSSxDQUFDLFlBRUgsT0FBQSxhQUFhLGNBQWMsT0FBTyxJQUFJO0NBRXhDLE9BQUEsYUFBYSxjQUFjLG9CQUFvQixNQUFBLGFBQVksY0FBYyx3QkFBd0IsVUFBVSxFQUN6RyxPQUFPO0VBQ1c7RUFDUjtFQUNPO0VBQ0U7Q0FDbkIsRUFDRixHQUFHLFFBQVEsQ0FBQztBQUNkO0FBQ0EsSUFBSSxrQkFBa0IsU0FBVSxJQUFJO0NBQ2xDLElBQUksWUFBWSxHQUFHLFdBQ2pCLFlBQVksR0FBRyxXQUNmLFVBQVUsU0FBUyxJQUFJLENBQUMsYUFBYSxXQUFXLENBQUM7Q0FDbkQsSUFBSSxLQUFLLG9CQUFvQixHQUMzQixpQkFBaUIsR0FBRyxnQkFDcEIsZ0JBQWdCLEdBQUcsZUFDbkIsa0JBQWtCLEdBQUc7Q0FDdkIsSUFBSSxnQkFBQSxHQUFlRixhQUFBQSxPQUFBQSxDQUFPLElBQUk7Q0FDOUIsSUFBSSxtQkFBbUIsY0FBYyxRQUFRLFdBQVc7Q0FFeEQsSUFDRSxZQUFBLEdBRE9FLGFBQUFBLFNBQUFBLENBQVMsSUFDSixDQUFDLENBQUM7Q0FDaEIsU0FBUyxpQkFBaUI7RUFDeEIsZ0JBQWdCLFNBQVM7Q0FDM0I7Q0FDQSxDQUFBLEdBQUEsYUFBQSxVQUFBLENBQVUsV0FBWTtFQUNwQixJQUFJLENBQUMsZ0JBQWdCO0dBQ25CLFNBQVMsV0FBWTtJQUNuQixNQUFNLElBQUksTUFBTSx5QkFBeUI7R0FDM0MsQ0FBQztHQUNELE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxhQUFhLFNBQ2hCLE9BQU87RUFFVCxJQUFJLFFBQVEsYUFDVixRQUFRLGNBQWM7RUFFeEIsSUFBSSxrQkFBa0IsY0FBYyxXQUFXLFNBQVMsY0FBYztFQUN0RSxvQkFBb0IsUUFBUSxvQkFBb0IsS0FBSyxLQUFhLGdCQUFnQixPQUFPLGFBQWEsT0FBTyxDQUFDLENBQUMsTUFBTSxTQUFVLEtBQUs7R0FDbEksSUFBSSxDQUFDLFlBQVksWUFBWSxHQUUzQjtHQUdGLFNBQVMsV0FBWTtJQUNuQixNQUFNLElBQUksTUFBTSwyQkFBMkIsT0FBTyxXQUFXLGlCQUFpQixDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7R0FDN0YsQ0FBQztFQUNILENBQUM7RUFDRCxPQUFPO0NBQ1QsR0FBRyxDQUFDLENBQUM7Q0FDTCxPQUFBLGFBQWEsY0FBYyxPQUFPO0VBQ2hDLEtBQUs7RUFDTTtDQUNiLENBQUM7QUFDSDtBQUNBLElBQUksa0JBQWtCLFNBQVUsU0FBUztDQUN2QyxPQUFBLGFBQWEsY0FBYyxpQkFBaUIsU0FBUyxFQUNuRCxXQUFXLFlBQ2IsR0FBRyxPQUFPLENBQUM7QUFDYjtBQUNBLElBQUksb0JBQW9CLFNBQVUsU0FBUztDQUN6QyxPQUFBLGFBQWEsY0FBYyxpQkFBaUIsU0FBUyxFQUNuRCxXQUFXLGNBQ2IsR0FBRyxPQUFPLENBQUM7QUFDYjtBQUNBLElBQUksb0JBQW9CLFNBQVUsU0FBUztDQUN6QyxPQUFBLGFBQWEsY0FBYyxpQkFBaUIsU0FBUyxFQUNuRCxXQUFXLGNBQ2IsR0FBRyxPQUFPLENBQUM7QUFDYjtBQUNBLElBQUksaUJBQWlCLFNBQVUsU0FBUztDQUN0QyxPQUFBLGFBQWEsY0FBYyxpQkFBaUIsU0FBUyxFQUNuRCxXQUFXLFdBQ2IsR0FBRyxPQUFPLENBQUM7QUFDYjtBQUNBLElBQUksZ0JBQWdCLFNBQVUsSUFBSTtDQUNoQyxJQUFJLFdBQVcsR0FBRztDQUNsQixPQUFBLGFBQWEsY0FBYyxPQUFPLEVBQ2hDLE9BQU87RUFDTCxTQUFTO0VBQ1QsT0FBTztDQUNULEVBQ0YsR0FBRyxRQUFRO0FBQ2I7Ozs7Ozs7OztBQVVBLElBQUksdUJBQXVCLFNBQVUsSUFBSTtDQUN2QyxJQUFJLFlBQVksR0FBRztDQUNuQixPQUFBLGFBQWEsY0FBYyxPQUFPLEVBQ3JCLFVBQ2IsR0FBQSxhQUFTLGNBQWMsaUJBQWlCLEVBQ3RDLFdBQVcsWUFDYixDQUFDLEdBQUEsYUFBUyxjQUFjLGlCQUFpQixFQUN2QyxXQUFXLGNBQ2IsQ0FBQyxHQUFBLGFBQVMsY0FBYyxlQUFlLE1BQUEsYUFBWSxjQUFjLG9CQUFvQixNQUFBLGFBQVksY0FBYyxpQkFBaUIsRUFDOUgsV0FBVyxjQUNiLENBQUMsQ0FBQyxHQUFBLGFBQVMsY0FBYyxvQkFBb0IsTUFBQSxhQUFZLGNBQWMsaUJBQWlCLEVBQ3RGLFdBQVcsV0FDYixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ047QUFDQSxJQUFJLFlBQVk7Q0FDZCxRQUFRO0NBQ1IsT0FBTztDQUNQLFVBQVU7Q0FDVixNQUFNO0NBQ04sUUFBUTtDQUNSLFVBQVU7Q0FDVixNQUFNO0NBQ04sT0FBTztDQUNQLE1BQU07Q0FDTixZQUFZO0NBQ1osU0FBUztDQUNULFFBQVE7Q0FDUixLQUFLO0NBQ0wsUUFBUTtDQUNSLEtBQUs7Q0FDTCxNQUFNO0NBQ04sTUFBTTtDQUNOLFNBQVM7Q0FDVCxNQUFNO0NBQ04sUUFBUTtDQUNSLGdCQUFnQjtDQUNoQixXQUFXO0NBQ1gsYUFBYTtDQUNiLFlBQVk7Q0FDWixVQUFVO0NBQ1YsT0FBTztDQUNQLFNBQVM7Q0FDVCxRQUFRO0FBQ1Y7QUFDQyxVQUFVLE9BQU8sVUFBVSxZQUFZLFVBQVUsU0FBUyxVQUFVLFFBQVEsVUFBVSxLQUFLLFVBQVUsUUFBUSxVQUFVLEtBQUssVUFBVSxNQUFNLFVBQVUsTUFBTSxVQUFVLFNBQVMsVUFBVSxNQUFNLFVBQVUsUUFBUSxVQUFVLGdCQUFnQixVQUFVLFdBQVcsVUFBVSxhQUFhLFVBQVUsWUFBWSxVQUFVLFVBQVUsVUFBVSxPQUFPLFVBQVUsUUFBUSxVQUFVO0FBTS9XLElBQUksVUFBVSIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswXX0=