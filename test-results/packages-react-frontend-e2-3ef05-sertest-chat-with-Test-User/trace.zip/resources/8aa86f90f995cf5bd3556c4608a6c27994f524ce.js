import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/paypal.tsx");import.meta.env = {"BASE_URL": "/", "DEV": true, "MODE": "development", "PROD": false, "SSR": false, "VITE_PAYPAL_CLIENT_ID": "AZ8jcfGV6r-eONmDyaTxdF9LAT3tPgNqfEhCJReOuiO96rOFRrhTzdjXvirWS7W177neKiwKEjFoZMCg", "VITE_SUPABASE_ANON_KEY": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsY3ByaXhoeWJkemtzcHlteGl4Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTAzNDg1NjYsImV4cCI6MjEwNTkyNDU2Nn0.BMYhE6hqFf8tnWQ7PryjWFJ2F2B-G8g6pBIOvCshMjo", "VITE_SUPABASE_PUBLISHABLE_KEY": "sb_publishable_RlLjZExV4WMMcOoXuYv3iw_vkCSHnFM", "VITE_SUPABASE_URL": "https://tlcprixhybdzkspymxix.supabase.co"};const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { PayPalScriptProvider, PayPalButtons } from "/node_modules/.vite/deps/@paypal_react-paypal-js.js?v=2b466928";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/paypal.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function Checkout() {
	_s();
	const [message, setMessage] = useState("");
	const initialOptions = {
		clientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
		currency: "USD",
		intent: "capture"
	};
	// Calls Express backend to create the PayPal order
	const handleCreateOrder = async () => {
		const response = await fetch(`${API_URL}/api/orders`, {
			method: "POST",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify({ cart: [{
				id: "ITEM_123",
				quantity: 1
			}] })
		});
		const orderData = await response.json();
		if (orderData.id) {
			return orderData.id;
		}
		throw new Error("Could not initiate PayPal Checkout.");
	};
	// Calls Express backend to finalize payment after buyer approves
	const handleApprove = async (data) => {
		const response = await fetch(`http://localhost:8000/api/orders/${data.orderID}/capture`, {
			method: "POST",
			headers: { "Content-Type": "application/json" }
		});
		const orderData = await response.json();
		const transaction = orderData?.purchase_units?.[0]?.payments?.captures?.[0];
		if (transaction) {
			setMessage(`Transaction ${transaction.status}: ${transaction.id}`);
		} else {
			setMessage("Payment failed or declined.");
		}
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		style: {
			maxWidth: "400px",
			margin: "2rem auto"
		},
		children: [/* @__PURE__ */ _jsxDEV(PayPalScriptProvider, {
			options: initialOptions,
			children: /* @__PURE__ */ _jsxDEV(PayPalButtons, {
				style: { layout: "vertical" },
				createOrder: handleCreateOrder,
				onApprove: handleApprove
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 64,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 63,
			columnNumber: 7
		}, this), message && /* @__PURE__ */ _jsxDEV("p", { children: message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 70,
			columnNumber: 19
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 62,
		columnNumber: 5
	}, this);
}
_s(Checkout, "EiOGSxO4GWQlH0sM782nQ9JwuAs=");
_c = Checkout;
var _c;
$RefreshReg$(_c, "Checkout");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/paypal.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/paypal.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/paypal.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/paypal.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FDRSxzQkFDQSxxQkFDSztBQUNQLFNBQVEsZUFBYzs7OztBQUV0QixlQUFlLFNBQVMsV0FBVzs7Q0FDakMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FFekMsTUFBTSxpQkFBaUI7RUFDckIsVUFBVSxZQUFZLElBQUk7RUFDMUIsVUFBVTtFQUNWLFFBQVE7Q0FDVjs7Q0FHQSxNQUFNLG9CQUFvQixZQUFZO0VBQ3BDLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLEdBQUcsUUFBUSxjQUNYO0dBQ0UsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0dBQzlDLE1BQU0sS0FBSyxVQUFVLEVBQ25CLE1BQU0sQ0FBQztJQUFFLElBQUk7SUFBWSxVQUFVO0dBQUUsQ0FBQyxFQUN4QyxDQUFDO0VBQ0gsQ0FDRjtFQUVBLE1BQU0sWUFBWSxNQUFNLFNBQVMsS0FBSztFQUN0QyxJQUFJLFVBQVUsSUFBSTtHQUNoQixPQUFPLFVBQVU7RUFDbkI7RUFDQSxNQUFNLElBQUksTUFBTSxxQ0FBcUM7Q0FDdkQ7O0NBR0EsTUFBTSxnQkFBZ0IsT0FBTyxTQUErQjtFQUMxRCxNQUFNLFdBQVcsTUFBTSxNQUNyQixvQ0FBb0MsS0FBSyxRQUFRLFdBQ2pEO0dBQ0UsUUFBUTtHQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0VBQ2hELENBQ0Y7RUFFQSxNQUFNLFlBQVksTUFBTSxTQUFTLEtBQUs7RUFDdEMsTUFBTSxjQUNKLFdBQVcsaUJBQWlCLEVBQUUsRUFBRSxVQUFVLFdBQVc7RUFFdkQsSUFBSSxhQUFhO0dBQ2YsV0FDRSxlQUFlLFlBQVksT0FBTyxJQUFJLFlBQVksSUFDcEQ7RUFFRixPQUFPO0dBQ0wsV0FBVyw2QkFBNkI7RUFDMUM7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLE9BQU87R0FBRSxVQUFVO0dBQVMsUUFBUTtFQUFZO1lBQXJELENBQ0Usd0JBQUMsc0JBQUQ7R0FBc0IsU0FBUzthQUM3Qix3QkFBQyxlQUFEO0lBQ0UsT0FBTyxFQUFFLFFBQVEsV0FBVztJQUM1QixhQUFhO0lBQ2IsV0FBVztHQUNaOzs7OztFQUNtQjs7OztZQUNyQixXQUFXLHdCQUFDLEtBQUQsWUFBSSxRQUFXOzs7O1VBQ3hCOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJwYXlwYWwudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgUGF5UGFsU2NyaXB0UHJvdmlkZXIsXHJcbiAgUGF5UGFsQnV0dG9uc1xyXG59IGZyb20gXCJAcGF5cGFsL3JlYWN0LXBheXBhbC1qc1wiO1xyXG5pbXBvcnQge0FQSV9VUkx9IGZyb20gXCIuL2NvbnN0YW50c1wiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2hlY2tvdXQoKSB7XHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IGluaXRpYWxPcHRpb25zID0ge1xyXG4gICAgY2xpZW50SWQ6IGltcG9ydC5tZXRhLmVudi5WSVRFX1BBWVBBTF9DTElFTlRfSUQsXHJcbiAgICBjdXJyZW5jeTogXCJVU0RcIixcclxuICAgIGludGVudDogXCJjYXB0dXJlXCJcclxuICB9O1xyXG5cclxuICAvLyBDYWxscyBFeHByZXNzIGJhY2tlbmQgdG8gY3JlYXRlIHRoZSBQYXlQYWwgb3JkZXJcclxuICBjb25zdCBoYW5kbGVDcmVhdGVPcmRlciA9IGFzeW5jICgpID0+IHtcclxuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgIGAke0FQSV9VUkx9L2FwaS9vcmRlcnNgLFxyXG4gICAgICB7XHJcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICBoZWFkZXJzOiB7IFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgY2FydDogW3sgaWQ6IFwiSVRFTV8xMjNcIiwgcXVhbnRpdHk6IDEgfV1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGNvbnN0IG9yZGVyRGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcclxuICAgIGlmIChvcmRlckRhdGEuaWQpIHtcclxuICAgICAgcmV0dXJuIG9yZGVyRGF0YS5pZDtcclxuICAgIH1cclxuICAgIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBpbml0aWF0ZSBQYXlQYWwgQ2hlY2tvdXQuXCIpO1xyXG4gIH07XHJcblxyXG4gIC8vIENhbGxzIEV4cHJlc3MgYmFja2VuZCB0byBmaW5hbGl6ZSBwYXltZW50IGFmdGVyIGJ1eWVyIGFwcHJvdmVzXHJcbiAgY29uc3QgaGFuZGxlQXBwcm92ZSA9IGFzeW5jIChkYXRhOiB7IG9yZGVySUQ6IHVua25vd24gfSkgPT4ge1xyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgYGh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hcGkvb3JkZXJzLyR7ZGF0YS5vcmRlcklEfS9jYXB0dXJlYCxcclxuICAgICAge1xyXG4gICAgICAgIG1ldGhvZDogXCJQT1NUXCIsXHJcbiAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgY29uc3Qgb3JkZXJEYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xyXG4gICAgY29uc3QgdHJhbnNhY3Rpb24gPVxyXG4gICAgICBvcmRlckRhdGE/LnB1cmNoYXNlX3VuaXRzPy5bMF0/LnBheW1lbnRzPy5jYXB0dXJlcz8uWzBdO1xyXG5cclxuICAgIGlmICh0cmFuc2FjdGlvbikge1xyXG4gICAgICBzZXRNZXNzYWdlKFxyXG4gICAgICAgIGBUcmFuc2FjdGlvbiAke3RyYW5zYWN0aW9uLnN0YXR1c306ICR7dHJhbnNhY3Rpb24uaWR9YFxyXG4gICAgICApO1xyXG4gICAgICAvLyBVcGRhdGUgeW91ciBkYXRhYmFzZSBvciByZWRpcmVjdCB0byBhIHN1Y2Nlc3MgcGFnZSBoZXJlXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBzZXRNZXNzYWdlKFwiUGF5bWVudCBmYWlsZWQgb3IgZGVjbGluZWQuXCIpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IHN0eWxlPXt7IG1heFdpZHRoOiBcIjQwMHB4XCIsIG1hcmdpbjogXCIycmVtIGF1dG9cIiB9fT5cclxuICAgICAgPFBheVBhbFNjcmlwdFByb3ZpZGVyIG9wdGlvbnM9e2luaXRpYWxPcHRpb25zfT5cclxuICAgICAgICA8UGF5UGFsQnV0dG9uc1xyXG4gICAgICAgICAgc3R5bGU9e3sgbGF5b3V0OiBcInZlcnRpY2FsXCIgfX1cclxuICAgICAgICAgIGNyZWF0ZU9yZGVyPXtoYW5kbGVDcmVhdGVPcmRlcn1cclxuICAgICAgICAgIG9uQXBwcm92ZT17aGFuZGxlQXBwcm92ZX1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1BheVBhbFNjcmlwdFByb3ZpZGVyPlxyXG4gICAgICB7bWVzc2FnZSAmJiA8cD57bWVzc2FnZX08L3A+fVxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufVxyXG4iXX0=