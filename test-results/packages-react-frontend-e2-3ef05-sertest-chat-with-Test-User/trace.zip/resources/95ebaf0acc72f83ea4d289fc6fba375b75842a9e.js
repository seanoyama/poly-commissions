import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/services/dateConverter.tsx");//function that converts time from ISO 8601 format to a more readable format
export function ReadableDate(props) {
	const date = new Date(props.iso_string);
	return new Intl.DateTimeFormat().format(date);
}
_c = ReadableDate;
var _c;
$RefreshReg$(_c, "ReadableDate");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/services/dateConverter.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/dateConverter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/dateConverter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/dateConverter.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IjtBQUVBLE9BQU8sU0FBUyxhQUFhLE9BQVc7Q0FDcEMsTUFBTSxPQUFPLElBQUksS0FBSyxNQUFNLFVBQVU7Q0FFdEMsT0FBTyxJQUFJLEtBQUssZUFBZSxDQUFDLENBQUMsT0FBTyxJQUFJO0FBR2hEIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbImRhdGVDb252ZXJ0ZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG4vL2Z1bmN0aW9uIHRoYXQgY29udmVydHMgdGltZSBmcm9tIElTTyA4NjAxIGZvcm1hdCB0byBhIG1vcmUgcmVhZGFibGUgZm9ybWF0XHJcbmV4cG9ydCBmdW5jdGlvbiBSZWFkYWJsZURhdGUocHJvcHM6IGFueSl7XHJcbiAgICBjb25zdCBkYXRlID0gbmV3IERhdGUocHJvcHMuaXNvX3N0cmluZyk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KCkuZm9ybWF0KGRhdGUpO1xyXG5cclxuXHJcbn0iXX0=