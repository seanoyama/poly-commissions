import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ChatForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatForm.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
const url = `${API_URL}/chats`;
export default function ChatForm({ user_one, user_two, post_id, onChatCreate }) {
	_s();
	const [error, setError] = useState("");
	const [isSubmitting, setIsSubmitting] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		if (!user_one || !user_two || !post_id) {
			setError("User one, User two, or post id does not exist.");
			return;
		}
		const chat = {
			user_one,
			user_two,
			post_id
		};
		setIsSubmitting(true);
		try {
			const response = await fetch(url, {
				method: "POST",
				headers: { "Content-Type": "application/json" },
				body: JSON.stringify(chat)
			});
			if (!response.ok) {
				const details = await response.text();
				throw new Error(details || "Unable to create chat.");
			}
			onChatCreate();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to send message.");
		} finally {
			setIsSubmitting(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		onSubmit: handleSubmit,
		children: [
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error-message",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 19
			}, this),
			/* @__PURE__ */ _jsxDEV("label", { children: "Create Chat: " }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("button", {
				type: "submit",
				disabled: isSubmitting || !user_one || !user_two || !post_id,
				children: isSubmitting ? "Creating..." : "Create"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 9
	}, this);
}
_s(ChatForm, "plqUL4XulY+s8ZBrJl5RCthQ7eQ=");
_c = ChatForm;
var _c;
$RefreshReg$(_c, "ChatForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ChatForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7QUFDekMsU0FBUSxlQUFjOzs7O0FBa0J0QixNQUFNLE1BQU0sR0FBRyxRQUFRO0FBRXZCLGVBQWUsU0FBUyxTQUFTLEVBQy9CLFVBQ0EsVUFDQSxTQUNBLGdCQUNnQjs7Q0FFZCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxLQUFLO0NBRXRELGVBQWUsYUFBYSxPQUFtQztFQUMzRCxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBRVgsSUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsU0FBUztHQUN4QyxTQUFTLGdEQUFnRDtHQUN6RDtFQUNBO0VBRUEsTUFBTSxPQUFnQjtHQUFFO0dBQVU7R0FBVTtFQUFPO0VBRW5ELGdCQUFnQixJQUFJO0VBQ3BCLElBQUk7R0FDSixNQUFNLFdBQVcsTUFBTSxNQUFNLEtBQUs7SUFDOUIsUUFBUTtJQUNSLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0lBQzlDLE1BQU0sS0FBSyxVQUFVLElBQUk7R0FDN0IsQ0FBQztHQUVELElBQUksQ0FBQyxTQUFTLElBQUk7SUFDZCxNQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUs7SUFDcEMsTUFBTSxJQUFJLE1BQU0sV0FBVyx3QkFBd0I7R0FDdkQ7R0FHQSxhQUFhO0VBQ2IsU0FBUyxLQUFLO0dBQ2QsU0FBUyxlQUFlLFFBQVEsSUFBSSxVQUFVLHlCQUF5QjtFQUN2RSxVQUFVO0dBQ1YsZ0JBQWdCLEtBQUs7RUFDckI7Q0FFSjtDQUVBLE9BQ0ksd0JBQUMsUUFBRDtFQUFNLFVBQVU7WUFBaEI7R0FDQyxTQUFTLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO2NBQWlCO0dBQVM7Ozs7O0dBQ2pELHdCQUFDLFNBQUQsWUFBTyxnQkFBb0I7Ozs7O0dBQzNCLHdCQUFDLFVBQUQ7SUFBUSxNQUFLO0lBQVMsVUFBVSxnQkFBZ0IsQ0FBQyxZQUFZLENBQUMsWUFBWSxDQUFDO2NBQ3RFLGVBQWUsZ0JBQWdCO0dBQzVCOzs7OztFQUNGOzs7Ozs7QUFFZCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDaGF0Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7QVBJX1VSTH0gZnJvbSBcIi4vY29uc3RhbnRzXCI7XHJcbnR5cGUgQ2hhdCA9IHtcclxuICBpZDogc3RyaW5nO1xyXG4gIHVzZXJfb25lOiBzdHJpbmc7XHJcbiAgdXNlcl90d286IHN0cmluZztcclxuICBwb3N0X2lkOiBzdHJpbmc7XHJcbiAgY3JlYXRlZF9hdDogc3RyaW5nO1xyXG59O1xyXG5cclxudHlwZSBOZXdDaGF0ID0gUGljazxDaGF0LCBcInVzZXJfb25lXCIgfCBcInVzZXJfdHdvXCIgfCBcInBvc3RfaWRcIj47XHJcblxyXG50eXBlIENoYXRGb3JtUHJvcHMgPSB7XHJcbiAgdXNlcl9vbmU/OiBzdHJpbmc7XHJcbiAgdXNlcl90d28/OiBzdHJpbmc7XHJcbiAgcG9zdF9pZD86IHN0cmluZztcclxuICBvbkNoYXRDcmVhdGU6ICgpID0+IHZvaWQ7XHJcbn07XHJcblxyXG5jb25zdCB1cmwgPSBgJHtBUElfVVJMfS9jaGF0c2A7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBDaGF0Rm9ybSh7XHJcbiAgdXNlcl9vbmUsXHJcbiAgdXNlcl90d28sXHJcbiAgcG9zdF9pZCxcclxuICBvbkNoYXRDcmVhdGVcclxufTogQ2hhdEZvcm1Qcm9wcykge1xyXG5cclxuICAgIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgICBjb25zdCBbaXNTdWJtaXR0aW5nLCBzZXRJc1N1Ym1pdHRpbmddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xyXG4gICAgICAgIHNldEVycm9yKFwiXCIpO1xyXG5cclxuICAgICAgICBpZiAoIXVzZXJfb25lIHx8ICF1c2VyX3R3byB8fCAhcG9zdF9pZCkgeyAvLyB0aGlzIGNhc2Ugc2hvdWxkIGJlIGltcG9zc2libGUgc2luY2Ugc29tZW9uZSBub3QgbG9nZ2VkIGluIHdvdWxkbid0IHNlZSB0aGUgbWVzc2FnZSBmb3JtIEkgdGhpbmtcclxuICAgICAgICBzZXRFcnJvcihcIlVzZXIgb25lLCBVc2VyIHR3bywgb3IgcG9zdCBpZCBkb2VzIG5vdCBleGlzdC5cIik7XHJcbiAgICAgICAgcmV0dXJuO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgY2hhdDogTmV3Q2hhdCA9IHsgdXNlcl9vbmUsIHVzZXJfdHdvLCBwb3N0X2lkfTtcclxuXHJcbiAgICAgICAgc2V0SXNTdWJtaXR0aW5nKHRydWUpO1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcclxuICAgICAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcclxuICAgICAgICAgICAgaGVhZGVyczogeyBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL2pzb25cIiB9LFxyXG4gICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeShjaGF0KVxyXG4gICAgICAgIH0pO1xyXG5cclxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgICAgIGNvbnN0IGRldGFpbHMgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihkZXRhaWxzIHx8IFwiVW5hYmxlIHRvIGNyZWF0ZSBjaGF0LlwiKTtcclxuICAgICAgICB9XHJcblxyXG5cclxuICAgICAgICBvbkNoYXRDcmVhdGUoKTtcclxuICAgICAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogXCJVbmFibGUgdG8gc2VuZCBtZXNzYWdlLlwiKTtcclxuICAgICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIHNldElzU3VibWl0dGluZyhmYWxzZSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2VcIj57ZXJyb3J9PC9wPn1cclxuICAgICAgICA8bGFiZWw+Q3JlYXRlIENoYXQ6IDwvbGFiZWw+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZyB8fCAhdXNlcl9vbmUgfHwgIXVzZXJfdHdvIHx8ICFwb3N0X2lkfT5cclxuICAgICAgICAgICAge2lzU3VibWl0dGluZyA/IFwiQ3JlYXRpbmcuLi5cIiA6IFwiQ3JlYXRlXCJ9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgKTtcclxufSJdfQ==