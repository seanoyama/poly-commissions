import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/services/userData.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"]; const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import "/src/App.css";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=2b466928";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/userData.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export function UserName(props) {
	_s();
	const uuid = props.uuid;
	// make urls by concatenating with user id
	const url = "http://localhost:8000/users/" + uuid;
	const [user, getUser] = useState();
	useEffect(() => {
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load user");
			}
			return response.json();
		}).then((data) => {
			getUser(data);
		}).catch((err) => {
			console.log(err);
		});
	}, [uuid]);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: user?.name }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 36,
		columnNumber: 10
	}, this);
}
_s(UserName, "dJzxhEh3g31EDdXisjyX9TmYqNQ=");
_c = UserName;
var _c;
$RefreshReg$(_c, "UserName");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/services/userData.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/userData.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/userData.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/services/userData.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTztBQUNQLFNBQVMsV0FBVyxnQkFBZ0I7Ozs7QUFZcEMsT0FBTyxTQUFTLFNBQVMsT0FBVzs7Q0FDaEMsTUFBTSxPQUFPLE1BQU07O0NBR3JCLE1BQU0sTUFBTSxpQ0FBZ0M7Q0FDNUMsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFlO0NBQ3ZDLGdCQUFnQjtFQUNaLE1BQU0sR0FBRyxDQUFDLENBQ1AsTUFBTSxhQUFhO0dBQ2xCLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQU0scUJBQXFCO0dBQ3ZDO0dBQ0EsT0FBTyxTQUFTLEtBQUs7RUFDdkIsQ0FBQyxDQUFDLENBQ0QsTUFBTSxTQUFTO0dBQ2QsUUFBUSxJQUFJO0VBQ2QsQ0FBQyxDQUFDLENBQ0QsT0FBTyxRQUFlO0dBQ3JCLFFBQVEsSUFBSSxHQUFHO0VBQ2pCLENBQUM7Q0FDTCxHQUFHLENBQUMsSUFBSSxDQUFDO0NBRVgsT0FBTywrQ0FDTixNQUFNLEtBQ0w7Ozs7O0FBRUoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsidXNlckRhdGEudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uL0FwcC5jc3NcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxudHlwZSBVc2VyID0ge1xyXG4gICAgaWQ6IHN0cmluZztcclxuICAgIG5hbWU6IHN0cmluZztcclxuICAgIGVtYWlsOiBzdHJpbmc7XHJcbiAgICBwaG9uZTogc3RyaW5nO1xyXG4gICAgb25fY2FtcHVzOiBib29sZWFuO1xyXG4gICAgY3JlYXRlZF9hdDogc3RyaW5nO1xyXG4gIH1cclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gVXNlck5hbWUocHJvcHM6IGFueSl7XHJcbiAgICBjb25zdCB1dWlkID0gcHJvcHMudXVpZDtcclxuXHJcbiAgLy8gbWFrZSB1cmxzIGJ5IGNvbmNhdGVuYXRpbmcgd2l0aCB1c2VyIGlkXHJcbiAgY29uc3QgdXJsID0gXCJodHRwOi8vbG9jYWxob3N0OjgwMDAvdXNlcnMvXCIrKHV1aWQpO1xyXG4gIGNvbnN0IFt1c2VyLCBnZXRVc2VyXSA9IHVzZVN0YXRlPFVzZXI+KCk7XHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgZmV0Y2godXJsKVxyXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZCBub3QgbG9hZCB1c2VyXCIpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKSBhcyBQcm9taXNlPFVzZXI+O1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgLnRoZW4oKGRhdGEpID0+IHtcclxuICAgICAgICAgIGdldFVzZXIoZGF0YSk7XHJcbiAgICAgICAgfSlcclxuICAgICAgICAuY2F0Y2goKGVycjogRXJyb3IpID0+IHtcclxuICAgICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9LCBbdXVpZF0pO1xyXG5cclxuICByZXR1cm4gPD5cclxuICB7dXNlcj8ubmFtZX1cclxuICA8Lz5cclxuXHJcbn0iXX0=