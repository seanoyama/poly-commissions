import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routesFE.tsx");const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"];import LoginPage from "/src/pages/LoginPage.tsx";
import SignupPage from "/src/pages/SignupPage.tsx";
import MessagesPage from "/src/pages/MessagesPage.tsx";
import PostsPage from "/src/pages/PostsPage.tsx";
import ProfilePage from "/src/pages/ProfilePage.tsx";
import ChatsPage from "/src/pages/ChatsPage.tsx";
import PostInfoPage from "/src/pages/PostInfoPage.tsx";
import { Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=2b466928";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/routesFE.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
export default function RoutesFE() {
	return /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/messages",
			element: /* @__PURE__ */ _jsxDEV(ChatsPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 40
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/messages/:chat_id",
			element: /* @__PURE__ */ _jsxDEV(MessagesPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 15,
				columnNumber: 49
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 16,
				columnNumber: 37
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 16,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/posts",
			element: /* @__PURE__ */ _jsxDEV(PostsPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 17,
				columnNumber: 37
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/posts/:uuid",
			element: /* @__PURE__ */ _jsxDEV(PostInfoPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/users/:uuid",
			element: /* @__PURE__ */ _jsxDEV(ProfilePage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/signup",
			element: /* @__PURE__ */ _jsxDEV(SignupPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 38
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 20,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 5
	}, this);
}
_c = RoutesFE;
var _c;
$RefreshReg$(_c, "RoutesFE");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routesFE.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/routesFE.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/routesFE.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/routesFE.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sZ0JBQWdCO0FBQ3ZCLE9BQU8sa0JBQWtCO0FBQ3pCLE9BQU8sZUFBZTtBQUN0QixPQUFPLGlCQUFpQjtBQUN4QixPQUFPLGVBQWU7QUFDdEIsT0FBTyxrQkFBa0I7QUFDekIsU0FBUyxRQUFRLGFBQWE7OztBQUU5QixlQUFlLFNBQVMsV0FBVztDQUVqQyxPQUNFLHdCQUFDLFFBQUQ7RUFDRSx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFZLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztFQUFJOzs7OztFQUNqRCx3QkFBQyxPQUFEO0dBQU8sTUFBSztHQUFxQixTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7RUFBSTs7Ozs7RUFDN0Qsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBUyxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7RUFBSTs7Ozs7RUFDOUMsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBUyxTQUFTLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7RUFBSTs7Ozs7RUFDOUMsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBZSxTQUFTLHdCQUFDLGNBQUQsQ0FBZTs7Ozs7RUFBSTs7Ozs7RUFDdkQsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBZSxTQUFTLHdCQUFDLGFBQUQsQ0FBYzs7Ozs7RUFBSTs7Ozs7RUFDdEQsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBVSxTQUFTLHdCQUFDLFlBQUQsQ0FBYTs7Ozs7RUFBSTs7Ozs7Q0FDMUM7Ozs7O0FBRVoiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsicm91dGVzRkUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBMb2dpblBhZ2UgZnJvbSBcIi4vcGFnZXMvTG9naW5QYWdlXCI7XHJcbmltcG9ydCBTaWdudXBQYWdlIGZyb20gXCIuL3BhZ2VzL1NpZ251cFBhZ2VcIjtcclxuaW1wb3J0IE1lc3NhZ2VzUGFnZSBmcm9tIFwiLi9wYWdlcy9NZXNzYWdlc1BhZ2VcIjtcclxuaW1wb3J0IFBvc3RzUGFnZSBmcm9tIFwiLi9wYWdlcy9Qb3N0c1BhZ2VcIjtcclxuaW1wb3J0IFByb2ZpbGVQYWdlIGZyb20gXCIuL3BhZ2VzL1Byb2ZpbGVQYWdlXCI7XHJcbmltcG9ydCBDaGF0c1BhZ2UgZnJvbSBcIi4vcGFnZXMvQ2hhdHNQYWdlXCI7XHJcbmltcG9ydCBQb3N0SW5mb1BhZ2UgZnJvbSBcIi4vcGFnZXMvUG9zdEluZm9QYWdlXCI7XHJcbmltcG9ydCB7IFJvdXRlcywgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm91dGVzRkUoKSB7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Um91dGVzPlxyXG4gICAgICA8Um91dGUgcGF0aD1cIi9tZXNzYWdlc1wiIGVsZW1lbnQ9ezxDaGF0c1BhZ2UgLz59IC8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiL21lc3NhZ2VzLzpjaGF0X2lkXCIgZWxlbWVudD17PE1lc3NhZ2VzUGFnZSAvPn0gLz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvbG9naW5cIiBlbGVtZW50PXs8TG9naW5QYWdlIC8+fSAvPlxyXG4gICAgICA8Um91dGUgcGF0aD1cIi9wb3N0c1wiIGVsZW1lbnQ9ezxQb3N0c1BhZ2UgLz59IC8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3Bvc3RzLzp1dWlkXCIgZWxlbWVudD17PFBvc3RJbmZvUGFnZSAvPn0gLz5cclxuICAgICAgPFJvdXRlIHBhdGg9XCIvdXNlcnMvOnV1aWRcIiBlbGVtZW50PXs8UHJvZmlsZVBhZ2UgLz59IC8+XHJcbiAgICAgIDxSb3V0ZSBwYXRoPVwiL3NpZ251cFwiIGVsZW1lbnQ9ezxTaWdudXBQYWdlIC8+fSAvPlxyXG4gICAgPC9Sb3V0ZXM+XHJcbiAgKTtcclxufVxyXG4iXX0=