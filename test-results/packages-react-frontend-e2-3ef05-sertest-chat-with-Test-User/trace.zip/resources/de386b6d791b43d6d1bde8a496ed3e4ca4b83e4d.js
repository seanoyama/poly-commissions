import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/singlePost.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { UserName } from "/src/services/userData.tsx";
import ChatForm from "/src/ChatForm.tsx";
import { useAuth } from "/src/SessionContext.tsx";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/singlePost.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function SinglePost(props) {
	_s();
	const id = props.id.uuid;
	const [refreshKey, setRefreshKey] = useState(0);
	const { user } = useAuth();
	// make urls by concatenating with post id
	const url = `${API_URL}/posts/${id}`;
	console.log(url);
	const [post, getPost] = useState();
	useEffect(() => {
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load post");
			}
			return response.json();
		}).then((data) => {
			getPost(data);
		}).catch((err) => {
			console.log(err);
		});
	}, [refreshKey]);
	console.log(post?.images[0]);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("h1", { children: ["Post: ", post?.title] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: post?.category }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 51,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("img", { src: post?.images[0] }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", { children: ["Price: ", post?.price] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", { children: [
			"Create new chat with ",
			/* @__PURE__ */ _jsxDEV(UserName, { uuid: post?.user_id }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 31
			}, this),
			":"
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 54,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(ChatForm, {
			user_one: post?.user_id,
			user_two: user?.id,
			post_id: post?.id,
			onChatCreate: () => setRefreshKey((key) => key + 1)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 55,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 49,
		columnNumber: 5
	}, this);
}
_s(SinglePost, "+rZgKH7gX2kIyh6AWprTqE3+ZC0=", false, function() {
	return [useAuth];
});
_c = SinglePost;
var _c;
$RefreshReg$(_c, "SinglePost");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/singlePost.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/singlePost.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/singlePost.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/singlePost.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFlO0FBQ25DLFNBQVEsZ0JBQWU7QUFDdkIsT0FBTyxjQUFjO0FBRXJCLFNBQVEsZUFBYztBQUN0QixTQUFRLGVBQWM7Ozs7QUFhdEIsZUFBZSxTQUFTLFdBQVcsT0FBVzs7Q0FDMUMsTUFBTSxLQUFLLE1BQU0sR0FBRztDQUNwQixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxDQUFDO0NBRTlDLE1BQU0sRUFBQyxTQUFRLFFBQVE7O0NBSXpCLE1BQU0sTUFBTSxHQUFHLFFBQVEsU0FBUztDQUNoQyxRQUFRLElBQUksR0FBRztDQUNmLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBZTtDQUN2QyxnQkFBZ0I7RUFDZCxNQUFNLEdBQUcsQ0FBQyxDQUNQLE1BQU0sYUFBYTtHQUNsQixJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLHFCQUFxQjtHQUN2QztHQUVBLE9BQU8sU0FBUyxLQUFLO0VBQ3ZCLENBQUMsQ0FBQyxDQUNELE1BQU0sU0FBUztHQUNkLFFBQVEsSUFBSTtFQUNkLENBQUMsQ0FBQyxDQUNELE9BQU8sUUFBZTtHQUNyQixRQUFRLElBQUksR0FBRztFQUNqQixDQUFDO0NBQ0wsR0FBRyxDQUFDLFVBQVUsQ0FBQztDQUNmLFFBQVEsSUFBSSxNQUFNLE9BQU8sRUFBRTtDQUMzQixPQUVFO0VBQ0Usd0JBQUMsTUFBRCxhQUFJLFVBQU8sTUFBTSxLQUFVOzs7OztFQUMzQix3QkFBQyxNQUFELFlBQUssTUFBTSxTQUFhOzs7OztFQUN4Qix3QkFBQyxPQUFELEVBQUssS0FBSyxNQUFNLE9BQU8sR0FBUzs7Ozs7RUFDaEMsd0JBQUMsS0FBRCxhQUFHLFdBQVEsTUFBTSxLQUFTOzs7OztFQUMxQix3QkFBQyxLQUFEO0dBQUc7R0FBcUIsd0JBQUMsVUFBRCxFQUFVLE1BQU8sTUFBTSxRQUFXOzs7OztHQUFDO0VBQUk7Ozs7O0VBQy9ELHdCQUFDLFVBQUQ7R0FBVSxVQUFVLE1BQU07R0FBUyxVQUFVLE1BQU07R0FBSSxTQUFTLE1BQU07R0FBSSxvQkFBb0IsZUFBZSxRQUFRLE1BQU0sQ0FBQztFQUFHOzs7OztDQUM3SDs7Ozs7QUFFUiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJzaW5nbGVQb3N0LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtVc2VyTmFtZX0gZnJvbSBcIi4vc2VydmljZXMvdXNlckRhdGFcIjtcclxuaW1wb3J0IENoYXRGb3JtIGZyb20gXCIuL0NoYXRGb3JtXCI7XHJcblxyXG5pbXBvcnQge3VzZUF1dGh9IGZyb20gXCIuL1Nlc3Npb25Db250ZXh0XCI7XHJcbmltcG9ydCB7QVBJX1VSTH0gZnJvbSBcIi4vY29uc3RhbnRzXCJcclxuXHJcbi8vIGNvbnNpZGVyIGhhdmluZyBhIHNjcmlwdCB0aGF0IGp1c3QgaGFzIGEgYnVuY2ggb2YgdHlwZXMgd2UgdXNlXHJcbnR5cGUgUG9zdCA9IHtcclxuICAgICAgICBpZDogc3RyaW5nO1xyXG4gICAgICAgIHVzZXJfaWQ6IHN0cmluZztcclxuICAgICAgICB0aXRsZTogc3RyaW5nO1xyXG4gICAgICAgIHByaWNlOiBudW1iZXI7XHJcbiAgICAgICAgY2F0ZWdvcnk6IHN0cmluZztcclxuICAgICAgICBsb2NhdGlvbjogc3RyaW5nO1xyXG4gICAgICAgIGltYWdlczogc3RyaW5nO1xyXG4gICAgfTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFNpbmdsZVBvc3QocHJvcHM6YW55KSB7XHJcbiAgICBjb25zdCBpZCA9IHByb3BzLmlkLnV1aWQ7XHJcbiAgICBjb25zdCBbcmVmcmVzaEtleSwgc2V0UmVmcmVzaEtleV0gPSB1c2VTdGF0ZSgwKTtcclxuXHJcbiAgICBjb25zdCB7dXNlcn0gPSB1c2VBdXRoKCk7XHJcblxyXG4gICAgXHJcbiAgLy8gbWFrZSB1cmxzIGJ5IGNvbmNhdGVuYXRpbmcgd2l0aCBwb3N0IGlkXHJcbiAgY29uc3QgdXJsID0gYCR7QVBJX1VSTH0vcG9zdHMvJHtpZH1gO1xyXG4gIGNvbnNvbGUubG9nKHVybCk7XHJcbiAgY29uc3QgW3Bvc3QsIGdldFBvc3RdID0gdXNlU3RhdGU8UG9zdD4oKTtcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgZmV0Y2godXJsKVxyXG4gICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcclxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJDb3VsZCBub3QgbG9hZCBwb3N0XCIpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKSBhcyBQcm9taXNlPFBvc3Q+O1xyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgIGdldFBvc3QoZGF0YSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5jYXRjaCgoZXJyOiBFcnJvcikgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKGVycik7XHJcbiAgICAgIH0pO1xyXG4gIH0sIFtyZWZyZXNoS2V5XSk7XHJcbiAgY29uc29sZS5sb2cocG9zdD8uaW1hZ2VzWzBdKTtcclxuICByZXR1cm4gKFxyXG4gICAgXHJcbiAgICA8PlxyXG4gICAgICA8aDE+UG9zdDoge3Bvc3Q/LnRpdGxlfTwvaDE+XHJcbiAgICAgIDxoMj57cG9zdD8uY2F0ZWdvcnl9PC9oMj5cclxuICAgICAgPGltZyBzcmM9e3Bvc3Q/LmltYWdlc1swXX0+PC9pbWc+XHJcbiAgICAgIDxwPlByaWNlOiB7cG9zdD8ucHJpY2V9PC9wPlxyXG4gICAgICA8cD5DcmVhdGUgbmV3IGNoYXQgd2l0aCA8VXNlck5hbWUgdXVpZD17KHBvc3Q/LnVzZXJfaWQpfSAvPjo8L3A+XHJcbiAgICAgIDxDaGF0Rm9ybSB1c2VyX29uZT17cG9zdD8udXNlcl9pZH0gdXNlcl90d289e3VzZXI/LmlkfSBwb3N0X2lkPXtwb3N0Py5pZH0gb25DaGF0Q3JlYXRlPXsoKSA9PiBzZXRSZWZyZXNoS2V5KChrZXkpID0+IGtleSArIDEpfS8+XHJcbiAgICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl19