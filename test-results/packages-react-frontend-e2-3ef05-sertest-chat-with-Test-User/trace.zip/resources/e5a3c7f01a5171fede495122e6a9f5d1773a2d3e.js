import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/profile.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport4_react_jsxDevRuntime["Fragment"];import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=2b466928";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import PostsList from "/src/PostsList.tsx";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/profile.tsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function Profile() {
	_s();
	const { uuid } = useParams();
	// make urls by concatenating with user id
	const url = `${API_URL}/users/${uuid}`;
	// const postsUrl =
	// "http://localhost:8000/posts?user_id=" + uuid;
	const [user, getUser] = useState();
	useEffect(() => {
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load user");
			}
			return response.json();
		}).then((data) => {
			getUser(data);
		}).catch((err) => {
			console.log(err);
		});
	}, []);
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		/* @__PURE__ */ _jsxDEV("h1", { children: "Profile" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: ["Name: ", user?.name] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 42,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: ["Contact: ", user?.email] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 43,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("p", { children: [
			"hello I am ",
			user?.name,
			" and this is my amazing bio!"
		] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 44,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 45,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("h2", { children: [user?.name, "'s Posts"] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 46,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV(PostsList, { user_id: uuid }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 47,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 40,
		columnNumber: 5
	}, this);
}
_s(Profile, "Cblqgk968XqNmXUq8IdHpSUc0vA=", false, function() {
	return [useParams];
});
_c = Profile;
var _c;
$RefreshReg$(_c, "Profile");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/profile.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/profile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/profile.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/profile.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPLGVBQWU7QUFDdEIsU0FBUyxlQUFlOzs7O0FBRXhCLGVBQWUsU0FBUyxVQUFVOztDQVVoQyxNQUFNLEVBQUUsU0FBUyxVQUFVOztDQUczQixNQUFNLE1BQU0sR0FBRyxRQUFRLFNBQVM7OztDQUdoQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQWU7Q0FDdkMsZ0JBQWdCO0VBQ2QsTUFBTSxHQUFHLENBQUMsQ0FDUCxNQUFNLGFBQWE7R0FDbEIsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFBTSxxQkFBcUI7R0FDdkM7R0FFQSxPQUFPLFNBQVMsS0FBSztFQUN2QixDQUFDLENBQUMsQ0FDRCxNQUFNLFNBQVM7R0FDZCxRQUFRLElBQUk7RUFDZCxDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQWU7R0FDckIsUUFBUSxJQUFJLEdBQUc7RUFDakIsQ0FBQztDQUNMLEdBQUcsQ0FBQyxDQUFDO0NBQ0wsT0FDRTtFQUNFLHdCQUFDLE1BQUQsWUFBSSxVQUFXOzs7OztFQUNmLHdCQUFDLE1BQUQsYUFBSSxVQUFPLE1BQU0sSUFBUzs7Ozs7RUFDMUIsd0JBQUMsTUFBRCxhQUFJLGFBQVUsTUFBTSxLQUFVOzs7OztFQUM5Qix3QkFBQyxLQUFEO0dBQUc7R0FBWSxNQUFNO0dBQUs7RUFBK0I7Ozs7O0VBQ3pELHdCQUFDLE1BQUQsQ0FBUTs7Ozs7RUFDUix3QkFBQyxNQUFELGFBQUssTUFBTSxNQUFLLFVBQVk7Ozs7O0VBQzVCLHdCQUFDLFdBQUQsRUFBVyxTQUFTLEtBQU87Ozs7O0NBQzNCOzs7OztBQUVOIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInByb2ZpbGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVBhcmFtcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFBvc3RzTGlzdCBmcm9tIFwiLi9Qb3N0c0xpc3RcIjtcclxuaW1wb3J0IHsgQVBJX1VSTCB9IGZyb20gXCIuL2NvbnN0YW50c1wiXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBQcm9maWxlKCkge1xyXG4gIHR5cGUgVXNlciA9IHtcclxuICAgIGlkOiBzdHJpbmc7XHJcbiAgICBuYW1lOiBzdHJpbmc7XHJcbiAgICBlbWFpbDogc3RyaW5nO1xyXG4gICAgcGhvbmU6IHN0cmluZztcclxuICAgIG9uX2NhbXB1czogYm9vbGVhbjtcclxuICAgIGNyZWF0ZWRfYXQ6IHN0cmluZztcclxuICB9O1xyXG5cclxuICBjb25zdCB7IHV1aWQgfSA9IHVzZVBhcmFtcygpO1xyXG4gIC8vIG1ha2UgdXJscyBieSBjb25jYXRlbmF0aW5nIHdpdGggdXNlciBpZFxyXG5cclxuICBjb25zdCB1cmwgPSBgJHtBUElfVVJMfS91c2Vycy8ke3V1aWR9YDtcclxuICAvLyBjb25zdCBwb3N0c1VybCA9XHJcbiAgICAvLyBcImh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9wb3N0cz91c2VyX2lkPVwiICsgdXVpZDtcclxuICBjb25zdCBbdXNlciwgZ2V0VXNlcl0gPSB1c2VTdGF0ZTxVc2VyPigpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBmZXRjaCh1cmwpXHJcbiAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xyXG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvdWxkIG5vdCBsb2FkIHVzZXJcIik7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzcG9uc2UuanNvbigpIGFzIFByb21pc2U8VXNlcj47XHJcbiAgICAgIH0pXHJcbiAgICAgIC50aGVuKChkYXRhKSA9PiB7XHJcbiAgICAgICAgZ2V0VXNlcihkYXRhKTtcclxuICAgICAgfSlcclxuICAgICAgLmNhdGNoKChlcnI6IEVycm9yKSA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coZXJyKTtcclxuICAgICAgfSk7XHJcbiAgfSwgW10pO1xyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8aDE+UHJvZmlsZTwvaDE+XHJcbiAgICAgIDxoMj5OYW1lOiB7dXNlcj8ubmFtZX08L2gyPlxyXG4gICAgICA8aDI+Q29udGFjdDoge3VzZXI/LmVtYWlsfTwvaDI+XHJcbiAgICAgIDxwPmhlbGxvIEkgYW0ge3VzZXI/Lm5hbWV9IGFuZCB0aGlzIGlzIG15IGFtYXppbmcgYmlvITwvcD5cclxuICAgICAgPGJyPjwvYnI+XHJcbiAgICAgIDxoMj57dXNlcj8ubmFtZX0ncyBQb3N0czwvaDI+XHJcbiAgICAgIDxQb3N0c0xpc3QgdXNlcl9pZD17dXVpZH0gLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl19