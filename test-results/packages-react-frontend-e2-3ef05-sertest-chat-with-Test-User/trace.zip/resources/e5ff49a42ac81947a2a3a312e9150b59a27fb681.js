import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/photoUpload.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import { uploadPhoto } from "/src/uploadPhoto.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/photoUpload.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function PhotoUpload({ onUpload }) {
	_s();
	const [preview, setPreview] = useState("");
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	async function handleChange(event) {
		const file = event.target.files?.[0];
		if (!file) return;
		setError("");
		setLoading(true);
		try {
			const url = await uploadPhoto(file);
			setPreview(url);
			onUpload(url);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Upload failed.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		/* @__PURE__ */ _jsxDEV("label", {
			htmlFor: "post-photo",
			children: "Upload a photo"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ _jsxDEV("input", {
			id: "post-photo",
			type: "file",
			accept: "image/*",
			onChange: handleChange
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 41,
			columnNumber: 7
		}, this),
		loading && /* @__PURE__ */ _jsxDEV("p", { children: "Uploading photo..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 48,
			columnNumber: 19
		}, this),
		error && /* @__PURE__ */ _jsxDEV("p", {
			role: "alert",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 49,
			columnNumber: 17
		}, this),
		preview && /* @__PURE__ */ _jsxDEV("img", {
			src: preview,
			alt: "Selected post",
			style: {
				width: 200,
				objectFit: "cover"
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 52,
			columnNumber: 9
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
_s(PhotoUpload, "KWPNoEUWIteZVpfmAcNQLTPpYOY=");
_c = PhotoUpload;
var _c;
$RefreshReg$(_c, "PhotoUpload");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/photoUpload.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/photoUpload.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/photoUpload.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/photoUpload.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7Ozs7QUFNNUIsZUFBZSxTQUFTLFlBQVksRUFDbEMsWUFDbUI7O0NBQ25CLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLGVBQWUsYUFDYixPQUNBO0VBQ0EsTUFBTSxPQUFPLE1BQU0sT0FBTyxRQUFRO0VBQ2xDLElBQUksQ0FBQyxNQUFNO0VBRVgsU0FBUyxFQUFFO0VBQ1gsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNGLE1BQU0sTUFBTSxNQUFNLFlBQVksSUFBSTtHQUNsQyxXQUFXLEdBQUc7R0FDZCxTQUFTLEdBQUc7RUFDZCxTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFBUSxJQUFJLFVBQVUsZ0JBQ3ZDO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQ0Usd0JBQUMsU0FBRDtHQUFPLFNBQVE7YUFBYTtFQUFxQjs7Ozs7RUFFakQsd0JBQUMsU0FBRDtHQUNFLElBQUc7R0FDSCxNQUFLO0dBQ0wsUUFBTztHQUNQLFVBQVU7RUFDWDs7Ozs7RUFFQSxXQUFXLHdCQUFDLEtBQUQsWUFBRyxxQkFBcUI7Ozs7O0VBQ25DLFNBQVMsd0JBQUMsS0FBRDtHQUFHLE1BQUs7YUFBUztFQUFTOzs7OztFQUVuQyxXQUNDLHdCQUFDLE9BQUQ7R0FDRSxLQUFLO0dBQ0wsS0FBSTtHQUNKLE9BQU87SUFBRSxPQUFPO0lBQUssV0FBVztHQUFRO0VBQ3pDOzs7OztDQUVBOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInBob3RvVXBsb2FkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1cGxvYWRQaG90byB9IGZyb20gXCIuL3VwbG9hZFBob3RvXCI7XHJcblxyXG50eXBlIFBob3RvVXBsb2FkUHJvcHMgPSB7XHJcbiAgb25VcGxvYWQ6ICh1cmw6IHN0cmluZykgPT4gdm9pZDtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFBob3RvVXBsb2FkKHtcclxuICBvblVwbG9hZCxcclxufTogUGhvdG9VcGxvYWRQcm9wcykge1xyXG4gIGNvbnN0IFtwcmV2aWV3LCBzZXRQcmV2aWV3XSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVDaGFuZ2UoXHJcbiAgICBldmVudDogUmVhY3QuQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD5cclxuICApIHtcclxuICAgIGNvbnN0IGZpbGUgPSBldmVudC50YXJnZXQuZmlsZXM/LlswXTtcclxuICAgIGlmICghZmlsZSkgcmV0dXJuO1xyXG5cclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCB1cmwgPSBhd2FpdCB1cGxvYWRQaG90byhmaWxlKTtcclxuICAgICAgc2V0UHJldmlldyh1cmwpO1xyXG4gICAgICBvblVwbG9hZCh1cmwpO1xyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiBcIlVwbG9hZCBmYWlsZWQuXCJcclxuICAgICAgKTtcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHNldExvYWRpbmcoZmFsc2UpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxsYWJlbCBodG1sRm9yPVwicG9zdC1waG90b1wiPlVwbG9hZCBhIHBob3RvPC9sYWJlbD5cclxuXHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPVwicG9zdC1waG90b1wiXHJcbiAgICAgICAgdHlwZT1cImZpbGVcIlxyXG4gICAgICAgIGFjY2VwdD1cImltYWdlLypcIlxyXG4gICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgIC8+XHJcblxyXG4gICAgICB7bG9hZGluZyAmJiA8cD5VcGxvYWRpbmcgcGhvdG8uLi48L3A+fVxyXG4gICAgICB7ZXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XHJcblxyXG4gICAgICB7cHJldmlldyAmJiAoXHJcbiAgICAgICAgPGltZ1xyXG4gICAgICAgICAgc3JjPXtwcmV2aWV3fVxyXG4gICAgICAgICAgYWx0PVwiU2VsZWN0ZWQgcG9zdFwiXHJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjAwLCBvYmplY3RGaXQ6IFwiY292ZXJcIiB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59Il19