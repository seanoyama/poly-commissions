import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ChatsList.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=2b466928";
import "/src/App.css";
import { useAuth } from "/src/SessionContext.tsx";
import { UserName } from "/src/services/userData.tsx";
import { API_URL } from "/src/constants.ts";
var _jsxFileName = "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatsList.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=2b466928";
var _s = $RefreshSig$();
export default function ChatsList(props) {
	_s();
	const { session, user } = useAuth();
	const chat_id = props.chat_id;
	const refreshKey = props.refreshKey;
	// url variable in case we go #public
	// let API_URL = "http://localhost:8000";
	let url = `${API_URL}/chats`;
	console.log(user);
	if (user) {
		url += `?user=${encodeURIComponent(user?.id)}`;
	}
	console.log(url);
	const [chats, setChats] = useState([]);
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(true);
	useEffect(() => {
		setLoading(true);
		setError("");
		fetch(url).then((response) => {
			if (!response.ok) {
				throw new Error("Could not load chats");
			}
			return response.json();
		}).then((data) => {
			setChats(data);
		}).catch((err) => {
			setError(err.message);
		}).finally(() => {
			setLoading(false);
		});
	}, [chat_id, refreshKey]);
	if (!session || !user) return /* @__PURE__ */ _jsxDEV("div", { children: "Please log in to view your messages." }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 57,
		columnNumber: 12
	}, this);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		error && /* @__PURE__ */ _jsxDEV("p", {
			className: "error-message",
			children: error
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 17
		}, this),
		loading && chats.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "Loading..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 62,
			columnNumber: 41
		}, this),
		!loading && !error && chats.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No chats yet." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 64,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("section", {
			className: "posts-list-grid",
			children: chats.map((chat) => /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("a", {
				href: `http://localhost:5173/messages/${chat.id}`,
				children: [
					"Chat with ",
					/* @__PURE__ */ _jsxDEV(UserName, { uuid: chat.user_one }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 25
					}, this),
					" and ",
					/* @__PURE__ */ _jsxDEV(UserName, { uuid: chat.user_two }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 62
					}, this),
					" ",
					/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 72,
						columnNumber: 95
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 74,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 69,
				columnNumber: 11
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 67,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 60,
		columnNumber: 5
	}, this);
}
_s(ChatsList, "CJI8gfbmctgHSzkWtPYKQs/bZX0=", false, function() {
	return [useAuth];
});
_c = ChatsList;
var _c;
$RefreshReg$(_c, "ChatsList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/ChatsList.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatsList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatsList.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/seano/OneDrive/Desktop/cal poly projects/csc3100/poly-commissions/packages/react-frontend/src/ChatsList.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPO0FBQ1AsU0FBUyxlQUFlO0FBQ3hCLFNBQVEsZ0JBQWU7QUFFdkIsU0FBUSxlQUFjOzs7O0FBU3RCLGVBQWUsU0FBUyxVQUFVLE9BQVk7O0NBQzVDLE1BQU0sRUFBRSxTQUFTLFNBQVMsUUFBUTtDQUNsQyxNQUFNLFVBQVUsTUFBTTtDQUN0QixNQUFNLGFBQWEsTUFBTTs7O0NBR3pCLElBQUksTUFBTSxHQUFHLFFBQVE7Q0FDbkIsUUFBUSxJQUFJLElBQUk7Q0FDaEIsSUFBSSxNQUFNO0VBQ1IsT0FBTyxTQUFTLG1CQUFtQixNQUFNLEVBQUU7Q0FDN0M7Q0FDQSxRQUFRLElBQUksR0FBRztDQUVqQixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlCLENBQUMsQ0FBQztDQUM3QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQWlCLEVBQUU7Q0FDN0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FFM0MsZ0JBQWdCO0VBR2QsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsTUFBTSxHQUFHLENBQUMsQ0FDUCxNQUFNLGFBQWE7R0FDbEIsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFBTSxzQkFBc0I7R0FDeEM7R0FDQSxPQUFPLFNBQVMsS0FBSztFQUN2QixDQUFDLENBQUMsQ0FDRCxNQUFNLFNBQVM7R0FDZCxTQUFTLElBQUk7RUFDZixDQUFDLENBQUMsQ0FDRCxPQUFPLFFBQWU7R0FDckIsU0FBUyxJQUFJLE9BQU87RUFDdEIsQ0FBQyxDQUFDLENBQ0QsY0FBYztHQUNiLFdBQVcsS0FBSztFQUNsQixDQUFDO0NBQ0wsR0FBRyxDQUFDLFNBQVMsVUFBVSxDQUFDO0NBRXhCLElBQUksQ0FBQyxXQUFXLENBQUMsTUFDZixPQUFPLHdCQUFDLE9BQUQsWUFBSyx1Q0FBeUM7Ozs7O0NBRXZELE9BQ0Usd0JBQUMsT0FBRDtFQUNHLFNBQVMsd0JBQUMsS0FBRDtHQUFHLFdBQVU7YUFBaUI7RUFBUzs7Ozs7RUFDaEQsV0FBVyxNQUFNLFdBQVcsS0FBSyx3QkFBQyxLQUFELFlBQUcsYUFBYTs7Ozs7RUFDakQsQ0FBQyxXQUFXLENBQUMsU0FBUyxNQUFNLFdBQVcsS0FDdEMsd0JBQUMsS0FBRCxZQUFHLGdCQUFnQjs7Ozs7RUFHckIsd0JBQUMsV0FBRDtHQUFTLFdBQVU7YUFDaEIsTUFBTSxLQUFLLFNBQ1Ysd0JBQUMsT0FBRCxhQUNFLHdCQUFDLEtBQUQ7SUFDRSxNQUFNLGtDQUFrQyxLQUFLO2NBRC9DO0tBQ3FEO0tBQ3pDLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEtBQUssU0FBVTs7Ozs7S0FBQztLQUFLLHdCQUFDLFVBQUQsRUFBVSxNQUFNLEtBQUssU0FBVTs7Ozs7S0FBQztLQUFDLHdCQUFDLE1BQUQsQ0FBUTs7Ozs7SUFDdkY7Ozs7O2FBQ0gsd0JBQUMsTUFBRCxDQUFROzs7O1dBQ0w7Ozs7V0FDTjtFQUNNOzs7OztDQUNOOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNoYXRzTGlzdC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgXCIuL0FwcC5jc3NcIjtcclxuaW1wb3J0IHsgdXNlQXV0aCB9IGZyb20gXCIuL1Nlc3Npb25Db250ZXh0XCI7XHJcbmltcG9ydCB7VXNlck5hbWV9IGZyb20gXCIuL3NlcnZpY2VzL3VzZXJEYXRhXCI7XHJcblxyXG5pbXBvcnQge0FQSV9VUkx9IGZyb20gXCIuL2NvbnN0YW50c1wiXHJcblxyXG50eXBlIENoYXQgPSB7XHJcbiAgaWQ6IHN0cmluZztcclxuICB1c2VyX29uZTogc3RyaW5nO1xyXG4gIHVzZXJfdHdvOiBzdHJpbmc7XHJcbiAgcG9zdF9pZDogc3RyaW5nO1xyXG4gIGNyZWF0ZWRfYXQ6IHN0cmluZztcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQ2hhdHNMaXN0KHByb3BzOiBhbnkpIHtcclxuICBjb25zdCB7IHNlc3Npb24sIHVzZXIgfSA9IHVzZUF1dGgoKTtcclxuICBjb25zdCBjaGF0X2lkID0gcHJvcHMuY2hhdF9pZDtcclxuICBjb25zdCByZWZyZXNoS2V5ID0gcHJvcHMucmVmcmVzaEtleTtcclxuICAvLyB1cmwgdmFyaWFibGUgaW4gY2FzZSB3ZSBnbyAjcHVibGljXHJcbiAgLy8gbGV0IEFQSV9VUkwgPSBcImh0dHA6Ly9sb2NhbGhvc3Q6ODAwMFwiO1xyXG4gIGxldCB1cmwgPSBgJHtBUElfVVJMfS9jaGF0c2A7XHJcbiAgICBjb25zb2xlLmxvZyh1c2VyKTtcclxuICAgIGlmICh1c2VyKSB7XHJcbiAgICAgIHVybCArPSBgP3VzZXI9JHtlbmNvZGVVUklDb21wb25lbnQodXNlcj8uaWQpfWA7XHJcbiAgICB9XHJcbiAgICBjb25zb2xlLmxvZyh1cmwpO1xyXG4gIFxyXG4gIGNvbnN0IFtjaGF0cywgc2V0Q2hhdHNdID0gdXNlU3RhdGU8Q2hhdFtdPihbXSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgXHJcblxyXG4gICAgc2V0TG9hZGluZyh0cnVlKTtcclxuICAgIHNldEVycm9yKFwiXCIpO1xyXG5cclxuICAgIGZldGNoKHVybClcclxuICAgICAgLnRoZW4oKHJlc3BvbnNlKSA9PiB7XHJcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ291bGQgbm90IGxvYWQgY2hhdHNcIik7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHJldHVybiByZXNwb25zZS5qc29uKCkgYXMgUHJvbWlzZTxDaGF0W10+O1xyXG4gICAgICB9KVxyXG4gICAgICAudGhlbigoZGF0YSkgPT4ge1xyXG4gICAgICAgIHNldENoYXRzKGRhdGEpO1xyXG4gICAgICB9KVxyXG4gICAgICAuY2F0Y2goKGVycjogRXJyb3IpID0+IHtcclxuICAgICAgICBzZXRFcnJvcihlcnIubWVzc2FnZSk7XHJcbiAgICAgIH0pXHJcbiAgICAgIC5maW5hbGx5KCgpID0+IHtcclxuICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKTtcclxuICAgICAgfSk7XHJcbiAgfSwgW2NoYXRfaWQsIHJlZnJlc2hLZXldKTtcclxuXHJcbiAgaWYgKCFzZXNzaW9uIHx8ICF1c2VyKVxyXG4gICAgcmV0dXJuIDxkaXY+UGxlYXNlIGxvZyBpbiB0byB2aWV3IHlvdXIgbWVzc2FnZXMuPC9kaXY+O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yLW1lc3NhZ2VcIj57ZXJyb3J9PC9wPn1cclxuICAgICAge2xvYWRpbmcgJiYgY2hhdHMubGVuZ3RoID09PSAwICYmIDxwPkxvYWRpbmcuLi48L3A+fVxyXG4gICAgICB7IWxvYWRpbmcgJiYgIWVycm9yICYmIGNoYXRzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPHA+Tm8gY2hhdHMgeWV0LjwvcD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBvc3RzLWxpc3QtZ3JpZFwiPlxyXG4gICAgICAgIHtjaGF0cy5tYXAoKGNoYXQpID0+IChcclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxhXHJcbiAgICAgICAgICAgICAgaHJlZj17YGh0dHA6Ly9sb2NhbGhvc3Q6NTE3My9tZXNzYWdlcy8ke2NoYXQuaWR9YH0+XHJcbiAgICAgICAgICAgICAgQ2hhdCB3aXRoIDxVc2VyTmFtZSB1dWlkPXtjaGF0LnVzZXJfb25lfS8+IGFuZCA8VXNlck5hbWUgdXVpZD17Y2hhdC51c2VyX3R3b30vPiA8YnI+PC9icj5cclxuICAgICAgICAgICAgPC9hPlxyXG4gICAgICAgICAgICA8YnI+PC9icj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICkpfVxyXG4gICAgICA8L3NlY3Rpb24+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdfQ==